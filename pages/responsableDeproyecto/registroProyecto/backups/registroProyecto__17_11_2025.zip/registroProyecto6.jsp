<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Estudiantes - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .participant-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
            background: white;
            border-radius: 0.75rem;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .participant-table th {
            background-color: #7A1737;
            color: white;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            font-size: 0.875rem;
        }
        
        .participant-table td {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-section {
            background: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .section-header {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #B28854;
        }
        
        .notification {
            position: fixed;
            top: 1rem;
            right: 1rem;
            padding: 1rem;
            border-radius: 0.5rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: flex;
            align-items: center;
            max-width: 400px;
            transform: translateX(150%);
            transition: transform 0.3s ease-out;
            background-color: #fee2e2;
            border: 1px solid #ef4444;
            color: #991b1b;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification-icon {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }
        
        .table-title {
            color: #7A1737;
            font-weight: 600;
            margin: 0;
        }
        
        .legend-box {
            background-color: #f8fafc;
            border-left: 4px solid #7A1737;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 0.375rem;
        }
        
        .legend-title {
            font-weight: 600;
            color: #7A1737;
            margin-bottom: 0.5rem;
        }
        
        .legend-text {
            color: #4b5563;
            font-size: 0.875rem;
        }
        
        .file-input {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.5rem;
            width: 100%;
            font-size: 0.875rem;
        }
        
        .file-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 2px rgba(122, 23, 55, 0.2);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    <%@ include file="Navegador.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-user-graduate mr-3"></i>OPCIONAL. Estudiantes Participantes 6/9
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Ingrese la información de los estudiantes participantes (En caso de no contar con estudiantes, guarde en borrador y continúe)
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formEstudiantes" class="p-8 space-y-8">
                    <!-- Leyenda -->
                    <div class="legend-box">
                        <div class="legend-title">Estudiantes Participantes</div>
                        <div class="legend-text"> Cada estudiante debe contar con información completa sobre su nivel académico, institución, programa educativo,
                            tiempo de permanencia en el proyecto, actividades específicas y adjuntar la carta de intención de colaboración.
                        </div>
                    </div>

                    <!-- Sección: ESTUDIANTES - 5 Tablas -->
                    <section class="space-y-6">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-user-graduate mr-2 text-[#7A1737]"></i>ESTUDIANTES
                        </h4>

                        <!-- Tabla 1 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Estudiante 1</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre completo</td>
                                        <td><input type="text" name="est-nombre-1" class="floating-input" placeholder="Nombre completo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Nivel académico</td>
                                        <td>
                                            <select name="est-nivel-1" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Licenciatura">Licenciatura</option>
                                                <option value="Maestría">Maestría</option>
                                                <option value="Doctorado">Doctorado</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Institución</td>
                                        <td><input type="text" name="est-institucion-1" class="floating-input" placeholder="Institución"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Programa Educativo</td>
                                        <td><input type="text" name="est-programa-1" class="floating-input" placeholder="Programa Educativo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Sexo</td>
                                        <td>
                                            <select name="est-sexo-1" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Hombre">Hombre</option>
                                                <option value="Mujer">Mujer</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Tiempo de permanencia (meses)</td>
                                        <td><input type="number" name="est-tiempo-1" class="floating-input" placeholder="Meses" min="1" max="6" oninput="if(this.value>6)this.value=6;"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Actividades a realizar</td>
                                        <td><input type="text" name="est-actividades-realizar-1" class="floating-input" placeholder="Actividades a realizar"></td>
                                    </tr>
                                    <tr>
                                    <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Adjunte carta de intención de colaboración 
                                        </td>
                                        <td>
                                            <input type="file" name="est-comprobante-1" accept=".pdf,image/*" 
                                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 2 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Estudiante 2</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre completo</td>
                                        <td><input type="text" name="est-nombre-2" class="floating-input" placeholder="Nombre completo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Nivel académico</td>
                                        <td>
                                            <select name="est-nivel-2" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Licenciatura">Licenciatura</option>
                                                <option value="Maestría">Maestría</option>
                                                <option value="Doctorado">Doctorado</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Institución</td>
                                        <td><input type="text" name="est-institucion-2" class="floating-input" placeholder="Institución"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Programa Educativo</td>
                                        <td><input type="text" name="est-programa-2" class="floating-input" placeholder="Programa Educativo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Sexo</td>
                                        <td>
                                            <select name="est-sexo-2" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Hombre">Hombre</option>
                                                <option value="Mujer">Mujer</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Tiempo de permanencia (meses)</td>
                                        <td><input type="number" name="est-tiempo-2" class="floating-input" placeholder="Meses" min="1" max="6" oninput="if(this.value>6)this.value=6;"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Actividades a realizar</td>
                                        <td><input type="text" name="est-actividades-realizar-2" class="floating-input" placeholder="Actividades a realizar"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Adjunte carta de intención de colaboración 
                                        </td>
                                        <td>
                                            <input type="file" name="est-comprobante-2" accept=".pdf,image/*" 
                                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 3 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Estudiante 3</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre completo</td>
                                        <td><input type="text" name="est-nombre-3" class="floating-input" placeholder="Nombre completo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Nivel académico</td>
                                        <td>
                                            <select name="est-nivel-3" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Licenciatura">Licenciatura</option>
                                                <option value="Maestría">Maestría</option>
                                                <option value="Doctorado">Doctorado</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Institución</td>
                                        <td><input type="text" name="est-institucion-3" class="floating-input" placeholder="Institución"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Programa Educativo</td>
                                        <td><input type="text" name="est-programa-3" class="floating-input" placeholder="Programa Educativo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Sexo</td>
                                        <td>
                                            <select name="est-sexo-3" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Hombre">Hombre</option>
                                                <option value="Mujer">Mujer</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Tiempo de permanencia (meses)</td>
                                        <td><input type="number" name="est-tiempo-3" class="floating-input" placeholder="Meses" min="1" max="6" oninput="if(this.value>6)this.value=6;"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Actividades a realizar</td>
                                        <td><input type="text" name="est-actividades-realizar-3" class="floating-input" placeholder="Actividades a realizar"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Adjunte carta de intención de colaboración 
                                        </td>
                                        <td>
                                            <input type="file" name="est-comprobante-3" accept=".pdf,image/*" 
                                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 4 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Estudiante 4</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre completo</td>
                                        <td><input type="text" name="est-nombre-4" class="floating-input" placeholder="Nombre completo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Nivel académico</td>
                                        <td>
                                            <select name="est-nivel-4" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Licenciatura">Licenciatura</option>
                                                <option value="Maestría">Maestría</option>
                                                <option value="Doctorado">Doctorado</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Institución</td>
                                        <td><input type="text" name="est-institucion-4" class="floating-input" placeholder="Institución"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Programa Educativo</td>
                                        <td><input type="text" name="est-programa-4" class="floating-input" placeholder="Programa Educativo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Sexo</td>
                                        <td>
                                            <select name="est-sexo-4" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Hombre">Hombre</option>
                                                <option value="Mujer">Mujer</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Tiempo de permanencia (meses)</td>
                                        <td><input type="number" name="est-tiempo-4" class="floating-input" placeholder="Meses" min="1" max="6" oninput="if(this.value>6)this.value=6;"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Actividades a realizar</td>
                                        <td><input type="text" name="est-actividades-realizar-4" class="floating-input" placeholder="Actividades a realizar"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Adjunte carta de intención de colaboración 
                                        </td>
                                        <td>
                                            <input type="file" name="est-comprobante-4" accept=".pdf,image/*" 
                                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 5 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Estudiante 5</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre completo</td>
                                        <td><input type="text" name="est-nombre-5" class="floating-input" placeholder="Nombre completo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Nivel académico</td>
                                        <td>
                                            <select name="est-nivel-5" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Licenciatura">Licenciatura</option>
                                                <option value="Maestría">Maestría</option>
                                                <option value="Doctorado">Doctorado</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Institución</td>
                                        <td><input type="text" name="est-institucion-5" class="floating-input" placeholder="Institución"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Programa Educativo</td>
                                        <td><input type="text" name="est-programa-5" class="floating-input" placeholder="Programa Educativo"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Sexo</td>
                                        <td>
                                            <select name="est-sexo-5" class="floating-input">
                                                <option value="">Seleccione</option>
                                                <option value="Hombre">Hombre</option>
                                                <option value="Mujer">Mujer</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Tiempo de permanencia (meses)</td>
                                        <td><input type="number" name="est-tiempo-5" class="floating-input" placeholder="Meses" min="1" max="6" oninput="if(this.value>6)this.value=6;"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Actividades a realizar</td>
                                        <td><input type="text" name="est-actividades-realizar-5" class="floating-input" placeholder="Actividades a realizar"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Adjunte carta de intención de colaboración 
                                        </td>
                                        <td>
                                            <input type="file" name="est-comprobante-5" accept=".pdf,image/*" 
                                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>

                    <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formEstudiantes', 'pagina6', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto5.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button" id="btnSiguiente"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>
    
    <!-- Notificación -->
    <div id="notification" class="notification">
        <i class="notification-icon fas fa-exclamation-circle"></i>
        <span class="notification-message"></span>
    </div>
    
    <script>
        // Función para guardar datos del formulario en localStorage con estructura plana
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            
            console.log('[estudiantes] Iniciando guardado de borrador...');
            
            // Estructura JSON PLANA - cada estudiante como campo individual (sin arrays ni loops)
            const jsonData = {
                estudiantes: {
                    // Estudiante 1
                    estudiante1_nombre: form.querySelector('[name="est-nombre-1"]')?.value || '',
                    estudiante1_sexo: form.querySelector('[name="est-sexo-1"]')?.value || '',
                    estudiante1_nivel: form.querySelector('[name="est-nivel-1"]')?.value || '',
                    estudiante1_tiempo: form.querySelector('[name="est-tiempo-1"]')?.value || '',
                    estudiante1_institucion: form.querySelector('[name="est-institucion-1"]')?.value || '',
                    estudiante1_programa: form.querySelector('[name="est-programa-1"]')?.value || '',
                    estudiante1_actividades: form.querySelector('[name="est-actividades-realizar-1"]')?.value || '',
                    estudiante1_comprobante: form.querySelector('[name="est-comprobante-1"]')?.files[0]?.name || '',
                    
                    // Estudiante 2
                    estudiante2_nombre: form.querySelector('[name="est-nombre-2"]')?.value || '',
                    estudiante2_sexo: form.querySelector('[name="est-sexo-2"]')?.value || '',
                    estudiante2_nivel: form.querySelector('[name="est-nivel-2"]')?.value || '',
                    estudiante2_tiempo: form.querySelector('[name="est-tiempo-2"]')?.value || '',
                    estudiante2_institucion: form.querySelector('[name="est-institucion-2"]')?.value || '',
                    estudiante2_programa: form.querySelector('[name="est-programa-2"]')?.value || '',
                    estudiante2_actividades: form.querySelector('[name="est-actividades-realizar-2"]')?.value || '',
                    estudiante2_comprobante: form.querySelector('[name="est-comprobante-2"]')?.files[0]?.name || '',
                    
                    // Estudiante 3
                    estudiante3_nombre: form.querySelector('[name="est-nombre-3"]')?.value || '',
                    estudiante3_sexo: form.querySelector('[name="est-sexo-3"]')?.value || '',
                    estudiante3_nivel: form.querySelector('[name="est-nivel-3"]')?.value || '',
                    estudiante3_tiempo: form.querySelector('[name="est-tiempo-3"]')?.value || '',
                    estudiante3_institucion: form.querySelector('[name="est-institucion-3"]')?.value || '',
                    estudiante3_programa: form.querySelector('[name="est-programa-3"]')?.value || '',
                    estudiante3_actividades: form.querySelector('[name="est-actividades-realizar-3"]')?.value || '',
                    estudiante3_comprobante: form.querySelector('[name="est-comprobante-3"]')?.files[0]?.name || '',
                    
                    // Estudiante 4
                    estudiante4_nombre: form.querySelector('[name="est-nombre-4"]')?.value || '',
                    estudiante4_sexo: form.querySelector('[name="est-sexo-4"]')?.value || '',
                    estudiante4_nivel: form.querySelector('[name="est-nivel-4"]')?.value || '',
                    estudiante4_tiempo: form.querySelector('[name="est-tiempo-4"]')?.value || '',
                    estudiante4_institucion: form.querySelector('[name="est-institucion-4"]')?.value || '',
                    estudiante4_programa: form.querySelector('[name="est-programa-4"]')?.value || '',
                    estudiante4_actividades: form.querySelector('[name="est-actividades-realizar-4"]')?.value || '',
                    estudiante4_comprobante: form.querySelector('[name="est-comprobante-4"]')?.files[0]?.name || '',
                    
                    // Estudiante 5
                    estudiante5_nombre: form.querySelector('[name="est-nombre-5"]')?.value || '',
                    estudiante5_sexo: form.querySelector('[name="est-sexo-5"]')?.value || '',
                    estudiante5_nivel: form.querySelector('[name="est-nivel-5"]')?.value || '',
                    estudiante5_tiempo: form.querySelector('[name="est-tiempo-5"]')?.value || '',
                    estudiante5_institucion: form.querySelector('[name="est-institucion-5"]')?.value || '',
                    estudiante5_programa: form.querySelector('[name="est-programa-5"]')?.value || '',
                    estudiante5_actividades: form.querySelector('[name="est-actividades-realizar-5"]')?.value || '',
                    estudiante5_comprobante: form.querySelector('[name="est-comprobante-5"]')?.files[0]?.name || ''
                }
            };
            
            try {
                localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(jsonData));
                console.log('[estudiantes] ✅ Borrador guardado exitosamente');
                console.log('[estudiantes] Datos guardados:', jsonData.pagina6);
                
                // Verificación
                const verify = localStorage.getItem('proyecto_borrador_' + pageKey);
                if (verify) {
                    console.log('[estudiantes] ✅ Verificación exitosa - datos recuperables');
                } else {
                    console.error('[estudiantes] ❌ Error: No se pudo verificar el guardado');
                }
            } catch (e) {
                console.error('[estudiantes] ❌ Error al guardar borrador:', e);
                mostrarMensaje('Error al guardar el borrador', 'error', targetBtn);
                return;
            }
            
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        // Función para cargar borrador
        function cargarBorrador(formId, pageKey) {
            console.log('[estudiantes] Intentando cargar borrador...');
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (!savedData) {
                console.log('[estudiantes] No hay borrador guardado');
                return;
            }
            
            try {
                const data = JSON.parse(savedData);
                console.log('[estudiantes] Borrador encontrado:', data);
                
                const form = document.getElementById(formId);
                if (!form) {
                    console.error('[estudiantes] ❌ Formulario no encontrado');
                    return;
                }
                
                // Cargar estructura PLANA (igual que guardarBorrador)
                const p6 = data?.estudiantes;
                if (!p6) {
                    console.warn('[estudiantes] ⚠️ No se encontró estudiantes en el borrador');
                    return;
                }
                
                // Estudiante 1
                if (p6.estudiante1_nombre) form.querySelector('[name="est-nombre-1"]').value = p6.estudiante1_nombre;
                if (p6.estudiante1_sexo) form.querySelector('[name="est-sexo-1"]').value = p6.estudiante1_sexo;
                if (p6.estudiante1_nivel) form.querySelector('[name="est-nivel-1"]').value = p6.estudiante1_nivel;
                if (p6.estudiante1_tiempo) form.querySelector('[name="est-tiempo-1"]').value = p6.estudiante1_tiempo;
                if (p6.estudiante1_institucion) form.querySelector('[name="est-institucion-1"]').value = p6.estudiante1_institucion;
                if (p6.estudiante1_programa) form.querySelector('[name="est-programa-1"]').value = p6.estudiante1_programa;
                if (p6.estudiante1_actividades) form.querySelector('[name="est-actividades-realizar-1"]').value = p6.estudiante1_actividades;
                
                // Estudiante 2
                if (p6.estudiante2_nombre) form.querySelector('[name="est-nombre-2"]').value = p6.estudiante2_nombre;
                if (p6.estudiante2_sexo) form.querySelector('[name="est-sexo-2"]').value = p6.estudiante2_sexo;
                if (p6.estudiante2_nivel) form.querySelector('[name="est-nivel-2"]').value = p6.estudiante2_nivel;
                if (p6.estudiante2_tiempo) form.querySelector('[name="est-tiempo-2"]').value = p6.estudiante2_tiempo;
                if (p6.estudiante2_institucion) form.querySelector('[name="est-institucion-2"]').value = p6.estudiante2_institucion;
                if (p6.estudiante2_programa) form.querySelector('[name="est-programa-2"]').value = p6.estudiante2_programa;
                if (p6.estudiante2_actividades) form.querySelector('[name="est-actividades-realizar-2"]').value = p6.estudiante2_actividades;
                
                // Estudiante 3
                if (p6.estudiante3_nombre) form.querySelector('[name="est-nombre-3"]').value = p6.estudiante3_nombre;
                if (p6.estudiante3_sexo) form.querySelector('[name="est-sexo-3"]').value = p6.estudiante3_sexo;
                if (p6.estudiante3_nivel) form.querySelector('[name="est-nivel-3"]').value = p6.estudiante3_nivel;
                if (p6.estudiante3_tiempo) form.querySelector('[name="est-tiempo-3"]').value = p6.estudiante3_tiempo;
                if (p6.estudiante3_institucion) form.querySelector('[name="est-institucion-3"]').value = p6.estudiante3_institucion;
                if (p6.estudiante3_programa) form.querySelector('[name="est-programa-3"]').value = p6.estudiante3_programa;
                if (p6.estudiante3_actividades) form.querySelector('[name="est-actividades-realizar-3"]').value = p6.estudiante3_actividades;
                
                // Estudiante 4
                if (p6.estudiante4_nombre) form.querySelector('[name="est-nombre-4"]').value = p6.estudiante4_nombre;
                if (p6.estudiante4_sexo) form.querySelector('[name="est-sexo-4"]').value = p6.estudiante4_sexo;
                if (p6.estudiante4_nivel) form.querySelector('[name="est-nivel-4"]').value = p6.estudiante4_nivel;
                if (p6.estudiante4_tiempo) form.querySelector('[name="est-tiempo-4"]').value = p6.estudiante4_tiempo;
                if (p6.estudiante4_institucion) form.querySelector('[name="est-institucion-4"]').value = p6.estudiante4_institucion;
                if (p6.estudiante4_programa) form.querySelector('[name="est-programa-4"]').value = p6.estudiante4_programa;
                if (p6.estudiante4_actividades) form.querySelector('[name="est-actividades-realizar-4"]').value = p6.estudiante4_actividades;
                
                // Estudiante 5
                if (p6.estudiante5_nombre) form.querySelector('[name="est-nombre-5"]').value = p6.estudiante5_nombre;
                if (p6.estudiante5_sexo) form.querySelector('[name="est-sexo-5"]').value = p6.estudiante5_sexo;
                if (p6.estudiante5_nivel) form.querySelector('[name="est-nivel-5"]').value = p6.estudiante5_nivel;
                if (p6.estudiante5_tiempo) form.querySelector('[name="est-tiempo-5"]').value = p6.estudiante5_tiempo;
                if (p6.estudiante5_institucion) form.querySelector('[name="est-institucion-5"]').value = p6.estudiante5_institucion;
                if (p6.estudiante5_programa) form.querySelector('[name="est-programa-5"]').value = p6.estudiante5_programa;
                if (p6.estudiante5_actividades) form.querySelector('[name="est-actividades-realizar-5"]').value = p6.estudiante5_actividades;
                
                console.log('[estudiantes] ✅ Borrador cargado exitosamente');
            } catch (error) {
                console.error('[estudiantes] ❌ Error al cargar borrador:', error);
            }
        }

        // Mostrar mensaje temporal
        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';
            
            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }
            
            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;
            
            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);
                
                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
                
                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;
                
                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }
                
                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;
                
                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }
            
            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir control de navegación
        window.addEventListener('load', function() {
            cargarBorrador('formEstudiantes', 'pagina6');
            
            const KEY = 'proyecto_borrador_pagina6_saved';
            const form = document.getElementById('formEstudiantes');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const siguienteBtn = document.getElementById('btnSiguiente');
            
            function setDisabled(btn, disabled){
                if(!btn) return;
                // No usar disabled real para que los eventos sigan funcionando
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                btn.setAttribute('data-disabled', disabled ? 'true' : 'false');
                if(disabled) {
                    btn.classList.add('opacity-60', 'cursor-not-allowed');
                    btn.classList.remove('hover:bg-[#5c0f2a]');
                } else {
                    btn.classList.remove('opacity-60', 'cursor-not-allowed');
                    btn.classList.add('hover:bg-[#5c0f2a]');
                }
            }
            
            if(!guardarBtn || !siguienteBtn){
                console.warn('No se encontraron botones Guardar/Siguiente en estudiantes');
                return;
            }
            
            // Estado inicial desde localStorage
            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(siguienteBtn, !saved);
            
            // Cuando se pulsa guardar, marcar y habilitar siguiente
            guardarBtn.addEventListener('click', function(){
                localStorage.setItem(KEY,'1');
                saved = true;
                setDisabled(siguienteBtn, false);
                console.log('Borrador estudiantes guardado -> Siguiente habilitado');
            });
            
            // Agregar evento al botón siguiente para manejar navegación y advertencias
            siguienteBtn.addEventListener('click', function(e){
                e.preventDefault();
                e.stopPropagation();
                
                // Verificar si está "deshabilitado" (visualmente)
                if(siguienteBtn.getAttribute('data-disabled') === 'true'){
                    mostrarMensaje('Debe guardar el borrador antes de continuar', 'error', siguienteBtn);
                    return false;
                }
                
                // Si está habilitado, navegar a la siguiente página
                window.location.href = '/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto7.jsp';
            });
            
            // Si el formulario cambia después de guardar, volver a marcar como no guardado y bloquear
            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        setDisabled(siguienteBtn, true);
                        console.log('Formulario estudiantes modificado después de guardar: Siguiente bloqueado.');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));
                
                // Advertir al usuario si intenta abandonar la página con cambios no guardados
                window.addEventListener('beforeunload', function(e){
                    try{
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault(); 
                            e.returnValue = msg; 
                            return msg;
                        }
                    }catch(err){ 
                        return undefined; 
                    }
                });
            }
        });
    </script>
</body>
</html>