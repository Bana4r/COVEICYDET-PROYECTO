<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Documento Extenso - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }

        .download-btn {
            background: linear-gradient(135deg, #7A1737 0%, #B28854 100%);
            transition: all 0.3s ease;
        }
        
        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(122, 23, 55, 0.3);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    <%@ include file="Navegador.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4 max-w-4xl">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6 text-white">
                    <div class="flex items-center space-x-4">
                        <div class="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center">
                            <i class="fas fa-file-alt text-2xl text-white"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold">Documento Extenso 9/10</h1>
                            <p class="text-white/90 mt-1">Descarga la plantilla y sube tu documento final en PDF</p>
                        </div>
                    </div>
                </div>

                <!-- Formulario -->
                <form id="formPagina9" class="p-8 space-y-8">

                    <!-- Sección de descarga -->
                    <section class="space-y-6">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-download mr-2 text-[#7A1737]"></i>Paso 1: Descargar Plantilla
                        </h4>
                        <div class="bg-gradient-to-r from-yellow-50 to-amber-50 border-l-4 border-amber-400 p-6 rounded-lg">
                            <div class="flex items-start">
                                <i class="fas fa-lightbulb text-amber-500 text-2xl mr-4 mt-1"></i>
                                <div>
                                    <h3 class="font-semibold text-amber-800 text-lg mb-2">Recomendación Importante</h3>
                                    <p class="text-amber-700">
                                        Descarga y utiliza esta plantilla para garantizar que tu proyecto cumpla con todos los requisitos de formato establecidos por COVEICYDET.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <a href="/proyectos/plantillas/EjemploDocCOVEICYDET.docx" download
                               class="download-btn text-white font-bold py-4 px-8 rounded-xl inline-flex items-center justify-center text-lg transition-all duration-300">
                                <i class="fas fa-download mr-3 text-xl"></i>
                                <span>Descargar Plantilla Oficial</span>
                            </a>
                        </div>
                    </section>

                    <!-- Sección de subida -->
                    <section class="space-y-6 pt-6 border-t border-gray-200">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-upload mr-2 text-[#7A1737]"></i>Paso 2: Subir Documento Extenso
                        </h4>
                        <div class="flex flex-col space-y-2">
                            <label for="documentoExtenso" class="text-sm font-medium text-gray-700 flex items-center">
                                Sube el documento completo en formato PDF:
                            </label>
                            <input type="file" id="documentoExtenso" name="documentoExtenso" accept=".pdf"
                                   class="border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-[#7A1737]">
                            <p class="text-sm text-gray-500">Por favor, asegúrate de que el archivo esté en formato PDF. Tamaño máximo: 10MB.</p>
                            <div class="flex space-x-4 pt-2">
                                <button type="button" id="visualizarDocumentoBtn"
                                        class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center w-max">
                                    <i class="fas fa-eye mr-2"></i>Vista previa
                                </button>
                                <button type="button" id="subirDocumentoBtn"
                                        class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center w-max">
                                    <i class="fas fa-cloud-upload-alt mr-2"></i>Subir documento
                                </button>
                            </div>
                        </div>
                    </section>

                    <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-between">
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-8 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='registroProyecto8.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button" onclick="guardarBorrador('formPagina9', 'pagina9', this)"
                                    class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-3 px-8 rounded-lg transition duration-200 flex items-center justify-center">
                                <i class="fas fa-save mr-2"></i>Guardar Borrador
                            </button>
                        </div>
                        <button type="button" 
                                class="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-medium py-3 px-8 rounded-lg transition duration-200 flex items-center justify-center"
                                onclick="guardarBorrador('formPagina9', 'pagina9'); location.href='registroProyecto10.jsp'">
                            Siguiente
                            <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>
    
    <script>
        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            
            const documentoExtensoInput = document.getElementById('documentoExtenso');
            const nombreArchivo = documentoExtensoInput && documentoExtensoInput.files[0] 
                ? documentoExtensoInput.files[0].name 
                : '';
            
            const jsonData = {
                pagina9: {
                    doc_extenso: nombreArchivo,
                    plantilla_descargada: localStorage.getItem('plantilla_descargada') === 'true'
                }
            };
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(jsonData));
            if (targetBtn) {
                mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
            }
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                try {
                    const data = JSON.parse(savedData);
                    if (data.pagina9 && data.pagina9.doc_extenso) {
                        const documentoExtensoInput = document.getElementById('documentoExtenso');
                        if (documentoExtensoInput && !document.getElementById('archivoGuardadoMsg')) {
                            const mensaje = document.createElement('p');
                            mensaje.id = 'archivoGuardadoMsg';
                            mensaje.className = 'text-sm text-blue-600 mt-2';
                            mensaje.innerHTML = '<i class="fas fa-info-circle mr-1"></i>Archivo guardado anteriormente: <strong>' + data.pagina9.doc_extenso + '</strong>';
                            documentoExtensoInput.parentElement.insertBefore(mensaje, documentoExtensoInput.nextSibling);
                        }
                    }
                } catch(e) {
                    console.error("Error al cargar borrador:", e);
                }
            }
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border fixed ';

            if (tipo === 'success') baseClasses += 'bg-green-100 text-green-800 border-green-200';
            else if (tipo === 'error') baseClasses += 'bg-red-100 text-red-800 border-red-200';
            else baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                // Posicionamiento sobre el botón (tooltip style)
                messageDiv.style.position = 'absolute';
                document.body.appendChild(messageDiv);
                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                let top = rect.top + scrollTop - messageDiv.offsetHeight - 8;
                let left = rect.left + (rect.width - messageDiv.offsetWidth) / 2;
                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
            } else {
                // Posicionamiento fijo en la esquina
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        window.addEventListener('load', function() {
            cargarBorrador('formPagina9', 'pagina9');

            const downloadBtn = document.querySelector('.download-btn');
            if (downloadBtn) {
                downloadBtn.addEventListener('click', function() {
                    localStorage.setItem('plantilla_descargada', 'true');
                });
            }

            // Lógica de cambios sin guardar
            const form = document.getElementById('formPagina9');
            let saved = true;
            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        console.log('Formulario pagina9 modificado');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                window.addEventListener('beforeunload', function(e){
                    if(!saved){
                        var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                        e.preventDefault(); e.returnValue = msg; return msg;
                    }
                });
            }
        });
    </script>
</body>
</html>