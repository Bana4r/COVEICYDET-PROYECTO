<%@ page language="java" contentType="application/json; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.File, java.util.logging.Logger" %>

<%
    String jsonResponse = "";
    Logger logger = Logger.getLogger("deleteFile.jsp");

    try {
        // 1. Obtener la URL del archivo que se quiere borrar
        String fileUrl = request.getParameter("fileUrl");
        if (fileUrl == null || fileUrl.isEmpty()) {
            throw new Exception("No se especificó la URL del archivo (fileUrl).");
        }

        // 2. Obtener la ruta base de la aplicación
        // (Ej: /var/lib/tomcat9/webapps/proyectos/)
        String appPath = request.getServletContext().getRealPath("/");
        File safeUploadDir = new File(appPath + "uploads");
        String safeUploadDirCanonicalPath = safeUploadDir.getCanonicalPath();

        // 3. Obtener el nombre del archivo de la URL
        String fileName = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);

        // 4. Sanear el nombre del archivo (medida de seguridad)
        if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
            throw new SecurityException("Nombre de archivo no válido.");
        }

        // 5. Reconstruir la ruta absoluta y segura del archivo
        File fileToDelete = new File(safeUploadDir, fileName);
        String fileToDeleteCanonicalPath = fileToDelete.getCanonicalPath();

        // 6. ¡Verificación de seguridad CRÍTICA!
        // Asegurarse de que el archivo a borrar ESTÉ DENTRO de la carpeta /uploads
        if (!fileToDeleteCanonicalPath.startsWith(safeUploadDirCanonicalPath)) {
            throw new SecurityException("Intento de Path Traversal detectado. Operación denegada.");
        }

        // 7. Borrar el archivo
        if (fileToDelete.exists()) {
            if (fileToDelete.delete()) {
                // Éxito
                jsonResponse = "{\"success\": true, \"message\": \"Archivo eliminado exitosamente.\"}";
            } else {
                // Falló el borrado (ej. permisos)
                throw new Exception("No se pudo eliminar el archivo del servidor.");
            }
        } else {
            // El archivo ya no existía (lo cual está bien)
            jsonResponse = "{\"success\": true, \"message\": \"El archivo ya no existía.\"}";
        }

    } catch (Exception e) {
        logger.severe("Error al eliminar archivo: " + e.getMessage());
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        jsonResponse = String.format("{\"success\": false, \"message\": \"Error: %s\"}", 
            e.getMessage().replace("\"", "\\\"")
        );
    }

    // 8. Enviar la respuesta JSON al cliente
    response.getWriter().write(jsonResponse);
%>