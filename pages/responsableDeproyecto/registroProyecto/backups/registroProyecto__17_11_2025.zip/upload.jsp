<%@ page language="java" contentType="application/json; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.io.*, java.util.*, javax.servlet.http.*" %>
<%@ page import="java.nio.file.Paths" %>
<%@ page import="java.util.Base64" %>

<%
    // 1. Obtiene la ruta real de tu aplicación en el servidor
    // Esto será /var/lib/tomcat9/webapps/proyectos/
    String appPath = request.getServletContext().getRealPath("/");

    // 2. Define la carpeta de subidas DENTRO de la aplicación
    String UPLOAD_DIRECTORY = appPath + "uploads";
    // -----------------------------------------

    String jsonResponse = "";

    try {
        // 1. Obtener los parámetros de texto (NO usamos getPart)
        String base64Data = request.getParameter("fileData");
        String originalFileName = request.getParameter("fileName");

        if (base64Data == null || base64Data.isEmpty() || originalFileName == null || originalFileName.isEmpty()) {
            throw new Exception("No se recibieron datos de archivo (fileData o fileName están vacíos).");
        }

        // 2. Limpiar el string Base64 (quitar el prefijo "data:application/pdf;base64,")
        String base64String = base64Data.substring(base64Data.indexOf(',') + 1);
        
        // 3. Decodificar el string Base64 a bytes
        byte[] fileBytes = Base64.getDecoder().decode(base64String);

        // 4. Crear un nombre de archivo único
        String uniqueID = UUID.randomUUID().toString();
        String fileExtension = "";
        int i = originalFileName.lastIndexOf('.');
        if (i > 0) {
            fileExtension = originalFileName.substring(i);
        }
        String uniqueFileName = uniqueID + fileExtension;
        
        // 5. Definir la ruta completa de guardado
        File uploadDir = new File(UPLOAD_DIRECTORY);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs(); // Intentar crear el directorio si no existe
        }
        File file = new File(UPLOAD_DIRECTORY + File.separator + uniqueFileName);

        // 6. Guardar los bytes en el archivo del servidor
        try (OutputStream output = new FileOutputStream(file)) {
            output.write(fileBytes);
        }
        
        // 7. Preparar la respuesta JSON de éxito
        // En lugar de la ruta absoluta del disco, creamos la URL web
        String webUrl = request.getContextPath() + "/uploads/" + uniqueFileName;
        
        jsonResponse = String.format("{\"success\": true, \"webUrl\": \"%s\", \"originalName\": \"%s\"}",
            webUrl.replace("\\", "\\\\"), // Devolvemos la URL web
            originalFileName.replace("\"", "\\\"")
        );

    } catch (Exception e) {
        // 8. Preparar la respuesta JSON de error
        jsonResponse = String.format("{\"success\": false, \"message\": \"Error: %s\"}", 
            e.getMessage().replace("\"", "\\\"")
        );
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }

    // 9. Enviar la respuesta JSON al cliente
    response.getWriter().write(jsonResponse);
%>