<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Resumen y Envío - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
            resize: vertical;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .word-counter {
            font-size: 0.875rem;
            margin-top: 0.5rem;
            text-align: right;
            padding: 0.25rem 0.5rem;
            background-color: #f8fafc;
            border-radius: 0.25rem;
            border: 1px solid #e2e8f0;
            font-weight: 500;
        }
        
        .word-counter.warning {
            color: #dc2626;
            background-color: #fef2f2;
            border-color: #fecaca;
        }
        
        .word-counter.success {
            color: #16a34a;
            background-color: #f0fdf4;
            border-color: #bbf7d0;
        }
        
        .textarea-container {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    <%@ include file="Navegador.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-file-contract mr-3"></i>Resumen y Envío 10/10
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Revise la información y envíe su proyecto.
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formPagina10" class="p-8 space-y-8">

                    <!-- Aquí va el contenido del formulario -->
                    <section class="space-y-6">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-check-circle mr-2 text-[#7A1737]"></i>Finalizar
                        </h4>
                        <p>Ha completado todos los pasos. Puede guardar un último borrador o enviar el proyecto para su revisión.</p>
                    </section>

                        <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formPagina10', 'pagina10', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar Borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto9.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button" id="enviarProyectoBtn"
                                    class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                                <i class="fas fa-paper-plane mr-2"></i>Enviar Proyecto
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>
    
    <script>
        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey, targetBtn) {
            const jsonData = {
                pagina10: {} // No hay campos en esta página, pero se guarda para el flujo
            };
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(jsonData));
            // mostrar mensaje posicionado sobre el botón si se pasó targetBtn
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            // No hay datos que cargar para esta página, pero la función se mantiene por consistencia
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir control de navegación y protección contra abandono
        window.addEventListener('load', function() {
            cargarBorrador('formPagina10', 'pagina10');

            const KEY = 'proyecto_borrador_pagina10_saved';
            const form = document.getElementById('formPagina10');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const enviarBtn = document.getElementById('enviarProyectoBtn') || buttons.find(b => /enviar proyecto/i.test(b.textContent));

            function setDisabled(btn, disabled){
                if(!btn) return;
                // No usar disabled real para que los eventos sigan funcionando
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                btn.setAttribute('data-disabled', disabled ? 'true' : 'false');
                if(disabled) {
                    btn.classList.add('opacity-60', 'cursor-not-allowed');
                    btn.classList.remove('hover:bg-green-700');
                } else {
                    btn.classList.remove('opacity-60', 'cursor-not-allowed');
                    btn.classList.add('hover:bg-green-700');
                }
            }

            if(!guardarBtn || !enviarBtn){
                console.warn('No se encontraron botones Guardar/Enviar en página10');
            }

            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(enviarBtn, !saved);

            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1');
                    saved = true;
                    setDisabled(enviarBtn, false);
                    console.log('Borrador pagina10 guardado -> Enviar habilitado');
                });
            }

            // Agregar evento al botón enviar para manejar navegación y advertencias
            if(enviarBtn){
                enviarBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Verificar si está "deshabilitado" (visualmente)
                    if(enviarBtn.getAttribute('data-disabled') === 'true'){
                        mostrarMensaje('Debe guardar el borrador antes de enviar el proyecto', 'error', enviarBtn);
                        return false;
                    }
                    
                    // Si está habilitado, consolidar datos de las 10 páginas y enviar
                    guardarBorrador('formPagina10', 'pagina10', guardarBtn);
                    enviarProyectoCompleto();
                });
            }
            
            // Función para consolidar y enviar el proyecto completo
            function enviarProyectoCompleto() {
                try {
                    // Consolidar datos de todas las páginas desde localStorage
                    const datosCompletos = {
                        pagina1: {}, pagina2: {}, pagina3: {}, pagina4: {},
                        pagina5: {}, pagina6: {}, pagina7: {}, pagina8: {},
                        pagina9: {}, pagina10: {}
                    };
                    
                    // Cargar datos de cada página
                    for (let i = 1; i <= 10; i++) {
                        const key = 'proyecto_borrador_pagina' + i;
                        const savedData = localStorage.getItem(key);
                        
                        if (savedData) {
                            try {
                                const pageData = JSON.parse(savedData);
                                const pageKey = 'pagina' + i;
                                
                                // Extraer los datos de la página específica
                                if (pageData[pageKey]) {
                                    datosCompletos[pageKey] = pageData[pageKey];
                                } else {
                                    // Si el formato es diferente, tomar todo el objeto
                                    datosCompletos[pageKey] = pageData;
                                }
                            } catch (parseError) {
                                console.error('Error al parsear datos de página ' + i + ':', parseError);
                                datosCompletos['pagina' + i] = {};
                            }
                        } else {
                            console.warn('No se encontraron datos guardados para página ' + i);
                        }
                    }
                    
                    // Validar que hay datos para enviar
                    let tieneDatos = false;
                    for (let i = 1; i <= 10; i++) {
                        const pageKey = 'pagina' + i;
                        if (datosCompletos[pageKey] && Object.keys(datosCompletos[pageKey]).length > 0) {
                            tieneDatos = true;
                            break;
                        }
                    }
                    
                    if (!tieneDatos) {
                        mostrarMensaje('No se encontraron datos del proyecto para enviar', 'error', enviarBtn);
                        return;
                    }
                    
                    console.log('📦 Datos consolidados del proyecto:', datosCompletos);
                    
                    // Crear formulario oculto para enviar datos
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '/proyectos/pages/responsableDeproyecto/registroProyecto/procesarProyecto.jsp';
                    
                    // Crear input oculto con JSON consolidado
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'datosProyecto';
                    input.value = JSON.stringify(datosCompletos);
                    
                    form.appendChild(input);
                    document.body.appendChild(form);
                    
                    // Mostrar mensaje de envío
                    mostrarMensaje('📤 Enviando proyecto completo...', 'info');
                    
                    // Enviar formulario
                    setTimeout(function() {
                        form.submit();
                    }, 500);
                    
                } catch (error) {
                    console.error('❌ Error al enviar proyecto:', error);
                    mostrarMensaje('Error al procesar el proyecto: ' + error.message, 'error', enviarBtn);
                }
            }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        setDisabled(enviarBtn, true);
                        console.log('Formulario pagina10 modificado después de guardar: Enviar bloqueado');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                // beforeunload
                window.addEventListener('beforeunload', function(e){
                    try{
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault(); e.returnValue = msg; return msg;
                        }
                    }catch(err){ return undefined; }
                });
            }
        });
    </script>
</body>
</html>
