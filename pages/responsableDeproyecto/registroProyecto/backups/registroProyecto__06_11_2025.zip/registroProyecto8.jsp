<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro Proyecto - COVEICYDET</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    .word-counter {
      font-size: 0.75rem;
      color: #6b7280;
      text-align: right;
      margin-top: 0.25rem;
    }
    .word-counter.warning {
      color: #dc2626;
      font-weight: 600;
    }
    .justificacion-textarea.limit-reached {
      border-color: #dc2626;
      background-color: #fef2f2;
    }
    .partida-input {
      border: 1px solid #d1d5db;
      border-radius: 0.375rem;
      padding: 0.5rem;
      text-align: right;
    }
    .partida-input:focus {
      outline: none;
      border-color: #3b82f6;
      ring: 2px;
      ring-color: #3b82f6;
    }
    .input-wrapper {
      position: relative;
      display: inline-block;
      width: 100%;
    }
    .total-input {
      padding: 0.5rem;
      text-align: right;
    }
    .total-wrapper {
      position: relative;
      display: inline-block;
      width: 100%;
    }
  </style>
</head>
<%@ include file="../header.jsp" %>
<body class="bg-gray-50 min-h-screen antialiased">
    <div class="max-w-7xl mx-auto px-4 py-10">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-[#B28854] p-6">
                <h1 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-box-open mr-3"></i>Partidas 8/9
                </h1>
                <p class="text-white/90 mt-2">Desglose las partidas utilizadas durante el desarrollo del proyecto</p>
            </div>
            
            <form id="formPagina5" class="p-8 space-y-8" action="#" method="post">
                <div class="space-y-6">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">Gasto corriente</h2>
                        
                        <div class="overflow-x-auto">
                            <table class="min-w-full border-collapse border border-gray-300">
                                <thead>
                                    <tr class="bg-gray-100">
                                        <th class="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Información de las partidas</th>
                                        <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Semestre 1</th>
                                        <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Semestre 2</th>
                                        <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Total</th>
                                        <th class="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Justificación de partida<br><span class="text-xs font-normal"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Pasajes y viáticos -->
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Pasajes y viáticos</td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="pasajesViaticos_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="pasajesViaticos" data-semestre="s1">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="pasajesViaticos_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="pasajesViaticos" data-semestre="s2">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="total-wrapper">
                                                <input type="text" name="pasajesViaticos_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <textarea name="pasajesViaticos_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                            <div class="word-counter" data-for="pasajesViaticos_justificacion">0/200 palabras</div>
                                        </td>
                                    </tr>
                                    
                                    <!-- Gastos de operación -->
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Gastos de operación</td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="gastosOperacion_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="gastosOperacion" data-semestre="s1">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="gastosOperacion_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="gastosOperacion" data-semestre="s2">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="total-wrapper">
                                                <input type="text" name="gastosOperacion_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <textarea name="gastosOperacion_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                            <div class="word-counter" data-for="gastosOperacion_justificacion">0/200 palabras</div>
                                        </td>
                                    </tr>
                                    
                                    <!-- Gastos de trabajo de campo -->
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Gastos de trabajo de campo</td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="gastosTrabajoCampo_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="gastosTrabajoCampo" data-semestre="s1" id="gastosTrabajoCampo_s1">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="gastosTrabajoCampo_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="gastosTrabajoCampo" data-semestre="s2" id="gastosTrabajoCampo_s2">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="total-wrapper">
                                                <input type="text" name="gastosTrabajoCampo_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <textarea name="gastosTrabajoCampo_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                            <div class="word-counter" data-for="gastosTrabajoCampo_justificacion">0/200 palabras</div>
                                        </td>
                                    </tr>
                                    
                                    <!-- Indicador de límite para Gastos de trabajo de campo -->
                                    <tr>
                                        <td colspan="5" class="border border-gray-300 px-4 py-2 bg-gray-50">
                                            <div id="indicadorLimiteGastosCampo" class="text-sm">
                                                <span class="font-medium">Límite de gastos de trabajo de campo:</span>
                                                <span id="limiteTexto" class="ml-2">Máximo permitido: $0.00 (10% del presupuesto total)</span>
                                                <span id="actualTexto" class="ml-4">Actual: $0.00 (0.00%)</span>
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <!-- Estudiantes incorporados -->
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Estudiantes incorporados</td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="estudiantesIncorporados_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="estudiantesIncorporados" data-semestre="s1">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="input-wrapper">
                                                <input type="text" name="estudiantesIncorporados_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="estudiantesIncorporados" data-semestre="s2">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="total-wrapper">
                                                <input type="text" name="estudiantesIncorporados_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <textarea name="estudiantesIncorporados_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                            <div class="word-counter" data-for="estudiantesIncorporados_justificacion">0/200 palabras</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- total de gasto corriente -->
                            <!--<div class="flex justify-end mt-4">
                                <label class="text-lg font-semibold text-gray-800 mr-4">Total de gasto corriente:</label>
                                <input type="number" id="totalGastoCorriente" name="totalGastoCorriente" class="w-1/4 border border-gray-300 rounded-md shadow-sm p-2 bg-gray-100 text-gray-700 font-semibold" value="0.00" readonly>
                            </div>-->
                        </div>
                        
                        <!-- Sección de gastos de inversión -->
                        <div class="mt-8">
                            <h2 class="text-xl font-semibold text-gray-800 mb-4">Gasto de inversión</h2>
                            
                            <div class="overflow-x-auto">
                                <table class="min-w-full border-collapse border border-gray-300">
                                    <thead>
                                        <tr class="bg-gray-100">
                                            <th class="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Información de las partidas</th>
                                            <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Semestre 1</th>
                                            <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Semestre 2</th>
                                            <th class="border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-700">Total</th>
                                                                                        <th class="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Justificación de partida<br><span class="text-xs font-normal">Descripción del bien o servicio y justificación</span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Adquisiciones de instrumentos y equipo de laboratorio -->
                                        <tr>
                                            <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Adquisiciones de instrumentos y equipo de laboratorio</td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="input-wrapper">
                                                    <input type="text" name="adquisicionesInstrumentosEquipoLaboratorio_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="adquisicionesInstrumentosEquipoLaboratorio" data-semestre="s1">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="input-wrapper">
                                                    <input type="text" name="adquisicionesInstrumentosEquipoLaboratorio_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="adquisicionesInstrumentosEquipoLaboratorio" data-semestre="s2">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="total-wrapper">
                                                    <input type="text" name="adquisicionesInstrumentosEquipoLaboratorio_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <textarea name="adquisicionesInstrumentosEquipoLaboratorio_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                                <div class="word-counter" data-for="adquisicionesInstrumentosEquipoLaboratorio_justificacion">0/200 palabras</div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Adquisición de equipos para planta piloto -->
                                        <tr>
                                            <td class="border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Adquisición de equipos para planta piloto</td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="input-wrapper">
                                                    <input type="text" name="adquisicionEquiposPlantaPiloto_s1" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="adquisicionEquiposPlantaPiloto" data-semestre="s1">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="input-wrapper">
                                                    <input type="text" name="adquisicionEquiposPlantaPiloto_s2" class="w-full partida-input" placeholder="0.00" value="$0.00" data-partida="adquisicionEquiposPlantaPiloto" data-semestre="s2">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <div class="total-wrapper">
                                                    <input type="text" name="adquisicionEquiposPlantaPiloto_total" class="w-full border-0 focus:ring-0 bg-gray-100 font-semibold total-input" readonly value="$0.00">
                                                </div>
                                            </td>
                                            <td class="border border-gray-300 px-4 py-2">
                                                <textarea name="adquisicionEquiposPlantaPiloto_justificacion" class="w-full border border-gray-300 rounded p-2 text-sm justificacion-textarea" rows="2" placeholder="Descripción del bien o servicio y justificación"></textarea>
                                                <div class="word-counter" data-for="adquisicionEquiposPlantaPiloto_justificacion">0/200 palabras</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- total -->
                <div class="flex items-center space-x-4">
                    <label class="w-1/2 text-lg font-semibold text-gray-800">Total presupuesto del proyecto:</label>
                    <div class="total-wrapper w-1/2">
                        <input type="text" id="totalPresupuesto" name="totalPresupuesto" class="w-full border border-gray-300 rounded-md shadow-sm p-2 bg-gray-100 text-gray-700 font-semibold total-input" value="$0.00" readonly>
                    </div>
                </div>

                <!-- Botones de acción -->
                <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formPagina2', 'pagina2', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto7.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    id="btnSiguiente">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
            </form>
        </div>
    </div>

    <script>
        // ========== CONFIGURACIÓN INICIAL ==========
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Inicializando formulario...');
            setupCalculos();
            setupContadoresPalabras();
            setupFormatoMoneda();
            cargarBorrador();
            setupNavegacion();
        });

        // ========== FORMATO DE MONEDA ==========
        function formatearMoneda(valor) {
            // Convertir a número y validar
            const numero = parseFloat(valor) || 0;
            
            // Formatear con separador de miles y 2 decimales
            return '$' + numero.toLocaleString('es-MX', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function extraerNumero(valorFormateado) {
            // Remover el símbolo $ y las comas, convertir a número
            return parseFloat(valorFormateado.replace(/[$,]/g, '')) || 0;
        }

        function setupFormatoMoneda() {
            const inputs = document.querySelectorAll('.partida-input');
            
            inputs.forEach(input => {
                // Formatear al perder el foco
                input.addEventListener('blur', function() {
                    const numero = extraerNumero(this.value);
                    this.value = formatearMoneda(numero);
                });

                // Limpiar formato al obtener el foco para facilitar edición
                input.addEventListener('focus', function() {
                    const numero = extraerNumero(this.value);
                    if (numero === 0) {
                        this.value = '';
                    } else {
                        this.value = numero.toFixed(2);
                    }
                });

                // Validar que solo se ingresen números
                input.addEventListener('input', function(e) {
                    let valor = this.value;
                    // Permitir solo números, punto decimal y comas
                    valor = valor.replace(/[^0-9.]/g, '');
                    // Permitir solo un punto decimal
                    const partes = valor.split('.');
                    if (partes.length > 2) {
                        valor = partes[0] + '.' + partes.slice(1).join('');
                    }
                    this.value = valor;
                });
            });
        }

        // ========== CÁLCULOS AUTOMÁTICOS ==========
        function setupCalculos() {
            const inputs = document.querySelectorAll('.partida-input');
            inputs.forEach(input => {
                input.addEventListener('input', calcularTodo);
                input.addEventListener('blur', calcularTodo);
            });
        }

        function calcularTodo() {
            const partidas = [
                'pasajesViaticos', 'gastosOperacion', 
                'gastosTrabajoCampo', 
                'estudiantesIncorporados',
                'adquisicionesInstrumentosEquipoLaboratorio', 
                'adquisicionEquiposPlantaPiloto'
            ];

            let totalGeneral = 0;

            partidas.forEach(partida => {
                const inputS1 = document.querySelector('[name="' + partida + '_s1"]');
                const inputS2 = document.querySelector('[name="' + partida + '_s2"]');
                const inputTotal = document.querySelector('[name="' + partida + '_total"]');
                
                const s1 = extraerNumero(inputS1.value);
                const s2 = extraerNumero(inputS2.value);
                const total = s1 + s2;
                
                inputTotal.value = formatearMoneda(total);
                totalGeneral += total;
            });

            document.getElementById('totalPresupuesto').value = formatearMoneda(totalGeneral);
            
            // Actualizar indicador de límite de gastos de campo
            actualizarIndicadorLimiteGastosCampo();
        }

        // ========== VALIDACIÓN DE LÍMITE DE GASTOS DE CAMPO ==========
        function validarLimiteGastosCampo() {
            const totalPresupuesto = extraerNumero(document.getElementById('totalPresupuesto').value);
            const limitePermitido = totalPresupuesto * 0.10; // 10%
            
            const gastosCampoS1 = extraerNumero(document.querySelector('[name="gastosTrabajoCampo_s1"]').value);
            const gastosCampoS2 = extraerNumero(document.querySelector('[name="gastosTrabajoCampo_s2"]').value);
            const totalGastosCampo = gastosCampoS1 + gastosCampoS2;
            
            return {
                valido: totalGastosCampo <= limitePermitido,
                totalGastosCampo: totalGastosCampo,
                limitePermitido: limitePermitido,
                porcentaje: totalPresupuesto > 0 ? (totalGastosCampo / totalPresupuesto * 100) : 0
            };
        }

        function actualizarIndicadorLimiteGastosCampo() {
            const validacion = validarLimiteGastosCampo();
            const limiteTexto = document.getElementById('limiteTexto');
            const actualTexto = document.getElementById('actualTexto');
            const indicador = document.getElementById('indicadorLimiteGastosCampo');
            
            if (!limiteTexto || !actualTexto || !indicador) return;
            
            limiteTexto.textContent = 'Máximo permitido: ' + formatearMoneda(validacion.limitePermitido) + ' (10% del presupuesto total)';
            actualTexto.textContent = 'Actual: ' + formatearMoneda(validacion.totalGastosCampo) + ' (' + validacion.porcentaje.toFixed(2) + '%)';
            
            // Cambiar color según el porcentaje
            actualTexto.classList.remove('text-green-600', 'text-yellow-600', 'text-red-600', 'font-semibold');
            
            if (validacion.porcentaje > 10) {
                // Excede el límite
                actualTexto.classList.add('text-red-600', 'font-semibold');
                indicador.classList.remove('bg-gray-50', 'bg-yellow-50');
                indicador.classList.add('bg-red-50');
            } else if (validacion.porcentaje >= 8) {
                // Cerca del límite (8-10%)
                actualTexto.classList.add('text-yellow-600', 'font-semibold');
                indicador.classList.remove('bg-gray-50', 'bg-red-50');
                indicador.classList.add('bg-yellow-50');
            } else {
                // Dentro del límite
                actualTexto.classList.add('text-green-600');
                indicador.classList.remove('bg-yellow-50', 'bg-red-50');
                indicador.classList.add('bg-gray-50');
            }
        }

        // ========== CONTADOR DE PALABRAS ==========
        function setupContadoresPalabras() {
            const textareas = document.querySelectorAll('.justificacion-textarea');
            textareas.forEach(textarea => {
                actualizarContador(textarea);
                textarea.addEventListener('input', function() {
                    actualizarContador(this);
                });
            });
        }

        function actualizarContador(textarea) {
            const texto = textarea.value.trim();
            const palabras = texto === '' ? 0 : texto.split(/\s+/).length;
            const maxPalabras = 200;
            
            const counter = document.querySelector('.word-counter[data-for="' + textarea.name + '"]');
            if (counter) {
                counter.textContent = palabras + '/' + maxPalabras + ' palabras';
                
                if (palabras > maxPalabras) {
                    counter.classList.add('warning');
                    textarea.classList.add('limit-reached');
                } else {
                    counter.classList.remove('warning');
                    textarea.classList.remove('limit-reached');
                }
            }
        }

        // ========== GUARDAR Y CARGAR ==========
        function guardarBorrador(formId, pageKey, targetBtn) {
            // Primero validar el límite de gastos de campo
            const validacion = validarLimiteGastosCampo();
            
            if (!validacion.valido && validacion.totalGastosCampo > 0) {
                const mensaje = 'Los gastos de trabajo de campo (' + formatearMoneda(validacion.totalGastosCampo) + ') ' +
                               'exceden el 10% del presupuesto total.\n' +
                               'Máximo permitido: ' + formatearMoneda(validacion.limitePermitido) + ' ' +
                               '(Actualmente: ' + validacion.porcentaje.toFixed(2) + '%)';
                
                mostrarMensaje(mensaje, 'error', targetBtn);
                
                // Resaltar los campos problemáticos
                const campo1 = document.getElementById('gastosTrabajoCampo_s1');
                const campo2 = document.getElementById('gastosTrabajoCampo_s2');
                
                campo1.classList.add('border-red-500', 'bg-red-50');
                campo2.classList.add('border-red-500', 'bg-red-50');
                
                // Remover el resaltado después de 5 segundos
                setTimeout(function() {
                    campo1.classList.remove('border-red-500', 'bg-red-50');
                    campo2.classList.remove('border-red-500', 'bg-red-50');
                }, 5000);
                
                return false; // No guardar
            }
            
            // Si pasa la validación, guardar normalmente
            const datos = {};
            const inputs = document.querySelectorAll('#formPagina5 input, #formPagina5 textarea');
            
            inputs.forEach(input => {
                // Si es un input de partida, guardar el valor numérico
                if (input.classList.contains('partida-input') || input.classList.contains('total-input')) {
                    datos[input.name] = extraerNumero(input.value);
                } else {
                    datos[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_pagina5', JSON.stringify(datos));
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador() {
            const saved = localStorage.getItem('proyecto_borrador_pagina5');
            if (saved) {
                const datos = JSON.parse(saved);
                Object.keys(datos).forEach(key => {
                    const elemento = document.querySelector('[name="' + key + '"]');
                    if (elemento) {
                        // Si es un input de moneda, formatear el valor
                        if (elemento.classList.contains('partida-input')) {
                            elemento.value = formatearMoneda(datos[key]);
                        } else if (elemento.classList.contains('total-input')) {
                            elemento.value = formatearMoneda(datos[key]);
                        } else {
                            elemento.value = datos[key];
                        }
                    }
                });
                calcularTodo();
                setupContadoresPalabras();
            }
        }

        // ========== MENSAJES ==========
        function mostrarMensaje(texto, tipo, targetEl) {
            const mensajesExistentes = document.querySelectorAll('.mensaje-temporal');
            mensajesExistentes.forEach(function(msg) {
                msg.remove();
            });
            
            const div = document.createElement('div');
            var clases = 'font-medium mensaje-temporal ';
            
            if (tipo === 'success') {
                clases += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                clases += 'bg-red-100 text-red-800 border-red-200';
            } else {
                clases += 'bg-blue-100 text-blue-800 border-blue-200';
            }
            
            div.className = clases + ' p-4 rounded-md shadow-lg z-50 border';
            div.textContent = texto;

            if (targetEl && targetEl.getBoundingClientRect) {
                div.style.position = 'absolute';
                div.style.visibility = 'hidden';
                document.body.appendChild(div);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = div.offsetWidth;
                const mh = div.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                div.style.left = left + 'px';
                div.style.top = top + 'px';
                div.style.visibility = 'visible';
            } else {
                div.style.position = 'fixed';
                div.style.top = '1rem';
                div.style.right = '1rem';
                document.body.appendChild(div);
            }
            
            setTimeout(function() {
                if (div.parentNode) {
                    div.parentNode.removeChild(div);
                }
            }, 4000);
        }

        // ========== CONTROL DE NAVEGACIÓN ==========
        function setupNavegacion() {
            const KEY = 'proyecto_borrador_pagina5_saved';
            const form = document.getElementById('formPagina5');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const siguienteBtn = document.getElementById('btnSiguiente') || buttons.find(b => /siguiente/i.test(b.textContent));

            function setDisabled(btn, disabled){
                if(!btn) return;
                // No usar disabled real para que los eventos sigan funcionando
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                btn.setAttribute('data-disabled', disabled ? 'true' : 'false');
                if(disabled) {
                    btn.classList.add('opacity-60', 'cursor-not-allowed');
                    btn.classList.remove('hover:bg-[#5c0f2a]');
                } else {
                    btn.classList.remove('opacity-60', 'cursor-not-allowed');
                    btn.classList.add('hover:bg-[#5c0f2a]');
                }
            }

            if(!guardarBtn || !siguienteBtn){
                console.warn('No se encontraron botones Guardar/Siguiente en página5');
            }

            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(siguienteBtn, !saved);

            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1');
                    saved = true;
                    setDisabled(siguienteBtn, false);
                    console.log('Borrador pagina5 guardado -> Siguiente habilitado');
                });
            }

            // Agregar evento al botón siguiente para manejar navegación y advertencias
            if(siguienteBtn){
                siguienteBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Verificar si está "deshabilitado" (visualmente)
                    if(siguienteBtn.getAttribute('data-disabled') === 'true'){
                        mostrarMensaje('Debe guardar el borrador antes de continuar', 'error', siguienteBtn);
                        return false;
                    }
                    
                    // Si está habilitado, navegar a la siguiente página
                    window.location.href = '/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto9.jsp';
                });
            }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        setDisabled(siguienteBtn, true);
                        console.log('Formulario pagina5 modificado después de guardar: Siguiente bloqueado');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                // beforeunload
                window.addEventListener('beforeunload', function(e){
                    try{
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault(); e.returnValue = msg; return msg;
                        }
                    }catch(err){ return undefined; }
                });
            }
        }
    </script>
    <%@ include file="/footer.jsp" %>
</body>
</html>