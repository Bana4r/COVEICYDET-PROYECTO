<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Planeación y evaluación - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .semestre-section {
            transition: all 0.2s ease;
            border-radius: 0.5rem;
            overflow: visible;
        }
        
        .semestre-section:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        
        .input-focus:focus {
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.1);
        }
        
        .semestre-header {
            background: linear-gradient(135deg, #7A1737, #9D5B64);
            color: white;
            border-radius: 0.5rem 0.5rem 0 0;
        }

        /* Título grande y visible que estará por encima del header para evitar recortes */
        .semestre-visible {
            padding: 0.75rem 1rem;
            background: transparent;
            color: #1f2937; /* gris oscuro para contraste */
        }

        .semestre-visible h3 {
            color: #111827; /* asegurar contraste */
            font-weight: 700;
            margin: 0;
            z-index: 60;
            position: relative;
        }

        /* Separación superior para evitar que el header oscuro lo solape visualmente */
        .semestre-section { margin-top: 0.75rem; }

        .semestre-pill-visible {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #fff;
            color: #7A1737;
            border-radius: 999px;
            padding: 0.25rem 0.6rem;
            font-weight: 700;
            box-shadow: 0 1px 3px rgba(0,0,0,0.06);
            margin-right: 0.5rem;
        }
        
        .badge-semestre {
            background-color: #B28854;
            color: white;
            border-radius: 1rem;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
            min-width: 84px;
            text-align: center;
        }
        
        .table-actividades {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table-actividades th {
            background-color: #7A1737;
            color: white;
            padding: 0.75rem;
            text-align: left;
            font-weight: 600;
        }
        
        .table-actividades td {
            padding: 0.75rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-actividades tr:hover {
            background-color: #f9fafb;
        }
        
        .btn-remove {
            background-color: #dc2626;
            color: white;
            transition: all 0.2s ease;
        }
        
        .btn-remove:hover {
            background-color: #b91c1c;
            transform: translateY(-1px);
        }
        
        /* ESTILOS PARA ENTREGABLES */
        .entregables-container {
            position: relative;
            width: 100%;
        }
        
        .entregables-trigger {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            background-color: white;
            cursor: pointer;
            font-size: 0.875rem;
            color: #6b7280;
            text-align: left;
            margin-bottom: 0.5rem;
        }
        
        .entregables-trigger.has-selection {
            color: #374151;
            font-weight: 500;
            border-color: #7A1737;
            background-color: #fef2f2;
        }
        
        .entregables-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 50;
            max-height: 300px;
            overflow-y: auto;
            padding: 1rem;
        }
        
        .entregables-dropdown.show {
            display: block;
        }
        
        .entregable-group {
            margin-bottom: 1rem;
        }
        
        .entregable-group-title {
            font-weight: 600;
            color: #7A1737;
            font-size: 0.875rem;
            padding: 0.5rem 0.25rem;
            margin-bottom: 0.5rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .entregable-item {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 0.25rem;
            transition: background-color 0.2s;
        }
        
        .entregable-item:hover {
            background-color: #f3f4f6;
        }
        
        .entregable-checkbox {
            margin-right: 0.75rem;
            width: 16px;
            height: 16px;
        }
        
        .entregable-label {
            font-size: 0.875rem;
            color: #374151;
            cursor: pointer;
            flex: 1;
        }
        
        /* CONTENEDOR PARA ETIQUETAS VISIBLES */
        .selected-tags-container {
            min-height: 60px;
            padding: 0.75rem;
            background-color: #f8fafc;
            border-radius: 0.375rem;
            border: 1px solid #e5e7eb;
        }
        
        .selected-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .selected-tag {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #7A1737, #9D5B64);
            color: white;
            padding: 0.5rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.8rem;
            font-weight: 500;
            gap: 0.5rem;
            max-width: 240px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .remove-tag {
            margin-left: 0.5rem;
            cursor: pointer;
            width: 16px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.3);
            transition: background-color 0.2s;
            font-size: 0.7rem;
        }

        /* Asegurar texto visible dentro de la etiqueta */
        .selected-tag .tag-text {
            display: inline-block;
            color: white;
            font-size: 0.85rem;
            line-height: 1;
            max-width: 180px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .remove-tag:hover {
            background-color: rgba(255, 255, 255, 0.5);
        }
        
        .entregables-counter {
            font-size: 0.75rem;
            color: #6b7280;
            margin-top: 0.5rem;
            text-align: center;
        }
        
        .entregables-counter.has-selection {
            color: #7A1737;
            font-weight: 500;
        }
        
        .empty-selection {
            color: #9ca3af;
            font-style: italic;
            text-align: center;
            padding: 0.5rem;
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
            resize: vertical;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-calendar-alt mr-3"></i>Cronograma de Actividades 7/9
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Complete cada sección (todos los campos son necesarios)
                    </p>
                </div>

                <!-- Formulario -->
                <form class="p-8 space-y-8" action="#" method="post">
                    <!-- Contenedor para las secciones de semestres -->
                    <div id="semestresContainer" class="space-y-6">
                        <!-- Los semestres se generarán aquí dinámicamente -->
                        <div class="text-center py-12 text-gray-500">
                            <i class="fas fa-calendar-day text-4xl mb-3 opacity-50"></i>
                            <p>No hay semestres configurados</p>
                        </div>
                    </div>

                    <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formPagina2', 'pagina2', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto6.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto8.jsp'">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>

    <script>
        // Lista de entregables predefinidos
        const entregables = [
            // Productos Académicos
            { value: 'libros-derivados', text: 'Libros derivados de la propuesta', category: 'academicos' },
            { value: 'propiedad-intelectual', text: 'Propiedad intelectual e industrial', category: 'academicos' },
            { value: 'informes-tecnicos', text: 'Informes técnicos especializados', category: 'academicos' },
            { value: 'desarrollo-tecnologico', text: 'Desarrollo tecnológico e innovación', category: 'academicos' },
            
            // Productos de acceso universal del conocimiento
            { value: 'difusion-divulgacion', text: 'Actividades de difusión y divulgación', category: 'acceso-universal' },
            { value: 'infografias', text: 'Infografías explicativas', category: 'acceso-universal' },
            { value: 'folletos', text: 'Folletos informativos', category: 'acceso-universal' },
            { value: 'libros-divulgacion', text: 'Libros de divulgación científica', category: 'acceso-universal' },
            { value: 'material-audiovisual', text: 'Material audiovisual educativo', category: 'acceso-universal' },
            { value: 'podcast', text: 'Podcast y programas de audio', category: 'acceso-universal' },
            { value: 'otros-divulgacion', text: 'Otros productos de divulgación', category: 'acceso-universal' },
            
            // Formación de capacidades en HCTI y vocaciones científicas
            { value: 'tesis-grado', text: 'Tesis de grado o posgrado', category: 'formacion' },
            { value: 'tesina', text: 'Tesinas de investigación', category: 'formacion' },
            { value: 'memoria-residencias', text: 'Memorias de residencias profesionales', category: 'formacion' },
            
            // Fortalecimiento de infraestructura
            { value: 'equipamiento-maquinaria', text: 'Equipamiento de maquinaria', category: 'infraestructura' },
            { value: 'equipo-laboratorio', text: 'Equipo de laboratorio', category: 'infraestructura' },
            { value: 'software-especializado', text: 'Software especializado', category: 'infraestructura' },
            { value: 'infraestructura-redes', text: 'Infraestructura de redes', category: 'infraestructura' },
            
            // Otros entregables comunes
            { value: 'articulo-cientifico', text: 'Artículo científico', category: 'otros' },
            { value: 'ponencia-congreso', text: 'Ponencia en congreso', category: 'otros' },
            { value: 'poster-cientifico', text: 'Póster científico', category: 'otros' },
            { value: 'manual-tecnico', text: 'Manual técnico', category: 'otros' },
            { value: 'prototipo', text: 'Prototipo funcional', category: 'otros' },
            { value: 'base-datos', text: 'Base de datos especializada', category: 'otros' },
            { value: 'informe-final', text: 'Informe final de investigación', category: 'otros' }
        ];

        // Variable global para controlar el dropdown abierto
        let dropdownAbierto = null;

        // Función para generar las secciones de semestres
        function generarSemestres() {
            const container = document.getElementById('semestresContainer');
            
            // Limpiar el contenedor
            container.innerHTML = '';
            
            // Generar secciones para cada semestre (solo 2 semestres)
            for (let i = 1; i <= 2; i++) {
                const semestreSection = document.createElement('div');
                semestreSection.className = 'semestre-section bg-white border border-gray-200 rounded-lg';
                semestreSection.innerHTML = `
                    <div class="semestre-visible">
                        <h3 class="text-lg font-semibold">Semestre ${i}</h3>
                    </div>
                    <div class="semestre-header p-4 flex justify-between items-center">
                        <div></div>
                        <span class="badge-semestre" title="Semestre ${i}">Semestre ${i}</span>
                    </div>
                    
                    <div class="p-6 space-y-6">
                        <!-- Información general del semestre -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="descripcionSemestre${i}" class="block text-sm font-medium text-gray-700 mb-1">Descripción del Semestre ${i}:</label>
                                <textarea id="descripcionSemestre${i}" name="descripcionSemestre${i}" rows="2" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus"
                                          placeholder="Descripción general del semestre..."></textarea>
                            </div>
                            
                            <div>
                                <label for="metaSemestre${i}" class="block text-sm font-medium text-gray-700 mb-1">Meta del Semestre ${i}:</label>
                                <textarea id="metaSemestre${i}" name="metaSemestre${i}" rows="2" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus"
                                          placeholder="Describa las metas específicas a alcanzar..."></textarea>
                            </div>
                        </div>

                        
                        
                        <!-- Tabla de actividades -->
                        <div class="border-t border-gray-200 pt-4">
                            <div class="flex justify-between items-center mb-4">
                                <h4 class="text-lg font-semibold text-gray-800">Actividades del Semestre ${i}</h4>
                                <button id="agregarActividadBtn${i}" type="button" class="agregar-actividad bg-[#7A1737] hover:bg-[#5A2329] text-white font-medium py-2 px-4 rounded-md transition duration-200 flex items-center" data-semestre="${i}">
                                    <i class="fas fa-plus mr-2"></i>Agregar Actividad
                                </button>
                            </div>
                            
                            <div class="overflow-x-auto">
                                <table class="table-actividades">
                                    <thead>
                                        <tr>
                                            <th class="w-6/12">Actividad</th>
                                            <th class="w-5/12">Entregables</th>
                                            <th class="w-1/12">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="actividadesTable${i}">
                                        <!-- Las actividades se agregarán aquí dinámicamente -->
                                            <tr id="emptyRow${i}">
                                                <td colspan="3" class="text-center text-gray-500 py-4">
                                                    No hay actividades agregadas en Semestre ${i}. Haga clic en "Agregar Actividad" para comenzar.
                                                </td>
                                            </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                `;
                
                container.appendChild(semestreSection);

                // Garantizar los títulos en orden: primer .semestre-visible = Semestre 1, segundo = Semestre 2
                const visibleHeaders = container.querySelectorAll('.semestre-visible h3');
                if (visibleHeaders && visibleHeaders.length >= 1) {
                    if (visibleHeaders[0]) visibleHeaders[0].textContent = 'Semestre 1';
                    if (visibleHeaders[1]) visibleHeaders[1].textContent = 'Semestre 2';
                }

                // Forzar las etiquetas de descripción y meta para que muestren el número correcto
                const descLabel = semestreSection.querySelector(`label[for="descripcionSemestre${i}"]`);
                if (descLabel) descLabel.textContent = `Descripción del Semestre ${i}:`;
                const metaLabel = semestreSection.querySelector(`label[for="metaSemestre${i}"]`);
                if (metaLabel) metaLabel.textContent = `Meta del Semestre ${i}:`;
            }
        }

        // Event delegation acotada al contenedor de semestres (evita ambigüedades
        // con otros elementos en el documento que puedan capturar clicks)
        const semestresContainerEl = document.getElementById('semestresContainer');
        semestresContainerEl.addEventListener('click', function(event) {
            // Buscar el botón de agregar actividad más cercano (si existe)
            const addBtn = event.target.closest('button.agregar-actividad');
            if (addBtn && semestresContainerEl.contains(addBtn)) {
                const semestreNum = addBtn.dataset.semestre;
                console.log('Agregando actividad para semestre (click):', semestreNum, 'botonId:', addBtn.id);
                // Pasamos el botón para localizar la sección correcta en el DOM
                agregarActividadTabla(addBtn);
                return;
            }

            // Buscar el botón de eliminar actividad más cercano (si existe)
            const delBtn = event.target.closest('button.eliminar-actividad');
            if (delBtn && semestresContainerEl.contains(delBtn)) {
                const actividadId = delBtn.dataset.actividad;
                const semestreNum = delBtn.dataset.semestre;
                eliminarActividad(actividadId, semestreNum);
            }
        });

        // Función para crear el selector de entregables
        function crearEntregablesSelector(semestreNum, actividadId) {
            const container = document.createElement('div');
            container.className = 'entregables-container';
            
            const trigger = document.createElement('button');
            trigger.type = 'button';
            trigger.className = 'entregables-trigger';
            trigger.innerHTML = '<i class="fas fa-plus-circle mr-2"></i>Haz clic para seleccionar entregables';
            
            const counter = document.createElement('div');
            counter.className = 'entregables-counter';
            counter.textContent = 'No hay entregables seleccionados';
            
            // CONTENEDOR PRINCIPAL PARA ETIQUETAS VISIBLES
            const tagsContainer = document.createElement('div');
            tagsContainer.className = 'selected-tags-container';
            
            const dropdown = document.createElement('div');
            dropdown.className = 'entregables-dropdown';
            
            // Agrupar entregables por categoría
            const categorias = {
                'academicos': '📚 Productos Académicos',
                'acceso-universal': '🌐 Acceso Universal del Conocimiento',
                'formacion': '🎓 Formación de Capacidades',
                'infraestructura': '🏗️ Fortalecimiento de Infraestructura',
                'otros': '📦 Otros Entregables'
            };
            
            // Crear opciones por categoría
            Object.keys(categorias).forEach(categoria => {
                const group = document.createElement('div');
                group.className = 'entregable-group';
                
                const groupTitle = document.createElement('div');
                groupTitle.className = 'entregable-group-title';
                groupTitle.textContent = categorias[categoria];
                group.appendChild(groupTitle);
                
                entregables
                    .filter(entregable => entregable.category === categoria)
                    .forEach(entregable => {
                        const item = document.createElement('div');
                        item.className = 'entregable-item';
                        
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.className = 'entregable-checkbox';
                        checkbox.name = `actividadEntregable${semestreNum}_${actividadId}[]`;
                        checkbox.value = entregable.value;
                        checkbox.id = `entregable_${semestreNum}_${actividadId}_${entregable.value}`;
                        
                        const label = document.createElement('label');
                        label.className = 'entregable-label';
                        label.htmlFor = checkbox.id;
                        label.textContent = entregable.text;
                        
                        checkbox.addEventListener('change', function() {
                            updateSelectionState();
                        });
                        
                        item.appendChild(checkbox);
                        item.appendChild(label);
                        group.appendChild(item);
                    });
                
                dropdown.appendChild(group);
            });
            
            // Función para actualizar el estado de selección
            function updateSelectionState() {
                const checkboxes = dropdown.querySelectorAll('input[type="checkbox"]');
                const selected = Array.from(checkboxes).filter(cb => cb.checked);
                
                // Actualizar contador
                if (selected.length > 0) {
                    counter.textContent = `${selected.length} entregable(s) seleccionado(s)`;
                    counter.classList.add('has-selection');
                    trigger.classList.add('has-selection');
                    trigger.innerHTML = `<i class="fas fa-check-circle mr-2"></i>${selected.length} entregable(s) seleccionado(s) - Haz clic para modificar`;
                } else {
                    counter.textContent = 'No hay entregables seleccionados';
                    counter.classList.remove('has-selection');
                    trigger.classList.remove('has-selection');
                    trigger.innerHTML = '<i class="fas fa-plus-circle mr-2"></i>Haz clic para seleccionar entregables';
                }
                
                // Actualizar etiquetas visibles
                updateTags(selected);
            }
            
            // Función para actualizar las etiquetas visibles
            function updateTags(selectedCheckboxes) {
                // Limpiar el contenedor
                tagsContainer.innerHTML = '';
                
                // Crear contenedor para las etiquetas
                const tagsDiv = document.createElement('div');
                tagsDiv.className = 'selected-tags';
                
                if (selectedCheckboxes.length === 0) {
                    const emptyMsg = document.createElement('div');
                    emptyMsg.className = 'empty-selection';
                    emptyMsg.textContent = 'No hay entregables seleccionados';
                    tagsContainer.appendChild(emptyMsg);
                } else {
                    selectedCheckboxes.forEach(checkbox => {
                        const entregableValue = checkbox.value;
                        const entregable = entregables.find(e => e.value === entregableValue);
                        
                        if (entregable) {
                            const tag = document.createElement('div');
                            tag.className = 'selected-tag';

                            const textSpan = document.createElement('span');
                            textSpan.className = 'tag-text';
                            textSpan.textContent = entregable.text;

                            const removeBtn = document.createElement('span');
                            removeBtn.className = 'remove-tag';
                            removeBtn.setAttribute('data-value', entregableValue);
                            removeBtn.innerHTML = '<i class="fas fa-times"></i>';
                            removeBtn.addEventListener('click', function(e) {
                                e.stopPropagation();
                                const value = this.getAttribute('data-value');
                                const checkboxToUncheck = dropdown.querySelector(`input[value="${value}"]`);
                                if (checkboxToUncheck) {
                                    checkboxToUncheck.checked = false;
                                    checkboxToUncheck.dispatchEvent(new Event('change'));
                                }
                            });

                            tag.appendChild(textSpan);
                            tag.appendChild(removeBtn);
                            tagsDiv.appendChild(tag);
                        }
                    });
                    tagsContainer.appendChild(tagsDiv);
                }
            }
            
            // Event listeners para el dropdown
            trigger.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // Cerrar cualquier dropdown abierto previamente
                if (dropdownAbierto && dropdownAbierto !== dropdown) {
                    dropdownAbierto.classList.remove('show');
                }
                
                // Abrir/cerrar el dropdown actual
                dropdown.classList.toggle('show');
                dropdownAbierto = dropdown.classList.contains('show') ? dropdown : null;
            });
            
            // Prevenir que el contenido del dropdown cierre el dropdown al hacer clic
            dropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
            
            // Agregar elementos en el orden correcto
            container.appendChild(trigger);
            container.appendChild(counter);
            container.appendChild(tagsContainer);
            container.appendChild(dropdown);
            
            // Inicializar el estado
            updateTags([]);
            
            return container;
        }

        // Función para agregar una actividad a la tabla
        function agregarActividadTabla(semestreSource) {
            // semestreSource puede ser el número de semestre o el botón que lo inició
            let semestreNum;
            let container;

            if (typeof semestreSource === 'string' || typeof semestreSource === 'number') {
                semestreNum = semestreSource;
                container = document.getElementById(`actividadesTable${semestreNum}`);
            } else if (semestreSource instanceof Element) {
                const boton = semestreSource;
                // Buscar la sección de semestre más cercana y obtener su número desde el badge o data
                const semestreSection = boton.closest('.semestre-section');
                if (semestreSection) {
                    // intentar extraer el número desde el texto del badge o del contenido del header
                    const badge = semestreSection.querySelector('.badge-semestre');
                    if (badge) {
                        const match = badge.textContent.match(/\d+/);
                        semestreNum = match ? match[0] : boton.dataset.semestre;
                    } else {
                        semestreNum = boton.dataset.semestre;
                    }
                    container = semestreSection.querySelector(`#actividadesTable${semestreNum}`);
                } else {
                    // fallback
                    semestreNum = boton.dataset.semestre;
                    container = document.getElementById(`actividadesTable${semestreNum}`);
                }
            }

            console.log('Agregando actividad para semestre (resolved):', semestreNum);
            const emptyRow = document.getElementById(`emptyRow${semestreNum}`);
            
            // Ocultar fila vacía si existe
            if (emptyRow) {
                emptyRow.style.display = 'none';
            }
            
            const actividadId = Date.now(); // ID único basado en timestamp
            
            const actividadRow = document.createElement('tr');
            actividadRow.id = `actividad-${actividadId}`;
            actividadRow.innerHTML = `
                <td>
                    <input type="text" 
                           name="actividadNombre${semestreNum}[]" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus text-sm"
                           placeholder="Nombre de la actividad"
                           required>
                </td>
                <td>
                    <!-- El selector de entregables se agregará dinámicamente -->
                </td>
                <td>
                    <button type="button" 
                            class="eliminar-actividad btn-remove text-xs py-2 px-3 rounded flex items-center justify-center w-full"
                            data-actividad="${actividadId}"
                            data-semestre="${semestreNum}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            
            // Agregar el selector de entregables
            const tdEntregable = actividadRow.querySelector('td:nth-child(2)');
            const entregablesSelector = crearEntregablesSelector(semestreNum, actividadId);
            tdEntregable.appendChild(entregablesSelector);
            
            // Insertar la nueva fila AL FINAL del tbody
            if (container) {
                container.appendChild(actividadRow);
            } else {
                console.error('No se encontró el contenedor de actividades para el semestre:', semestreNum);
            }
        }

        // Función para eliminar una actividad
        function eliminarActividad(actividadId, semestreNum) {
            const actividadRow = document.getElementById(`actividad-${actividadId}`);
            if (actividadRow) {
                actividadRow.remove();

                // Mostrar fila vacía si no hay más actividades reales (filas con id actividad-...)
                const container = document.getElementById(`actividadesTable${semestreNum}`);
                const actividades = container.querySelectorAll('tr[id^="actividad-"]');
                if (actividades.length === 0) {
                    const emptyRow = document.getElementById(`emptyRow${semestreNum}`);
                    if (emptyRow) {
                        emptyRow.style.display = '';
                    }
                }
            }
        }

        // Función para guardar borrador
        function guardarBorrador(formId, pagina, button) {
            // Validar que cada semestre tenga al menos una actividad
            let semestresValidos = true;
            for (let i = 1; i <= 2; i++) {
                const actividades = document.querySelectorAll(`#actividadesTable${i} tr[id^="actividad-"]`);
                if (actividades.length === 0) {
                    alert(`El semestre ${i} no tiene actividades. Por favor, agregue al menos una actividad.`);
                    semestresValidos = false;
                    break;
                }
            }
            
            if (semestresValidos) {
                alert('Borrador guardado correctamente');
                // Aquí iría la lógica para guardar en la base de datos
            }
        }

        // Event listener global para cerrar dropdowns al hacer clic fuera
        document.addEventListener('click', function(event) {
            if (dropdownAbierto && !dropdownAbierto.parentElement.contains(event.target)) {
                dropdownAbierto.classList.remove('show');
                dropdownAbierto = null;
            }
        });

        // Generar 2 semestres por defecto al cargar la página
        document.addEventListener('DOMContentLoaded', function() {
            generarSemestres();
        });
    </script>
</body>
</html>