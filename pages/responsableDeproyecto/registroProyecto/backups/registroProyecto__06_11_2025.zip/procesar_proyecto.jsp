<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.util.regex.*" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>

<%!
    // Configuración de la base de datos (igual que proyectos.jsp)
    private static final String DB_URL = "jdbc:postgresql://coveicydetsysdev.ddns.net:5432/proyectos";
    private static final String DB_USER = "dbusr25";
    private static final String DB_PASSWORD = "mxToro24000Chocolate";
    
    // Función para extraer valor de JSON simple
    public String extraerValor(String json, String clave) {
        if (json == null || clave == null) return "";
        
        String patron = "\"" + clave + "\"\\s*:\\s*\"([^\"]*)\"|\"" + clave + "\"\\s*:\\s*([^,}\\]]+)";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(json);
        
        if (matcher.find()) {
            String valor = matcher.group(1);
            if (valor == null) valor = matcher.group(2);
            if (valor != null) {
                valor = valor.trim();
                if (valor.equals("null") || valor.equals("undefined")) return "";
                return valor;
            }
        }
        return "";
    }
    
    // Función para extraer array de cronograma
    public List<Map<String, String>> extraerCronograma(String json) {
        List<Map<String, String>> cronograma = new ArrayList<>();
        
        if (json == null) return cronograma;
        
        // Buscar el array cronograma
        Pattern patronArray = Pattern.compile("\"cronograma\"\\s*:\\s*\\[(.*?)\\]", Pattern.DOTALL);
        Matcher matcherArray = patronArray.matcher(json);
        
        if (matcherArray.find()) {
            String arrayContent = matcherArray.group(1);
            
            // Dividir objetos dentro del array - mejorada para manejar objetos anidados
            Pattern patronObjeto = Pattern.compile("\\{([^{}]*(?:\\{[^{}]*\\}[^{}]*)*)\\}");
            Matcher matcherObjeto = patronObjeto.matcher(arrayContent);
            
            while (matcherObjeto.find()) {
                String objeto = matcherObjeto.group(1);
                Map<String, String> actividad = new HashMap<>();
                
                // Extraer campos del objeto cronograma
                String actividadVal = extraerValor("{" + objeto + "}", "actividad");
                String mesVal = extraerValor("{" + objeto + "}", "mes");
                String entregableVal = extraerValor("{" + objeto + "}", "entregable");
                
                // Solo agregar si al menos uno de los campos tiene contenido
                if (!actividadVal.isEmpty() || !mesVal.isEmpty() || !entregableVal.isEmpty()) {
                    actividad.put("actividad", actividadVal);
                    actividad.put("mes", mesVal);
                    actividad.put("entregable", entregableVal);
                    cronograma.add(actividad);
                }
            }
        }
        
        return cronograma;
    }

    // ==========================
    // Extracción segura sin libs
    // ==========================
    private int encontrarCierreBalanceado(String s, int inicio, char abre, char cierra) {
        int profundidad = 0;
        boolean enString = false;
        boolean escape = false;
        for (int i = inicio; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (enString) {
                if (escape) {
                    escape = false;
                } else if (ch == '\\') {
                    escape = true;
                } else if (ch == '"') {
                    enString = false;
                }
                continue;
            }
            if (ch == '"') {
                enString = true;
                continue;
            }
            if (ch == abre) profundidad++;
            else if (ch == cierra) {
                profundidad--;
                if (profundidad == 0) return i;
            }
        }
        return -1; // no encontrado
    }

    private String extraerObjetoPorClave(String json, String clave) {
        if (json == null) return "{}";
        String buscado = "\"" + clave + "\"";
        int idx = json.indexOf(buscado);
        if (idx < 0) return "{}";
        int ll = json.indexOf('{', idx);
        if (ll < 0) return "{}";
        int rr = encontrarCierreBalanceado(json, ll, '{', '}');
        if (rr < 0) return "{}";
        return json.substring(ll, rr + 1);
    }

    private String extraerArrayPorClave(String json, String clave) {
        if (json == null) return "[]";
        String buscado = "\"" + clave + "\"";
        int idx = json.indexOf(buscado);
        if (idx < 0) return "[]";
        int lb = json.indexOf('[', idx);
        if (lb < 0) return "[]";
        int rb = encontrarCierreBalanceado(json, lb, '[', ']');
        if (rb < 0) return "[]";
        return json.substring(lb, rb + 1);
    }

    public List<Map<String, String>> extraerCronogramaSeguro(String datosProyectoJson) {
        List<Map<String, String>> cronograma = new ArrayList<>();
        if (datosProyectoJson == null) return cronograma;

        // 1) Obtener pagina4 sin regex frágil (el cronograma está en página 4)
        String pagina4 = extraerObjetoPorClave(datosProyectoJson, "pagina4");
        if (pagina4 == null || pagina4.length() < 2) return cronograma;

        // 2) Obtener el array cronograma dentro de pagina4
        String arr = extraerArrayPorClave(pagina4, "cronograma");
        if (arr == null || arr.length() < 2) return cronograma;

        // 3) Recorrer el array y extraer cada objeto balanceado
        int i = 0;
        while (i < arr.length()) {
            int objStart = arr.indexOf('{', i);
            if (objStart < 0) break;
            int objEnd = encontrarCierreBalanceado(arr, objStart, '{', '}');
            if (objEnd < 0) break;

            String objeto = arr.substring(objStart, objEnd + 1);

            String actividadVal = extraerValor(objeto, "actividad");
            String mesVal = extraerValor(objeto, "mes");
            if (mesVal == null || mesVal.isEmpty()) mesVal = extraerValor(objeto, "trimestre");
            String entregableVal = extraerValor(objeto, "entregable");
            String fechaVal = extraerValor(objeto, "fecha");
            if (fechaVal == null || fechaVal.isEmpty()) fechaVal = extraerValor(objeto, "fecha_entrega");

            if ((actividadVal != null && !actividadVal.isEmpty())
                || (mesVal != null && !mesVal.isEmpty())
                || (entregableVal != null && !entregableVal.isEmpty())) {
                Map<String, String> act = new HashMap<>();
                act.put("actividad", actividadVal);
                act.put("mes", mesVal);
                act.put("entregable", entregableVal);
                act.put("fecha", fechaVal);
                cronograma.add(act);
            }

            i = objEnd + 1;
        }

        return cronograma;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Procesando Proyecto</title>
</head>
<body class="bg-slate-100 min-h-screen antialiased font-sans">
    <div class="max-w-4xl mx-auto px-4 py-10">
        <div class="bg-white p-8 rounded-xl shadow-sm border border-slate-200">

<%
    // Obtener datos del usuario de la sesión
    Integer userId = (Integer) session.getAttribute("id");
    String nombreCompleto = (String) session.getAttribute("nombre");
    
    // Configuración de la base de datos ya declarada arriba
    
    String mensaje = "";
    String tipoMensaje = "info";
    boolean exito = false;
    
    try {
        // Validar que el usuario tenga sesión válida
        if (userId == null || nombreCompleto == null) {
            throw new Exception("Sesión inválida. Por favor, inicie sesión nuevamente.");
        }
        
        String datosProyectoJson = request.getParameter("datosProyecto");
        
        if (datosProyectoJson == null || datosProyectoJson.trim().isEmpty()) {
            throw new Exception("No se recibieron datos del proyecto");
        }
        
        // Extraer secciones del JSON principal
        Pattern patronPagina = Pattern.compile("\"(pagina\\d+)\"\\s*:\\s*\\{([^}]+(?:\\{[^}]*\\}[^}]*)*)\\}");
        Matcher matcherPagina = patronPagina.matcher(datosProyectoJson);
        
        Map<String, String> paginas = new HashMap<>();
        while (matcherPagina.find()) {
            String nombrePagina = matcherPagina.group(1);
            String contenidoPagina = "{" + matcherPagina.group(2) + "}";
            paginas.put(nombrePagina, contenidoPagina);
        }
        
        String pagina1Json = paginas.getOrDefault("pagina1", "{}");
        String pagina2Json = paginas.getOrDefault("pagina2", "{}");
        String pagina3Json = paginas.getOrDefault("pagina3", "{}");
        String pagina4Json = paginas.getOrDefault("pagina4", "{}");
        
        // Conectar a la base de datos
        Class.forName("org.postgresql.Driver");
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            conn.setAutoCommit(false);
            
            // Insertar proyecto principal
            String sqlProyecto = "INSERT INTO proyectos (" +
                "titulo, organizacion_proponente, area_adscripcion, convocatoria, " +
                "area_conocimiento, sector_desarrollo, nivel_maduracion, " +
                "resumen_ejecutivo, antecedentes, pertinencia, preguntas_investigacion, " +
                "objetivo_general, objetivos_especificos, factores_riesgo_mitigacion, " +
                "referencias_bibliograficas, vinculacion_institucional, resultados_esperados, " +
                "areas_impacto, monto_solicitado_coveicydet, estado_proyecto, usuario_creador, usuario_id" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'enviado', ?, ?) " +
                "RETURNING id_proyecto";
            
            int proyectoId = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlProyecto)) {
                // Mapear campos de página 1
                stmt.setString(1, extraerValor(pagina1Json, "titulo"));
                stmt.setString(2, extraerValor(pagina1Json, "institucion"));
                stmt.setString(3, extraerValor(pagina1Json, "area"));
                stmt.setString(4, extraerValor(pagina1Json, "convocatoria"));
                stmt.setString(5, extraerValor(pagina1Json, "areaConocimiento"));
                stmt.setString(6, extraerValor(pagina1Json, "sectorDesarrollo"));
                stmt.setString(7, extraerValor(pagina1Json, "nivelMaduracion"));
                
                // Mapear campos de página 2
                stmt.setString(8, extraerValor(pagina2Json, "resumen-ejecutivo"));
                stmt.setString(9, extraerValor(pagina2Json, "antecedentes"));
                stmt.setString(10, extraerValor(pagina2Json, "pertinencia"));
                stmt.setString(11, extraerValor(pagina2Json, "preguntas-investigacion"));
                stmt.setString(12, extraerValor(pagina2Json, "objetivo-general"));
                stmt.setString(13, extraerValor(pagina2Json, "objetivos-especificos"));
                
                // Mapear campos de página 3
                stmt.setString(14, extraerValor(pagina3Json, "factores-riesgo"));
                stmt.setString(15, extraerValor(pagina3Json, "referencias"));
                stmt.setString(16, extraerValor(pagina3Json, "vinculacion-institucional"));
                stmt.setString(17, extraerValor(pagina3Json, "resultados"));
                stmt.setString(18, extraerValor(pagina3Json, "areas-impacto"));
                
                // Mapear presupuesto de página 4
                String presupuestoStr = extraerValor(pagina4Json, "presupuesto");
                double presupuesto = 0;
                try {
                    if (!presupuestoStr.isEmpty()) {
                        presupuesto = Double.parseDouble(presupuestoStr);
                    }
                } catch (NumberFormatException e) {
                    presupuesto = 0;
                }
                stmt.setDouble(19, presupuesto);
                
                // Agregar usuario_creador y usuario_id
                stmt.setString(20, nombreCompleto);
                stmt.setInt(21, userId);
                
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    proyectoId = rs.getInt("id_proyecto");
                }
            }
            
            if (proyectoId == 0) {
                throw new Exception("No se pudo insertar el proyecto");
            }
            
            // Insertar responsables (página 1)
            String sqlResponsables = "INSERT INTO proyecto_responsables (id_proyecto, tipo_responsable, nombre, correo, telefono) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlResponsables)) {
                // Responsable Legal
                String nombreLegal = extraerValor(pagina1Json, "nombreLegal");
                String correoLegal = extraerValor(pagina1Json, "correoLegal");
                String telefonoLegal = extraerValor(pagina1Json, "telefonoLegal");
                if (!nombreLegal.isEmpty()) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "legal");
                    stmt.setString(3, nombreLegal);
                    stmt.setString(4, correoLegal);
                    stmt.setString(5, telefonoLegal);
                    stmt.addBatch();
                }
                
                // Responsable Técnico
                String nombreTecnico = extraerValor(pagina1Json, "nombreTecnico");
                String correoTecnico = extraerValor(pagina1Json, "correoTecnico");
                String telefonoTecnico = extraerValor(pagina1Json, "telefonoTecnico");
                if (!nombreTecnico.isEmpty()) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "tecnico");
                    stmt.setString(3, nombreTecnico);
                    stmt.setString(4, correoTecnico);
                    stmt.setString(5, telefonoTecnico);
                    stmt.addBatch();
                }
                
                // Responsable Administrativo
                String nombreAdmin = extraerValor(pagina1Json, "nombreAdministrativo");
                String correoAdmin = extraerValor(pagina1Json, "correoAdministrativo");
                String telefonoAdmin = extraerValor(pagina1Json, "telefonoAdministrativo");
                if (!nombreAdmin.isEmpty()) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "administrativo");
                    stmt.setString(3, nombreAdmin);
                    stmt.setString(4, correoAdmin);
                    stmt.setString(5, telefonoAdmin);
                    stmt.addBatch();
                }
                
                stmt.executeBatch();
            }
            
            // Insertar cronograma (página 4) usando extracción segura sin libs externas
            List<Map<String, String>> cronograma = extraerCronogramaSeguro(datosProyectoJson);
            if (!cronograma.isEmpty()) {
                // Opción A: usar columnas reales del esquema (trimestre, meta, actividad, fecha_entrega)
                String sqlCronograma = "INSERT INTO cronograma_actividades (id_proyecto, trimestre, meta, actividad, fecha_entrega) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sqlCronograma)) {
                    for (Map<String, String> actividad : cronograma) {
                        stmt.setInt(1, proyectoId);
                        // Mapear mes -> trimestre
                        stmt.setString(2, actividad.get("mes"));
                        // Mapear entregable -> meta
                        stmt.setString(3, actividad.get("entregable"));
                        // Actividad
                        stmt.setString(4, actividad.get("actividad"));
                        // Intentar mapear fecha si llega; de lo contrario NULL
                        java.sql.Date fecha = null;
                        String fechaStr = actividad.get("fecha");
                        if (fechaStr != null && !fechaStr.trim().isEmpty()) {
                            try {
                                fecha = java.sql.Date.valueOf(fechaStr);
                            } catch (IllegalArgumentException ex) {
                                fecha = null;
                            }
                        }
                        if (fecha != null) {
                            stmt.setDate(5, fecha);
                        } else {
                            stmt.setNull(5, java.sql.Types.DATE);
                        }
                        stmt.addBatch();
                    }
                    stmt.executeBatch();
                }
            }
            
            // Insertar entregables comprometidos (página 4)
            // Solo guardar los checkboxes marcados
            String sqlEntregables = "INSERT INTO entregables_comprometidos (id_proyecto, categoria, tipo_entregable) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEntregables)) {
                // Productos académicos
                if ("on".equals(extraerValor(pagina4Json, "articulos-jcr"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos Académicos");
                    stmt.setString(3, "Artículos en revistas JCR");
                    stmt.addBatch();
                }
                if ("on".equals(extraerValor(pagina4Json, "articulos-conahcyt"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos Académicos");
                    stmt.setString(3, "Artículos en revistas CONAHCYT");
                    stmt.addBatch();
                }
                if ("on".equals(extraerValor(pagina4Json, "capitulos-libro"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos Académicos");
                    stmt.setString(3, "Capítulos de libro");
                    stmt.addBatch();
                }
                if ("on".equals(extraerValor(pagina4Json, "libros"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos Académicos");
                    stmt.setString(3, "Libros");
                    stmt.addBatch();
                }
                
                // Productos de acceso universal
                if ("on".equals(extraerValor(pagina4Json, "libros-acceso"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos de acceso universal");
                    stmt.setString(3, "Libros de acceso universal");
                    stmt.addBatch();
                }
                if ("on".equals(extraerValor(pagina4Json, "patentes"))) {
                    stmt.setInt(1, proyectoId);
                    stmt.setString(2, "Productos de acceso universal");
                    stmt.setString(3, "Patentes");
                    stmt.addBatch();
                }
                
                stmt.executeBatch();
            }
            
            conn.commit();
            exito = true;
            mensaje = "Proyecto enviado exitosamente con ID: " + proyectoId;
            tipoMensaje = "success";
            
            // Limpiar localStorage después del envío exitoso
%>
            <script>
                localStorage.removeItem('proyecto_borrador_pagina1');
                localStorage.removeItem('proyecto_borrador_pagina2');
                localStorage.removeItem('proyecto_borrador_pagina3');
                localStorage.removeItem('proyecto_borrador_pagina4');
            </script>
<%
        } catch (SQLException e) {
            mensaje = "Error de base de datos: " + e.getMessage();
            tipoMensaje = "error";
            e.printStackTrace();
        }
        
    } catch (ClassNotFoundException e) {
        mensaje = "Error: Driver de PostgreSQL no encontrado";
        tipoMensaje = "error";
        e.printStackTrace();
    } catch (Exception e) {
        mensaje = "Error al procesar el proyecto: " + e.getMessage();
        tipoMensaje = "error";
        e.printStackTrace();
    }
%>

            <div class="text-center">
                <% if ("success".equals(tipoMensaje)) { %>
                    <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                        <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                    <h1 class="text-2xl font-semibold text-gray-900 mb-2">¡Proyecto Enviado!</h1>
                <% } else { %>
                    <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
                        <svg class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </div>
                    <h1 class="text-2xl font-semibold text-gray-900 mb-2">Error al Enviar</h1>
                <% } %>
                
                <p class="text-gray-600 mb-6"><%= mensaje %></p>
                
                <div class="space-x-4">
                    <% if (exito) { %>
                        <a href="/proyectos/pages/responsableDeproyecto/proyectos/proyectos.jsp" 
                           class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Ver Mis Proyectos
                        </a>
                        <a href="/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto.jsp" 
                           class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            Nuevo Proyecto
                        </a>
                    <% } else { %>
                        <button onclick="history.back()" 
                                class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            Volver
                        </button>
                        <a href="/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto.jsp" 
                           class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Empezar de Nuevo
                        </a>
                    <% } %>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
