<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Organizaciones Participantes - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .participant-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
            background: white;
            border-radius: 0.75rem;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .participant-table th {
            background-color: #7A1737;
            color: white;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            font-size: 0.875rem;
        }
        
        .participant-table td {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-section {
            background: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .section-header {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #B28854;
        }
        
        .notification {
            position: fixed;
            top: 1rem;
            right: 1rem;
            padding: 1rem;
            border-radius: 0.5rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: flex;
            align-items: center;
            max-width: 400px;
            transform: translateX(150%);
            transition: transform 0.3s ease-out;
            background-color: #fee2e2;
            border: 1px solid #ef4444;
            color: #991b1b;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification-icon {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }
        
        .table-title {
            color: #7A1737;
            font-weight: 600;
            margin: 0;
        }
        
        .legend-box {
            background-color: #f8fafc;
            border-left: 4px solid #7A1737;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 0.375rem;
        }
        
        .legend-title {
            font-weight: 600;
            color: #7A1737;
            margin-bottom: 0.5rem;
        }
        
        .legend-text {
            color: #4b5563;
            font-size: 0.875rem;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-building mr-3"></i>Organizaciones Participantes 5/9
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Complete la información de las organizaciones participantes (Min 1 - Max 5).
                        
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formOrganizaciones" class="p-8 space-y-8">
                    <!-- Leyenda -->
                    <div class="legend-box">
                        <div class="legend-title">Organizaciones Participantes</div>
                        <div class="legend-text">
                            En esta sección deberá registrar la información de las 5 organizaciones que participarán en el proyecto. 
                            Cada organización debe contar con información completa sobre su razón social, responsable, datos de contacto 
                            y la descripción de las actividades que realizarán en el proyecto.
                        </div>
                    </div>

                    <!-- Sección: ORGANIZACIONES PARTICIPANTES - 5 Tablas -->
                    <section class="space-y-6">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-building mr-2 text-[#7A1737]"></i>ORGANIZACIONES PARTICIPANTES
                        </h4>

                        <!-- Tabla 1 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Organización 1</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre o razón social</td>
                                        <td><input type="text" name="org-nombre-1" class="floating-input" placeholder="Nombre o razón social"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Responsable</td>
                                        <td><input type="text" name="org-responsable-1" class="floating-input" placeholder="Responsable"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Domicilio</td>
                                        <td><input type="text" name="org-domicilio-1" class="floating-input" placeholder="Domicilio"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Teléfono</td>
                                        <td><input type="text" name="org-telefono-1" class="floating-input" placeholder="Teléfono"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Descripción de la actividad</td>
                                        <td><input type="text" name="org-actividad-1" class="floating-input" placeholder="Descripción de la actividad"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Correo electrónico</td>
                                        <td><input type="email" name="org-email-1" class="floating-input" placeholder="Correo electrónico"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Comprobante de adscripción
                                        </td>
                                        <td>
                                            <input type="file" name="org-comprobante-1" accept=".pdf,image/*" 
                                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                   title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 2 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Organización 2</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre o razón social</td>
                                        <td><input type="text" name="org-nombre-2" class="floating-input" placeholder="Nombre o razón social"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Responsable</td>
                                        <td><input type="text" name="org-responsable-2" class="floating-input" placeholder="Responsable"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Domicilio</td>
                                        <td><input type="text" name="org-domicilio-2" class="floating-input" placeholder="Domicilio"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Teléfono</td>
                                        <td><input type="text" name="org-telefono-2" class="floating-input" placeholder="Teléfono"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Descripción de la actividad</td>
                                        <td><input type="text" name="org-actividad-2" class="floating-input" placeholder="Descripción de la actividad"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Correo electrónico</td>
                                        <td><input type="email" name="org-email-2" class="floating-input" placeholder="Correo electrónico"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Comprobante de adscripción
                                        </td>
                                        <td>
                                            <input type="file" name="org-comprobante-2" accept=".pdf,image/*" 
                                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                   title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 3 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Organización 3</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre o razón social</td>
                                        <td><input type="text" name="org-nombre-3" class="floating-input" placeholder="Nombre o razón social"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Responsable</td>
                                        <td><input type="text" name="org-responsable-3" class="floating-input" placeholder="Responsable"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Domicilio</td>
                                        <td><input type="text" name="org-domicilio-3" class="floating-input" placeholder="Domicilio"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Teléfono</td>
                                        <td><input type="text" name="org-telefono-3" class="floating-input" placeholder="Teléfono"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Descripción de la actividad</td>
                                        <td><input type="text" name="org-actividad-3" class="floating-input" placeholder="Descripción de la actividad"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Correo electrónico</td>
                                        <td><input type="email" name="org-email-3" class="floating-input" placeholder="Correo electrónico"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Comprobante de adscripción
                                        </td>
                                        <td>
                                            <input type="file" name="org-comprobante-3" accept=".pdf,image/*" 
                                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                   title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 4 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Organización 4</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre o razón social</td>
                                        <td><input type="text" name="org-nombre-4" class="floating-input" placeholder="Nombre o razón social"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Responsable</td>
                                        <td><input type="text" name="org-responsable-4" class="floating-input" placeholder="Responsable"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Domicilio</td>
                                        <td><input type="text" name="org-domicilio-4" class="floating-input" placeholder="Domicilio"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Teléfono</td>
                                        <td><input type="text" name="org-telefono-4" class="floating-input" placeholder="Teléfono"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Descripción de la actividad</td>
                                        <td><input type="text" name="org-actividad-4" class="floating-input" placeholder="Descripción de la actividad"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Correo electrónico</td>
                                        <td><input type="email" name="org-email-4" class="floating-input" placeholder="Correo electrónico"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Comprobante de adscripción
                                        </td>
                                        <td>
                                            <input type="file" name="org-comprobante-4" accept=".pdf,image/*" 
                                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                   title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Tabla 5 -->
                        <div class="table-section">
                            <div class="section-header">
                                <h5 class="table-title">Organización 5</h5>
                            </div>
                            <table class="participant-table">
                                <tbody>
                                    <tr>
                                        <td style="width: 200px; background-color: #f8fafc; font-weight: 500;">Nombre o razón social</td>
                                        <td><input type="text" name="org-nombre-5" class="floating-input" placeholder="Nombre o razón social"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Responsable</td>
                                        <td><input type="text" name="org-responsable-5" class="floating-input" placeholder="Responsable"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Domicilio</td>
                                        <td><input type="text" name="org-domicilio-5" class="floating-input" placeholder="Domicilio"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Teléfono</td>
                                        <td><input type="text" name="org-telefono-5" class="floating-input" placeholder="Teléfono"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Descripción de la actividad</td>
                                        <td><input type="text" name="org-actividad-5" class="floating-input" placeholder="Descripción de la actividad"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">Correo electrónico</td>
                                        <td><input type="email" name="org-email-5" class="floating-input" placeholder="Correo electrónico"></td>
                                    </tr>
                                    <tr>
                                        <td style="background-color: #f8fafc; font-weight: 500;">
                                            <i class="fas fa-file-pdf text-[#7A1737] mr-2"></i>Comprobante de adscripción
                                        </td>
                                        <td>
                                            <input type="file" name="org-comprobante-5" accept=".pdf,image/*" 
                                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                                   title="Adjunte comprobante de adscripción (PDF o imagen)" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>

                    <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formOrganizaciones', 'organizaciones', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto4.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto6.jsp'">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>
    
    <!-- Notificación -->
    <div id="notification" class="notification">
        <i class="notification-icon fas fa-exclamation-circle"></i>
        <span class="notification-message"></span>
    </div>
    
    <script>
        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            // Recopilar datos de todos los inputs
            const inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                if (input.type !== 'button') {
                    if (input.type === 'file') {
                        data[input.name] = input.files[0] ? input.files[0].name : '';
                    } else {
                        data[input.name] = input.value;
                    }
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        // Función para cargar borrador
        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const element = form.querySelector(`[name="${key}"]`);
                    if (element && element.type !== 'file') {
                        element.value = data[key];
                    }
                });
            }
        }

        // Mostrar mensaje temporal
        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';
            
            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }
            
            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;
            
            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);
                
                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
                
                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;
                
                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }
                
                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;
                
                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }
            
            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir control de navegación
        window.addEventListener('load', function() {
            cargarBorrador('formOrganizaciones', 'organizaciones');
            
            const KEY = 'proyecto_borrador_organizaciones_saved';
            const form = document.getElementById('formOrganizaciones');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const siguienteBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('estudiantes.jsp') || /siguiente/i.test(b.textContent));
            
            function setDisabled(btn, disabled){
                if(!btn) return;
                btn.disabled = disabled;
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                if(disabled) { btn.classList.add('opacity-60','cursor-not-allowed'); } else { btn.classList.remove('opacity-60','cursor-not-allowed'); }
            }
            
            if(!guardarBtn || !siguienteBtn){
                console.warn('No se encontraron botones Guardar/Siguiente en organizaciones');
            }
            
            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(siguienteBtn, !saved);
            
            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1');
                    saved = true;
                    setDisabled(siguienteBtn, false);
                    console.log('Borrador organizaciones guardado -> Siguiente habilitado');
                });
            }
            
            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        setDisabled(siguienteBtn, true);
                        console.log('Formulario organizaciones modificado despues de guardar: Siguiente bloqueado');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));
                
                // beforeunload
                window.addEventListener('beforeunload', function(e){
                    try{
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault(); e.returnValue = msg; return msg;
                        }
                    }catch(err){ return undefined; }
                });
            }
        });
    </script>
</body>
</html>