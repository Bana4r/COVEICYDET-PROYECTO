<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Justificación y objetivos - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
            resize: vertical;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .word-counter {
            font-size: 0.875rem;
            margin-top: 0.5rem;
            text-align: right;
            padding: 0.25rem 0.5rem;
            background-color: #f8fafc;
            border-radius: 0.25rem;
            border: 1px solid #e2e8f0;
            font-weight: 500;
        }
        
        .word-counter.warning {
            color: #dc2626;
            background-color: #fef2f2;
            border-color: #fecaca;
        }
        
        .word-counter.success {
            color: #16a34a;
            background-color: #f0fdf4;
            border-color: #bbf7d0;
        }
        
        .textarea-container {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-file-contract mr-3"></i>Cargar archivo extenso 9/9
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formPagina6" class="p-8 space-y-8">

                    <!-- Aquí va el contenido del formulario -->
                    <section class="space-y-6">
                        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500 flex items-center">
                            <i class="fas fa-file-alt mr-2 text-[#7A1737]"></i>Descarga la plantilla para el documento extenso
                        </h4>

                        <!-- Campos del formulario aquí -->
                        <!-- descargar arhivo plantilla-->
                        <div class= "flex flex-col space-y-4">
                            <a href="/proyectos/plantillas/EjemploDocCOVEICYDET.docx" download
                               class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center w-max">
                                <i class="fas fa-download mr-2"></i>Descargar plantilla
                            </a> 
                        </div>

                        <!-- subir extenso en formato pdf-->
                        <div class="flex flex-col space-y-2">
                            <label for="documentoExtenso" class="text-sm font-medium text-gray-700 flex items-center">
                                <i class="fas fa-upload mr-2 text-[#7A1737]"></i>Subir documento extenso (formato PDF):
                            </label>
                            <input type="file" id="documentoExtenso" name="documentoExtenso" accept=".pdf"
                                   class="border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-[#7A1737]">
                            <p class="text-sm text-gray-500">Por favor, suba el documento en formato PDF. Tamaño máximo: 10MB.</p>
                        <!-- boton para visualizar el archivo subido-->
                            <button type="button" id="visualizarDocumentoBtn"
                                    class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center w-max">
                                <i class="fas fa-eye mr-2"></i>Visualizar documento subido
                            </button>
                            <!-- boton para subir archivo -->
                            <button type="button" id="subirDocumentoBtn"
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center w-max">
                                <i class="fas fa-cloud-upload-alt mr-2"></i>Subir documento
                            </button>
                        </div>

                    </section>

                        <!-- Navegación -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formPagina6', 'pagina6', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar Borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto8.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button" id="enviarProyectoBtn"
                                    class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                                <i class="fas fa-paper-plane mr-2"></i>Enviar Proyecto
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <%@ include file="/footer.jsp" %>
    
    <script>
        // Función para contar palabras
        function contarPalabras(texto) {
            texto = texto.trim();
            if (texto === '') return 0;
            return texto.split(/\s+/).length;
        }

        // Configurar contador para un textarea
        function configurarContador(textareaId, contadorId, maxPalabras) {
            const textarea = document.getElementById(textareaId);
            const contador = document.getElementById(contadorId);
            
            if (!textarea || !contador) return;
            
            function actualizar() {
                const numPalabras = contarPalabras(textarea.value);
                contador.textContent = numPalabras + '/' + maxPalabras + ' palabras';
                
                // Cambiar colores
                if (numPalabras > maxPalabras) {
                    contador.className = 'word-counter warning';
                } else if (numPalabras === maxPalabras) {
                    contador.className = 'word-counter success';
                } else {
                    contador.className = 'word-counter';
                }
            }
            
            // Controlar el límite de palabras
            function controlarLimite(e) {
                const numPalabras = contarPalabras(textarea.value);
                
                if (numPalabras >= maxPalabras) {
                    // Permitir teclas de navegación y borrado
                    const teclasPermitidas = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Tab'];
                    
                    if (teclasPermitidas.includes(e.key) || e.ctrlKey || e.metaKey) {
                        return; // Permitir estas teclas
                    }
                    
                    // Si se intenta agregar más texto (espacio o letra)
                    if (e.key === ' ' || e.key.length === 1) {
                        e.preventDefault();
                        
                        // Mostrar mensaje temporal
                        contador.textContent = '⚠️ Límite alcanzado: ' + maxPalabras + ' palabras';
                        setTimeout(() => actualizar(), 2000);
                    }
                }
            }
            
            // Validar al pegar texto
            function controlarPegado(e) {
                e.preventDefault();
                const textoPegado = (e.clipboardData || window.clipboardData).getData('text');
                const textoActual = textarea.value;
                const inicio = textarea.selectionStart;
                const fin = textarea.selectionEnd;
                
                // Insertar el texto pegado
                const nuevoTexto = textoActual.substring(0, inicio) + textoPegado + textoActual.substring(fin);
                const palabrasNuevas = contarPalabras(nuevoTexto);
                
                if (palabrasNuevas <= maxPalabras) {
                    textarea.value = nuevoTexto;
                    textarea.setSelectionRange(inicio + textoPegado.length, inicio + textoPegado.length);
                } else {
                    // Calcular cuántas palabras se pueden agregar
                    const palabrasActuales = contarPalabras(textoActual);
                    const palabrasDisponibles = maxPalabras - palabrasActuales;
                    
                    if (palabrasDisponibles > 0) {
                        const palabrasPegadas = textoPegado.trim().split(/\s+/);
                        const palabrasPermitidas = palabrasPegadas.slice(0, palabrasDisponibles).join(' ');
                        
                        const nuevoTextoLimitado = textoActual.substring(0, inicio) + palabrasPermitidas + textoActual.substring(fin);
                        textarea.value = nuevoTextoLimitado;
                        textarea.setSelectionRange(inicio + palabrasPermitidas.length, inicio + palabrasPermitidas.length);
                    }
                    
                    contador.textContent = '⚠️ Límite alcanzado: ' + maxPalabras + ' palabras';
                    setTimeout(() => actualizar(), 2000);
                }
                
                actualizar();
            }
            
            // Escuchar cambios
            textarea.addEventListener('input', actualizar);
            textarea.addEventListener('keydown', controlarLimite);
            textarea.addEventListener('paste', controlarPegado);
            
            // Actualizar inicialmente
            actualizar();
        }

        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(input.value);
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = input.value;
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            // mostrar mensaje posicionado sobre el botón si se pasó targetBtn
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const elements = form.querySelectorAll('[name="' + key + '"]');
                    
                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                        } else if (element.type === 'radio') {
                            element.checked = element.value === data[key];
                        } else if (element.type !== 'file') {
                            element.value = data[key] || '';
                        }
                    });
                });
            }
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir control de navegación y protección contra abandono
        window.addEventListener('load', function() {
            // Configurar contadores de palabras aquí si es necesario
            // Ejemplo: configurarContador('campo-id', 'contador-id', maxPalabras);
            
            cargarBorrador('formPagina6', 'pagina6');

            const KEY = 'proyecto_borrador_pagina6_saved';
            const form = document.getElementById('formPagina6');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const enviarBtn = document.getElementById('enviarProyectoBtn') || buttons.find(b => /enviar proyecto/i.test(b.textContent));

            function setDisabled(btn, disabled){
                if(!btn) return;
                // No usar disabled real para que los eventos sigan funcionando
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                btn.setAttribute('data-disabled', disabled ? 'true' : 'false');
                if(disabled) {
                    btn.classList.add('opacity-60', 'cursor-not-allowed');
                    btn.classList.remove('hover:bg-green-700');
                } else {
                    btn.classList.remove('opacity-60', 'cursor-not-allowed');
                    btn.classList.add('hover:bg-green-700');
                }
            }

            if(!guardarBtn || !enviarBtn){
                console.warn('No se encontraron botones Guardar/Enviar en página6');
            }

            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(enviarBtn, !saved);

            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1');
                    saved = true;
                    setDisabled(enviarBtn, false);
                    console.log('Borrador pagina6 guardado -> Enviar habilitado');
                });
            }

            // Agregar evento al botón enviar para manejar navegación y advertencias
            if(enviarBtn){
                enviarBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Verificar si está "deshabilitado" (visualmente)
                    if(enviarBtn.getAttribute('data-disabled') === 'true'){
                        mostrarMensaje('Debe guardar el borrador antes de enviar el proyecto', 'error', enviarBtn);
                        return false;
                    }
                    
                    // Si está habilitado, guardar y enviar el proyecto
                    guardarBorrador('formPagina6', 'pagina6', guardarBtn);
                    mostrarMensaje('¡Proyecto enviado correctamente!', 'success');
                    setTimeout(function() {
                        // Aquí puedes redirigir a la página de éxito o procesar el envío
                        // window.location.href = '/proyectos/pages/exito.jsp';
                        console.log('Proyecto enviado');
                    }, 2000);
                });
            }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        setDisabled(enviarBtn, true);
                        console.log('Formulario pagina6 modificado después de guardar: Enviar bloqueado');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                // beforeunload
                window.addEventListener('beforeunload', function(e){
                    try{
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault(); e.returnValue = msg; return msg;
                        }
                    }catch(err){ return undefined; }
                });
            }
        });
    </script>
</body>
</html>