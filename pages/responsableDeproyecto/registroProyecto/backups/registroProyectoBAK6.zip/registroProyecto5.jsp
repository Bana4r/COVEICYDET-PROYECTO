<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro Proyecto - COVEICYDET</title>
  <!-- llama a tailwindcss -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <%@ include file="../header.jsp" %>
</head>
<body class="bg-gray-50 min-h-screen antialiased">
    <div class="max-w-5xl mx-auto px-4 py-10">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-[#B28854] p-6">
                <h1 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-box-open mr-3"></i>Partidas 5/5
                    </h1>
                <p class="text-white/90 mt-2">Desglose las partidas utilizadas durante el desarrollo del proyecto</p>
            </div>
            
            <form id="formPagina5" class="p-8 space-y-8" action="#" method="post">
                <div class="space-y-6">
                    <div>
                        <!-- Titulo de la sección -->
                        <h2 class="text-xl font-semibold text-gray-800 mb-4">Gasto corriente</h2>
                        <!-- desglose de partidas, pasajes y viaticos, servicios externos, gastos de operacion, gastos de trabajo de campo, registro de derechos de propiedad, gastos de capacitacion, publicaciones, ediciones e impreciones, actividades de difusion, gastos de gordinacion general (pago de estudiantes incorporados al proyectos)-->
                        <div class="space-y-4">
                            <div class="space-y-3">
                                <div class="flex items-center space-x-4">
                                    <label for="pasajesViaticos" class="w-1/2 text-sm font-medium text-gray-700">Pasajes y viáticos:</label>
                                    <input type="number" id="pasajesViaticos" name="pasajesViaticos" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="serviciosExternos" class="w-1/2 text-sm font-medium text-gray-700">Servicios externos:</label>
                                    <input type="number" id="serviciosExternos" name="serviciosExternos" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="gastosOperacion" class="w-1/2 text-sm font-medium text-gray-700">Gastos de operación:</label>
                                    <input type="number" id="gastosOperacion" name="gastosOperacion" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="gastosTrabajoCampo" class="w-1/2 text-sm font-medium text-gray-700">Gastos de trabajo de campo:</label>
                                    <input type="number" id="gastosTrabajoCampo" name="gastosTrabajoCampo" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="registroDerechosPropiedad" class="w-1/2 text-sm font-medium text-gray-700">Registro de derechos de propiedad:</label>
                                    <input type="number" id="registroDerechosPropiedad" name="registroDerechosPropiedad" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="gastosCapacitacion" class="w-1/2 text-sm font-medium text-gray-700">Gastos de capacitación:</label>
                                    <input type="number" id="gastosCapacitacion" name="gastosCapacitacion" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="publicacionesEdicionesImpresiones" class="w-1/2 text-sm font-medium text-gray-700">Publicaciones, ediciones e impresiones:</label>
                                    <input type="number" id="publicacionesEdicionesImpresiones" name="publicacionesEdicionesImpresiones" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="actividadesDifusion" class="w-1/2 text-sm font-medium text-gray-700">Actividades de difusión:</label>
                                    <input type="number" id="actividadesDifusion" name="actividadesDifusion" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <label for="gastosCoordinacionGeneral" class="w-1/2 text-sm font-medium text-gray-700">Gastos de coordinación general:</label>
                                    <input type="number" id="gastosCoordinacionGeneral" name="gastosCoordinacionGeneral" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                </div>
                            </div>
                            
                            <!-- Sección de gastos de inversión -->
                            <div class="mt-8">
                                <h2 class="text-xl font-semibold text-gray-800 mb-4">Gasto de inversión</h2>
                                <div class="space-y-3">
                                    <div class="flex items-center space-x-4">
                                        <label for="adquisicionesInstrumentosEquipoLaboratorio" class="w-1/2 text-sm font-medium text-gray-700">Maquinaria y equipo:</label>
                                        <input type="number" id="adquisicionesInstrumentosEquipoLaboratorio" name="adquisicionesInstrumentosEquipoLaboratorio" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <label for="adquisicionesInstrumentosEquipoLaboratorio" class="w-1/2 text-sm font-medium text-gray-700">Adquisiciones de instrumentos y equipo de laboratorio:</label>
                                        <input type="number" id="adquisicionesInstrumentosEquipoLaboratorio" name="adquisicionesInstrumentosEquipoLaboratorio" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <label for="adquisicionEquiposPlantaPiloto" class="w-1/2 text-sm font-medium text-gray-700">Adquisición de equipos para planta piloto:</label>
                                        <input type="number" id="adquisicionEquiposPlantaPiloto" name="adquisicionEquiposPlantaPiloto" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <label for="adquisicionEquiposComputo" class="w-1/2 text-sm font-medium text-gray-700">Adquisición de equipos de cómputo:</label>
                                        <input type="number" id="adquisicionEquiposComputo" name="adquisicionEquiposComputo" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 focus:ring-[#B28854] focus:border-[#B28854]" min="0" step="0.01" placeholder="0.00" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- total -->
                <div class="flex items-center space-x-4">
                    <label class="w-1/2 text-lg font-semibold text-gray-800">Total presupuesto del proyecto:</label>
                    <input type="number" id="totalPresupuesto" name="totalPresupuesto" class="w-1/2 border border-gray-300 rounded-md shadow-sm p-2 bg-gray-100 text-gray-700 font-semibold" value="0.00" readonly> 
                </div>

                <!-- Botones de navegación -->
                <div class="flex justify-between pt-6 border-t border-gray-200">
                <button type="button" class="flex items-center px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-lg transition-colors duration-200" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto4.jsp'">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Anterior
                </button>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="guardarBorrador('formPagina5', 'pagina5', this)" class="flex items-center px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white font-medium rounded-lg transition-colors duration-200">
                        <i class="fas fa-save mr-2"></i>
                        Guardar borrador
                    </button>
                    <button type="button" onclick="enviarProyecto()" class="flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors duration-200">
                        <i class="fas fa-paper-plane mr-2"></i>
                        Enviar proyecto
                    </button>
                </div>
            </div>
            </form>
        </div>
    </div>
    
    <script>
        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(input.value);
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = input.value;
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const elements = form.querySelectorAll('[name="' + key + '"]');
                    
                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                        } else if (element.type === 'radio') {
                            element.checked = element.value === data[key];
                        } else if (element.type !== 'file') {
                            element.value = data[key] || '';
                        }
                    });
                });
                
                // Recalcular el total después de cargar los datos
                setTimeout(calcularTotalPresupuesto, 100);
            }
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Función para calcular el total de todas las partidas
        function calcularTotalPresupuesto() {
            // Lista de todos los IDs de campos de partidas
            const camposPartidas = [
                'pasajesViaticos',
                'serviciosExternos',
                'gastosOperacion',
                'gastosTrabajoCampo',
                'registroDerechosPropiedad',
                'gastosCapacitacion',
                'publicacionesEdicionesImpresiones',
                'actividadesDifusion',
                'gastosCoordinacionGeneral',
                'adquisicionesInstrumentosEquipoLaboratorio',
                'adquisicionEquiposPlantaPiloto',
                'adquisicionEquiposComputo'
            ];

            let total = 0;
            
            // Sumar todos los valores
            camposPartidas.forEach(function(campo) {
                const elemento = document.getElementById(campo);
                if (elemento) {
                    const valor = parseFloat(elemento.value) || 0;
                    total += valor;
                }
            });

            // Actualizar el campo de total
            const campoTotal = document.getElementById('totalPresupuesto');
            if (campoTotal) {
                campoTotal.value = total.toFixed(2);
            }
            
            return total;
        }

        // Función para agregar event listeners a todos los campos de partidas
        function inicializarCalculadoraTotal() {
            const camposPartidas = [
                'pasajesViaticos',
                'serviciosExternos',
                'gastosOperacion',
                'gastosTrabajoCampo',
                'registroDerechosPropiedad',
                'gastosCapacitacion',
                'publicacionesEdicionesImpresiones',
                'actividadesDifusion',
                'gastosCoordinacionGeneral',
                'adquisicionesInstrumentosEquipoLaboratorio',
                'adquisicionEquiposPlantaPiloto',
                'adquisicionEquiposComputo'
            ];

            // Agregar event listeners para recalcular cuando cambien los valores
            camposPartidas.forEach(function(campo) {
                const elemento = document.getElementById(campo);
                if (elemento) {
                    elemento.addEventListener('input', calcularTotalPresupuesto);
                    elemento.addEventListener('change', calcularTotalPresupuesto);
                }
            });

            // Calcular total inicial
            calcularTotalPresupuesto();
        }

        function enviarProyecto() {
            // Primero guardar la página actual
            guardarBorrador('formPagina5', 'pagina5');
            
            // Recopilar datos de todas las páginas
            const datosCompletos = {
                pagina1: JSON.parse(localStorage.getItem('proyecto_borrador_pagina1') || '{}'),
                pagina2: JSON.parse(localStorage.getItem('proyecto_borrador_pagina2') || '{}'),
                pagina3: JSON.parse(localStorage.getItem('proyecto_borrador_pagina3') || '{}'),
                pagina4: JSON.parse(localStorage.getItem('proyecto_borrador_pagina4') || '{}'),
                pagina5: JSON.parse(localStorage.getItem('proyecto_borrador_pagina5') || '{}')
            };
            
            // Debug: Mostrar datos del cronograma antes del envío
            console.log('Datos completos antes del envío:', datosCompletos);
            console.log('Datos de página 3:', datosCompletos.pagina3);
            console.log('Cronograma específico:', datosCompletos.pagina3.cronograma);
            
            // Verificar si hay cronograma
            if (datosCompletos.pagina3.cronograma && Array.isArray(datosCompletos.pagina3.cronograma)) {
                console.log('Cronograma encontrado con ' + datosCompletos.pagina3.cronograma.length + ' actividades');
                datosCompletos.pagina3.cronograma.forEach((actividad, index) => {
                    console.log('Actividad ' + index + ':', actividad);
                });
            } else {
                console.log('No se encontró cronograma o no es un array');
            }

            // Validar que tenemos datos básicos
            if (!datosCompletos.pagina1.institucion || !datosCompletos.pagina2['resumen-ejecutivo']) {
                mostrarMensaje('Por favor complete al menos la información básica en las primeras páginas', 'error');
                return;
            }

            // Mostrar indicador de carga
            const enviarBtn = event.target;
            enviarBtn.disabled = true;
            enviarBtn.textContent = 'Enviando...';

            // Crear formulario para envío
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'procesar_proyecto.jsp';

            // Agregar datos como campos ocultos
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'datosProyecto';
            input.value = JSON.stringify(datosCompletos);
            form.appendChild(input);

            // Debug: Mostrar el JSON final que se envía
            console.log('JSON final enviado:', input.value);

            // Enviar
            document.body.appendChild(form);
            form.submit();
        }

        // Cargar borrador y añadir control de navegación y protección contra abandono
        window.addEventListener('load', function() {
            cargarBorrador('formPagina5', 'pagina5');
            
            // Inicializar la calculadora de totales
            inicializarCalculadoraTotal();

            const KEY = 'proyecto_borrador_pagina5_saved';
            const form = document.getElementById('formPagina5');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));

            let saved = localStorage.getItem(KEY) === '1';

            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1');
                    saved = true;
                    console.log('Borrador pagina5 guardado');
                });
            }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY,'0');
                        console.log('Formulario pagina5 modificado después de guardar');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                window.addEventListener('beforeunload', function(e) {
                    try {
                        if(!saved){
                            var msg = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault();
                            e.returnValue = msg;
                            return msg;
                        }
                    } catch (err) {
                        return undefined;
                    }
                });
            }
        });
    </script>
    <%@ include file="/footer.jsp" %>
</body>
