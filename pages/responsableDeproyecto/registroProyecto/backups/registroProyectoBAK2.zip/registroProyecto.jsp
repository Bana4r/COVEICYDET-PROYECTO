<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<%@ include file="../header.jsp" %>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Registro de Proyecto</title>    
    
    
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <form id="formPagina1" class="bg-white border border-slate-200 rounded-xl shadow-sm px-8 py-10 space-y-10">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Datos generales 1/4</h1>
            <h3 class="text-sm text-gray-500">Complete cada seccion (todos los campos son necesarios)</h3>
        </div>
            <!-- institucion proponente -->
            <div class="mb-4">
                <label for="institucion" class="block text-sm font-medium text-gray-700">Institución Proponente</label>
                <input type="text" id="institucion" name="institucion" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">

            <!-- area de adcripsion -->
            <div class="mb-4">
                <label for="area" class="block text-sm font-medium text-gray-700 mt-4">Área de Adscripción</label>
                <input type="text" id="area" name="area" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
            </div>

            <!-- Responsable de la propuesta -->
            <div class="mb-4">
                <label for="responsable" class="block text-sm font-medium text-gray-700 mt-4">Responsable de la Propuesta</label>
                <!-- una tabla en la que hay 3 usuarios representante legal, tecnico y administrativo, se les pide nombre, correo y numero de telefono -->
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Correo</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teléfono</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">Representante Legal</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="text" name="nombreLegal" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="email" name="correoLegal" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="tel" name="telefonoLegal" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                        </tr>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">Representante Técnico</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="text" name="nombreTecnico" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="email" name="correoTecnico" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="tel" name="telefonoTecnico" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                        </tr>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">Representante Administrativo</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="text" name="nombreAdministrativo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="email" name="correoAdministrativo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="tel" name="telefonoAdministrativo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- convocatoria, Atención a temas prioritarios del PVD 2025 o Programas estratégicos nacionales 2025 -->
            <div class="mt-4">
                <label for="convocatoria" class="block text-sm font-medium text-gray-700">Convocatoria</label>
                <select id="convocatoria" name="convocatoria" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    <option value="">Seleccione una opción</option>
                    <option value="pvd2025">Atención a temas prioritarios del PVD 2025</option>
                    <option value="programasEstrategicos">Programas estratégicos nacionales 2025</option>
                </select>
            </div>

            <!-- area de conocimiento, Físico-Matemáticas y Ciencias de la Tierra, Biología y Química, Medicina y Ciencias de la Salud, Ciencias de la Conducta y la Educación, Humanidades, Ciencias Sociales, Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas, Ingenierías y Desarrollo Tecnológico, Interdisciplinaria -->
            <div class="mt-4">
                <label for="areaConocimiento" class="block text-sm font-medium text-gray-700">Área de Conocimiento</label>
                <select id="areaConocimiento" name="areaConocimiento" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    <option value="">Seleccione una opción</option>
                    <option value="fisicoMatematicas">Físico-Matemáticas y Ciencias de la Tierra</option>
                    <option value="biologiaQuimica">Biología y Química</option>
                    <option value="medicinaCienciasSalud">Medicina y Ciencias de la Salud</option>
                    <option value="cienciasConductaEducacion">Ciencias de la Conducta y la Educación</option>
                    <option value="humanidades">Humanidades</option>
                    <option value="cienciasSociales">Ciencias Sociales</option>
                    <option value="cienciasAgricultura">Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas</option>
                    <option value="ingenieriasDesarrollo">Ingenierías y Desarrollo Tecnológico</option>
                    <option value="interdisciplinaria">Interdisciplinaria</option>
                </select>
            </div>

            <!-- sector de desarrollo, Acuicultura, Agrícola – agroindustrial, Alimentos, Ambiente, Educación, Electrónica, Energía, Ingeniería, Medicina y farmacéutica y Química -->
            <div class="mt-4">
                <label for="sectorDesarrollo" class="block text-sm font-medium text-gray-700">Sector de Desarrollo</label>
                <select id="sectorDesarrollo" name="sectorDesarrollo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    <option value="">Seleccione una opción</option>
                    <option value="acuicultura">Acuicultura</option>
                    <option value="agricola">Agrícola – agroindustrial</option>
                    <option value="alimentos">Alimentos</option>
                    <option value="ambiente">Ambiente</option>
                    <option value="educacion">Educación</option>
                    <option value="electronica">Electrónica</option>
                    <option value="energia">Energía</option>
                    <option value="ingenieria">Ingeniería</option>
                    <option value="medicina">Medicina y farmacéutica</option>
                    <option value="quimica">Química</option>
                </select>
            </div>

            <!-- Nivel de Maduración -->
            <div class="mt-6">
                <label class="block text-sm font-medium text-gray-700 mb-4">Nivel de Maduración (tecnológico y/o social)</label>
                <p class="text-sm text-gray-600 mb-4">Marque con una "X" el nivel de maduración tecnológico y social en el que se encuentra su proyecto.</p>
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- TRL - Niveles de Maduración Tecnológica -->
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h4 class="text-lg font-semibold text-blue-800 mb-3">Niveles de Maduración Tecnológica</h4>
                        <div class="space-y-2">
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl1" name="nivelMaduracion" value="TRL1" class="mt-1">
                                <label for="trl1" class="text-sm">
                                    <span class="font-semibold">TRL 1:</span> Principios básicos observados y reportados. Investigación básica.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl2" name="nivelMaduracion" value="TRL2" class="mt-1">
                                <label for="trl2" class="text-sm">
                                    <span class="font-semibold">TRL 2:</span> Concepto y aplicación formulada.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl3" name="nivelMaduracion" value="TRL3" class="mt-1">
                                <label for="trl3" class="text-sm">
                                    <span class="font-semibold">TRL 3:</span> Prueba de concepto.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl4" name="nivelMaduracion" value="TRL4" class="mt-1">
                                <label for="trl4" class="text-sm">
                                    <span class="font-semibold">TRL 4:</span> Validación de componentes a nivel laboratorio/campo.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl5" name="nivelMaduracion" value="TRL5" class="mt-1">
                                <label for="trl5" class="text-sm">
                                    <span class="font-semibold">TRL 5:</span> Validación de componentes en un entorno relevante.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl6" name="nivelMaduracion" value="TRL6" class="mt-1">
                                <label for="trl6" class="text-sm">
                                    <span class="font-semibold">TRL 6:</span> Demostración tecnológica en un ambiente relevante.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl7" name="nivelMaduracion" value="TRL7" class="mt-1">
                                <label for="trl7" class="text-sm">
                                    <span class="font-semibold">TRL 7:</span> Demostración de prototipo a nivel sistema en un ambiente operativo real.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl8" name="nivelMaduracion" value="TRL8" class="mt-1">
                                <label for="trl8" class="text-sm">
                                    <span class="font-semibold">TRL 8:</span> Desarrollo de producto completo y evaluado.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="trl9" name="nivelMaduracion" value="TRL9" class="mt-1">
                                <label for="trl9" class="text-sm">
                                    <span class="font-semibold">TRL 9:</span> Producto terminado con éxito en el entorno real.
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- SRL - Niveles de Maduración Social -->
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h4 class="text-lg font-semibold text-green-800 mb-3">SRL: Niveles de Maduración Social</h4>
                        <div class="space-y-2">
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl1" name="nivelMaduracion" value="SRL1" class="mt-1">
                                <label for="srl1" class="text-sm">
                                    <span class="font-semibold">SRL 1:</span> Identificación del problema y su impacto social.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl2" name="nivelMaduracion" value="SRL2" class="mt-1">
                                <label for="srl2" class="text-sm">
                                    <span class="font-semibold">SRL 2:</span> Formulación del problema, propuesta de soluciones e impacto potencial.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl3" name="nivelMaduracion" value="SRL3" class="mt-1">
                                <label for="srl3" class="text-sm">
                                    <span class="font-semibold">SRL 3:</span> Inicio de pruebas en campo con el grupo de interés.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl4" name="nivelMaduracion" value="SRL4" class="mt-1">
                                <label for="srl4" class="text-sm">
                                    <span class="font-semibold">SRL 4:</span> Problema validado mediante prueba piloto en entorno relevante.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl5" name="nivelMaduracion" value="SRL5" class="mt-1">
                                <label for="srl5" class="text-sm">
                                    <span class="font-semibold">SRL 5:</span> Solución validada por el grupo de interés relevante en el área.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl6" name="nivelMaduracion" value="SRL6" class="mt-1">
                                <label for="srl6" class="text-sm">
                                    <span class="font-semibold">SRL 6:</span> Adopción de la solución.
                                </label>
                            </div>
                            <div class="flex items-start space-x-3">
                                <input type="radio" id="srl7" name="nivelMaduracion" value="SRL7" class="mt-1">
                                <label for="srl7" class="text-sm">
                                    <span class="font-semibold">SRL 7:</span> Impacto social.
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Documento probatorio -->
                <div class="mt-4">
                    <label for="documentoProbatorio" class="block text-sm font-medium text-gray-700 mb-2">Documento probatorio (PDF)</label>
                    <input type="file" id="documentoProbatorio" name="documentoProbatorio" accept=".pdf" 
                           class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                    <p class="text-xs text-gray-500 mt-1">Adjunte documento que acredite el nivel de maduración seleccionado</p>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="flex justify-end mt-8 pt-6 border-t border-gray-200">
                <div class="flex space-x-4">
                    <button type="button" onclick="guardarBorrador('formPagina1', 'pagina1')" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg">
                        Guardar Borrador
                    </button>
                    <button type="button" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto2.jsp'">
                        Siguiente
                    </button>
                </div>
            </div>

        </form>
    </div>
    <script>
        // Función para guardar datos del formulario en localStorage
        function guardarBorrador(formId, pageKey) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(input.value);
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = input.value;
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success');
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const elements = form.querySelectorAll('[name="' + key + '"]');
                    
                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                        } else if (element.type === 'radio') {
                            element.checked = element.value === data[key];
                        } else if (element.type !== 'file') {
                            element.value = data[key] || '';
                        }
                    });
                });
            }
        }

        function mostrarMensaje(mensaje, tipo = 'info') {
            const messageDiv = document.createElement('div');
            let className = 'fixed top-4 right-4 p-4 rounded-md shadow-lg z-50 ';
            
            if (tipo === 'success') {
                className += 'bg-green-100 text-green-800 border border-green-200';
            } else if (tipo === 'error') {
                className += 'bg-red-100 text-red-800 border border-red-200';
            } else {
                className += 'bg-blue-100 text-blue-800 border border-blue-200';
            }
            
            messageDiv.className = className;
            messageDiv.textContent = mensaje;
            
            document.body.appendChild(messageDiv);
            
            setTimeout(() => {
                messageDiv.remove();
            }, 3000);
        }

        // Cargar borrador al cargar la página
        window.addEventListener('load', function() {
            cargarBorrador('formPagina1', 'pagina1');
        });
    </script>
</body>
</html>
