<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<%@ include file="../header.jsp" %>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Justificación y objetivos</title>
</head>
<body class="bg-slate-100 min-h-screen antialiased font-sans">
  <div class="max-w-5xl mx-auto px-4 py-10">
    <form id="formPagina2" class="bg-white border border-slate-200 rounded-xl shadow-sm px-8 py-10 space-y-10">
      <header class="space-y-2">
        <h3 class="text-2xl font-semibold text-slate-800 tracking-tight">Justificación y objetivos 2/4</h3>
        <p class="text-sm text-slate-500">Complete cada sección (todos los campos son obligatorios).</p>
      </header>

      <!-- Grupo 1 -->
      <section class="space-y-6">
        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Descripción General</h4>

        <div class="space-y-2">
          <label for="resumen-ejecutivo" class="text-sm font-medium text-slate-700">Resumen Ejecutivo <span class="text-rose-600">*</span></label>
          <textarea id="resumen-ejecutivo" name="resumen-ejecutivo" rows="5"
            placeholder="Describa brevemente el proyecto, alcance, impacto y resultados esperados."
            class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40 resize-y"></textarea>
          <small class="text-[11px] font-semibold tracking-wide text-slate-400">Máx. 1000 caracteres</small>
        </div>

        <div class="space-y-2">
          <label for="antecedentes" class="text-sm font-medium text-slate-700">Antecedentes <span class="text-rose-600">*</span></label>
          <textarea id="antecedentes" name="antecedentes" rows="5"
            placeholder="Contexto previo, estudios, situación actual."
            class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>
        </div>

        <div class="space-y-2">
          <label for="pertinencia" class="text-sm font-medium text-slate-700">Pertinencia <span class="text-rose-600">*</span></label>
          <textarea id="pertinencia" name="pertinencia" rows="4"
            placeholder="Justifique la relevancia y necesidad del proyecto."
            class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>
        </div>
      </section>

      <!-- Grupo 2 -->
      <section class="space-y-6">
        <h4 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Fundamentación</h4>

        <div class="space-y-2">
          <label for="preguntas-investigacion" class="text-sm font-medium text-slate-700">Preguntas de Investigación <span class="text-rose-600">*</span></label>
          <textarea id="preguntas-investigacion" name="preguntas-investigacion" rows="4"
            placeholder="Enumere preguntas clave (una por línea)."
            class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>
        </div>

        <div class="grid gap-6 md:grid-cols-2">
          <div class="space-y-2">
            <label for="objetivo-general" class="text-sm font-medium text-slate-700">Objetivo General <span class="text-rose-600">*</span></label>
            <textarea id="objetivo-general" name="objetivo-general" rows="4"
              placeholder="Redacte el objetivo general del proyecto."
              class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>
          </div>
          <div class="space-y-2">
            <label for="objetivos-especificos" class="text-sm font-medium text-slate-700">Objetivos Específicos <span class="text-rose-600">*</span></label>
            <textarea id="objetivos-especificos" name="objetivos-especificos" rows="4"
              placeholder="Enumere objetivos específicos (uno por línea)."
              class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>
          </div>
        </div>
      </section>

      <!-- Navegación -->
      <div class="flex flex-col-reverse gap-3 pt-6 border-t border-slate-200 sm:flex-row sm:justify-end">
        <button type="button" onclick="guardarBorrador('formPagina2', 'pagina2')"
                class="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500/50">
          Guardar borrador
        </button>
        <div class="flex gap-3 sm:ml-4">
          <button type="button"
                  class="inline-flex items-center justify-center rounded-md bg-slate-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500/50" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto.jsp'">
            Anterior
          </button>
          <button type="button"
                  class="inline-flex items-center justify-center rounded-md bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/60" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto3.jsp'">
            Siguiente
          </button>
        </div>
      </div>
    </form>
  </div>
  <script>
    // Agregar las funciones JavaScript aquí (mismas que en la página 1)
    function guardarBorrador(formId, pageKey) {
        const form = document.getElementById(formId);
        const data = {};
        
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            if (input.type === 'checkbox') {
                if (!data[input.name]) data[input.name] = [];
                if (input.checked) {
                    data[input.name].push(input.value);
                }
            } else if (input.type === 'radio') {
                if (input.checked) {
                    data[input.name] = input.value;
                }
            } else if (input.type === 'file') {
                data[input.name] = input.files[0] ? input.files[0].name : '';
            } else {
                data[input.name] = input.value;
            }
        });
        
        localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
        mostrarMensaje('Borrador guardado exitosamente', 'success');
    }

    function cargarBorrador(formId, pageKey) {
        const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
        
        if (savedData) {
            const data = JSON.parse(savedData);
            const form = document.getElementById(formId);
            
            Object.keys(data).forEach(key => {
                const elements = form.querySelectorAll('[name="' + key + '"]');
                
                elements.forEach(element => {
                    if (element.type === 'checkbox') {
                        element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                    } else if (element.type === 'radio') {
                        element.checked = element.value === data[key];
                    } else if (element.type !== 'file') {
                        element.value = data[key] || '';
                    }
                });
            });
        }
    }

    function mostrarMensaje(mensaje, tipo = 'info') {
        const messageDiv = document.createElement('div');
        let className = 'fixed top-4 right-4 p-4 rounded-md shadow-lg z-50 ';
        
        if (tipo === 'success') {
            className += 'bg-green-100 text-green-800 border border-green-200';
        } else if (tipo === 'error') {
            className += 'bg-red-100 text-red-800 border border-red-200';
        } else {
            className += 'bg-blue-100 text-blue-800 border border-blue-200';
        }
        
        messageDiv.className = className;
        messageDiv.textContent = mensaje;
        
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.remove();
        }, 3000);
    }

    // Cargar borrador al cargar la página
    window.addEventListener('load', function() {
        cargarBorrador('formPagina2', 'pagina2');
    });
  </script>
  <%@ include file="/footer.jsp" %>
</body>
</html>