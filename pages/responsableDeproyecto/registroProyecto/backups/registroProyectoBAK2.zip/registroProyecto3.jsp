<!-- se usa Tailwind CSS para el diseño y estilo de la interfaz -->
<!DOCTYPE html>
<html lang="es">
<%@ include file="../header.jsp" %>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Planeacion y evaluacion</title>
</head>
<body class="bg-slate-100 min-h-screen antialiased font-sans">
    <div class="max-w-5xl mx-auto px-4 py-10">
        <form id="formPagina3" class="space-y-8 bg-white p-8 rounded-xl shadow-sm border border-slate-200" action="#" method="post">
            <h1 class="text-2xl font-semibold text-slate-800">Planeacion y evaluacion 3/4</h1>

            <!-- cronograma de actividades, sera un lugar donde se podra subir un archivo -->
            <div class="space-y-1">
                <label for="cronograma" class="block text-sm font-medium text-slate-700">Cronograma de Actividades</label>
                <div class="flex items-center space-x-4">
                    <button type="button" onclick="openCronogramaModal()" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md cursor-pointer">
                        Realizar cronograma
                    </button>
                </div>
            </div>

            <!-- Factores de riesgo y mitigacion -->
            <div class="space-y-1">
                <label for="factores-riesgo" class="block text-sm font-medium text-slate-700">Factores de Riesgo y Mitigación</label>
                <textarea id="factores-riesgo" name="factores-riesgo" rows="4" required
                          placeholder="Describa los principales factores de riesgo y sus estrategias de mitigación."
                          class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>

            </div>

            <!-- Referencias bibliograficas -->
            <div class="space-y-1">
                <label for="referencias" class="block text-sm font-medium text-slate-700">Referencias Bibliográficas</label>
                <textarea id="referencias" name="referencias" rows="4" required
                          placeholder="Incluya las referencias bibliográficas utilizadas."
                          class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>

            </div>

            <!-- vinculacion institucional -->
            <div class="space-y-1">
                <label for="vinculacion-institucional" class="block text-sm font-medium text-slate-700">Vinculación Institucional</label>
                <textarea id="vinculacion-institucional" name="vinculacion-institucional" rows="4" required
                          placeholder="Describa la vinculación institucional del proyecto."
                          class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>

            </div>

            <!-- Resultados esperados -->
            <div class="space-y-1">
                <label for="resultados" class="block text-sm font-medium text-slate-700">Resultados Esperados</label>
                <textarea id="resultados" name="resultados" rows="4" required
                          placeholder="Describa los resultados esperados del proyecto."
                          class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>

            </div>

            <!-- Areas de impacto -->
            <div class="space-y-1">
                <label for="areas-impacto" class="block text-sm font-medium text-slate-700">Áreas de Impacto</label>
                <textarea id="areas-impacto" name="areas-impacto" rows="4" required
                          placeholder="Describa las áreas de impacto del proyecto."
                          class="block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40"></textarea>

            </div>

            <!-- botones de guardar borrador y siguiente-->
            <div class="flex justify-between mt-4">
                <div class="coveic-hide-original flex ml-auto space-x-3">
                    <button type="button" onclick="guardarBorrador('formPagina3', 'pagina3')" class="inline-flex items-center justify-center rounded-md border border-transparent bg-gray-300 px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                        Guardar Borrador
                    </button>
                    <button type="button"
                    class="inline-flex items-center justify-center rounded-md bg-slate-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500/50" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto2.jsp'">
                        Anterior
                    </button>
                    <button type="button" class="inline-flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto4.jsp'">
                        Siguiente
                    </button>
                </div>
            </div>

        </form>
    </div>

    <!-- Modal para cronograma -->
    <div id="cronogramaModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <!-- Header del modal -->
                <div class="flex items-center justify-between p-6 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">Cronograma de Actividades</h3>
                    <button type="button" onclick="closeCronogramaModal()" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                
                <!-- Contenido del modal -->
                <div class="p-6">
                    <form id="cronogramaForm">
                        
                        <!-- Tabla para crear cronograma -->
                        <div class="overflow-x-auto">
                            <table class="min-w-full border border-gray-300">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 border border-gray-300 text-left text-sm font-medium text-gray-900">Actividad</th>
                                        <th class="px-4 py-2 border border-gray-300 text-left text-sm font-medium text-gray-900">Trimestre</th>
                                        <th class="px-4 py-2 border border-gray-300 text-left text-sm font-medium text-gray-900">Meta</th>
                                        <th class="px-4 py-2 border border-gray-300 text-left text-sm font-medium text-gray-900">Entregable</th>
                                        <th class="px-4 py-2 border border-gray-300 text-left text-sm font-medium text-gray-900">Fecha Entrega</th>
                                        <th class="px-4 py-2 border border-gray-300 text-center text-sm font-medium text-gray-900">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="cronogramaTableBody">
                                    <tr>
                                        <td class="px-4 py-2 border border-gray-300">
                                            <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                                        </td>
                                        <td class="px-4 py-2 border border-gray-300">
                                            <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                                        </td>
                                        <td class="px-4 py-2 border border-gray-300">
                                            <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                                        </td>
                                        <td class="px-4 py-2 border border-gray-300">
                                            <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                                        </td>
                                        <td class="px-4 py-2 border border-gray-300">
                                            <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                                        </td>
                                        <td class="px-4 py-2 border border-gray-300 text-center">
                                            <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Botón para agregar fila -->
                        <div class="mt-4">
                            <button type="button" onclick="addRow()" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Agregar Actividad
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Footer del modal -->
                <div class="flex justify-end space-x-3 p-6 border-t border-gray-200">
                    <button type="button" onclick="closeCronogramaModal()" class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Cancelar
                    </button>
                    <button type="button" onclick="saveCronograma()" class="px-4 py-2 bg-blue-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-blue-700">
                        Guardar Cronograma
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Utilidades para normalizar valores que llegan como 'false'/false/null
        function isFalseyString(v) {
            return v === false || v === 'false' || v === 'null' || v === 'undefined' || v === 'NaN';
        }
        function safe(v) {
            return (v == null || isFalseyString(v)) ? '' : String(v);
        }

        function openCronogramaModal() {
            document.getElementById('cronogramaModal').classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Evita scroll del body
        }

        function closeCronogramaModal() {
            document.getElementById('cronogramaModal').classList.add('hidden');
            document.body.style.overflow = 'auto'; // Restaura scroll del body
        }

        function addRow() {
            const tableBody = document.getElementById('cronogramaTableBody');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                </td>
                <td class="px-4 py-2 border border-gray-300 text-center">
                    <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                    </button>
                </td>
            `;
            tableBody.appendChild(newRow);
        }

        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
        }

        function saveCronograma() {
            // Guardar el cronograma y también actualizar el borrador
            guardarBorrador('formPagina3', 'pagina3');
            mostrarMensaje('Cronograma guardado exitosamente', 'success');
            closeCronogramaModal();
        }

        // Cerrar modal al hacer click fuera de él
        document.getElementById('cronogramaModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeCronogramaModal();
            }
        });

        // Funciones para guardar y cargar borradores
        function guardarBorrador(formId, pageKey) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(safe(input.value));
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = safe(input.value);
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = safe(input.value);
                }
            });
            
            // Guardar datos del cronograma
            const cronogramaData = [];
            const tableBody = document.getElementById('cronogramaTableBody');
            const rows = tableBody.querySelectorAll('tr');
            
            rows.forEach(row => {
                const inputs = row.querySelectorAll('input');
                if (inputs.length >= 5) {
                    const rowData = {
                        actividad: safe(inputs[0].value),
                        mes: safe(inputs[1].value),
                        meta: safe(inputs[2].value),
                        entregable: safe(inputs[3].value),
                        fecha_entrega: safe(inputs[4].value)
                    };
                    // Solo guardar si al menos uno de los campos tiene datos
                    if (rowData.actividad || rowData.mes || rowData.meta || rowData.entregable || rowData.fecha_entrega) {
                        cronogramaData.push(rowData);
                    }
                }
            });
            
            data.cronograma = cronogramaData;
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success');
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                try {
                    const raw = JSON.parse(savedData);
                    // Limpieza defensiva contra valores 'false' persistidos previamente
                    const data = {};
                    Object.keys(raw).forEach(k => {
                        if (k === 'cronograma') {
                            const arr = Array.isArray(raw[k]) ? raw[k] : [];
                            data[k] = arr.map(r => ({
                                actividad: safe(r && r.actividad),
                                mes: safe(r && r.mes),
                                meta: safe(r && r.meta),
                                entregable: safe(r && r.entregable),
                                fecha_entrega: safe(r && r.fecha_entrega)
                            }));
                        } else {
                            data[k] = safe(raw[k]);
                        }
                    });
                    // Reescribir el borrador ya limpiado para evitar que regrese 'false'
                    localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
                    const form = document.getElementById(formId);
                    
                    Object.keys(data).forEach(key => {
                        if (key === 'cronograma') {
                            // Cargar datos del cronograma
                            cargarCronograma(data[key]);
                        } else {
                            const elements = form.querySelectorAll('[name="' + key + '"]');
                            
                            elements.forEach(element => {
                                if (element.type === 'checkbox') {
                                    element.checked = Array.isArray(data[key]) && data[key].includes(safe(element.value));
                                } else if (element.type === 'radio') {
                                    element.checked = safe(element.value) === data[key];
                                } else if (element.type !== 'file') {
                                    element.value = data[key] || '';
                                }
                            });
                        }
                    });
                } catch (error) {
                    console.error('Error al cargar el borrador:', error);
                    // Si hay error, crear una fila vacía en el cronograma
                    const tableBody = document.getElementById('cronogramaTableBody');
                    if (tableBody.children.length === 0) {
                        addRow();
                    }
                }
            } else {
                // Si no hay datos guardados, asegurarse de que haya al menos una fila en el cronograma
                const tableBody = document.getElementById('cronogramaTableBody');
                if (tableBody.children.length === 0) {
                    addRow();
                }
            }
        }

        function cargarCronograma(cronogramaData) {
            const tableBody = document.getElementById('cronogramaTableBody');
            tableBody.innerHTML = '';

            if (!Array.isArray(cronogramaData) || cronogramaData.length === 0) {
                addRow();
                return;
            }

            cronogramaData.forEach(rowData => {
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                    </td>
                    <td class="px-4 py-2 border border-gray-300 text-center">
                        <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                        </button>
                    </td>
                `;
                const inputs = newRow.querySelectorAll('input');
                inputs[0].value = safe(rowData.actividad);
                inputs[1].value = safe(rowData.mes);
                inputs[2].value = safe(rowData.meta);
                inputs[3].value = safe(rowData.entregable);
                inputs[4].value = safe(rowData.fecha_entrega);

                tableBody.appendChild(newRow);
            });
        }

        function mostrarMensaje(mensaje, tipo = 'info') {
            const messageDiv = document.createElement('div');
            let className = 'fixed top-4 right-4 p-4 rounded-md shadow-lg z-50 ';
            
            if (tipo === 'success') {
                className += 'bg-green-100 text-green-800 border border-green-200';
            } else if (tipo === 'error') {
                className += 'bg-red-100 text-red-800 border border-red-200';
            } else {
                className += 'bg-blue-100 text-blue-800 border border-blue-200';
            }
            
            messageDiv.className = className;
            messageDiv.textContent = mensaje;
            
            document.body.appendChild(messageDiv);
            
            setTimeout(() => {
                messageDiv.remove();
            }, 3000);
        }

        // Cargar borrador al cargar la página
        window.addEventListener('load', function() {
            cargarBorrador('formPagina3', 'pagina3');
        });
    </script>

    <%@ include file="/footer.jsp" %>
</body>
</html>