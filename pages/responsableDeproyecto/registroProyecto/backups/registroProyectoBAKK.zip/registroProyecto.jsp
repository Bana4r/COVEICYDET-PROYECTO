<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.util.regex.*" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<%!
    private static final String DB_URL = "jdbc:postgresql://coveicydetsysdev.ddns.net:5432/proyectos";
    private static final String DB_USER = "dbusr25";
    private static final String DB_PASSWORD = "mxToro24000Chocolate";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    // funcion para obtener la lista de municipios
    private List<String> obtenerMunicipios() {
        List<String> municipios = new ArrayList<>();
        String sql = "SELECT municipio FROM municipios ORDER BY id";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                municipios.add(rs.getString("municipio"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return municipios;
    }
%>  

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Registro de Proyecto - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .table-input {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.5rem;
            width: 100%;
            font-size: 0.875rem;
        }
        
        .table-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 2px rgba(122, 23, 55, 0.2);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-file-alt mr-3"></i>Datos generales 1/5
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Complete cada sección (todos los campos son necesarios)
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formPagina1" class="p-8 space-y-8">
                    <!-- Institución proponente -->
                    <div>
                        <label for="institucion" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-university text-[#7A1737] mr-2"></i>Institución Proponente
                            <span class="ml-2 text-gray-500 cursor-help" title="Ingrese el nombre completo de la institución que propone el proyecto">
                                <i class="fas fa-question-circle"></i>
                            </span>
                        </label>
                        <input type="text" id="institucion" name="institucion" required 
                               class="floating-input" placeholder="Ejemplo: Instituto Tecnologico Superior de Xalapa">
                    </div>

                    <!-- Área de adscripción -->
                    <div>
                        <label for="area" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-network-wired text-[#7A1737] mr-2"></i>Área de Adscripción
                        </label>
                        <input type="text" id="area" name="area" required 
                               class="floating-input" placeholder="Ejemplo: Ingenieria en Sistemas Computacionales">
                    </div>

                    <!-- Municipio -->
                    <div>
                        <label for="municipio" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-city text-[#7A1737] mr-2"></i>Municipio
                        </label>
                        <select id="municipio" name="municipio" required class="floating-input">
                            <option value="">Seleccione un municipio</option>
                            <% 
                                List<String> municipios = obtenerMunicipios();
                                for (String municipio : municipios) {
                            %>
                                <option value="<%= municipio %>"><%= municipio %></option>
                            <% } %>
                        </select>
                    </div>

                    <!-- Responsables -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-4 flex items-center">
                            <i class="fas fa-users-cog text-[#7A1737] mr-2"></i>Responsable de la Propuesta
                        </label>
                        <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr class="bg-gray-100">
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                                            <i class="fas fa-user-tie mr-1"></i>Tipo
                                        </th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                                            <i class="fas fa-signature mr-1"></i>Nombre
                                        </th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                                            <i class="fas fa-envelope mr-1"></i>Correo
                                        </th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                                            <i class="fas fa-phone mr-1"></i>Teléfono
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <tr>
                                        <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                                            <i class="fas fa-user-tie text-gray-600 mr-2"></i>Representante Legal
                                        </td>
                                        <td class="px-4 py-3"><input type="text" name="nombreLegal" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="email" name="correoLegal" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="tel" name="telefonoLegal" class="table-input" required></td>
                                    </tr>
                                    <tr>
                                        <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                                            <i class="fas fa-user-cog text-gray-600 mr-2"></i>Representante Técnico
                                        </td>
                                        <td class="px-4 py-3"><input type="text" name="nombreTecnico" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="email" name="correoTecnico" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="tel" name="telefonoTecnico" class="table-input" required></td>
                                    </tr>
                                    <tr>
                                        <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                                            <i class="fas fa-user-shield text-gray-600 mr-2"></i>Representante Administrativo
                                        </td>
                                        <td class="px-4 py-3"><input type="text" name="nombreAdministrativo" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="email" name="correoAdministrativo" class="table-input" required></td>
                                        <td class="px-4 py-3"><input type="tel" name="telefonoAdministrativo" class="table-input" required></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Convocatoria -->
                    <div>
                        <label for="convocatoria" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-bullhorn text-[#7A1737] mr-2"></i>Convocatoria
                        </label>
                        <select id="convocatoria" name="convocatoria" required class="floating-input">
                            <option value="">Seleccione una opción</option>
                            <option value="pvd2025">Atención a temas prioritarios del PVD 2025</option>
                            <option value="programasEstrategicos">Programas estratégicos nacionales 2025</option>
                        </select>
                    </div>

                    <!-- Área de conocimiento -->
                    <div>
                        <label for="areaConocimiento" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-book-open text-[#7A1737] mr-2"></i>Área de Conocimiento
                        </label>
                        <select id="areaConocimiento" name="areaConocimiento" required class="floating-input">
                            <option value="">Seleccione una opción</option>
                            <option value="fisicoMatematicas">I - Físico-Matemáticas y Ciencias de la Tierra</option>
                            <option value="biologiaQuimica">II - Biología y Química</option>
                            <option value="medicinaCienciasSalud">III - Medicina y Ciencias de la Salud</option>
                            <option value="cienciasConductaEducacion">IV - Ciencias de la Conducta y la Educación</option>
                            <option value="humanidades">V - Humanidades</option>
                            <option value="cienciasSociales">VI - Ciencias Sociales</option>
                            <option value="cienciasAgricultura">VII - Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas</option>
                            <option value="ingenieriasDesarrollo">VIII - Ingenierías y Desarrollo Tecnológico</option>
                            <option value="interdisciplinaria">IX - Interdisciplinaria</option>
                        </select>
                    </div>

                    <!-- Sector de desarrollo -->
                    <div>
                        <label for="sectorDesarrollo" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-industry text-[#7A1737] mr-2"></i>Sector al que impacta el proyecto
                        </label>
                        <input type="text" id="sectorDesarrollo" name="sectorDesarrollo" required 
                               class="floating-input" placeholder="Ejemplo: Agrícola, Tecnología, Salud, etc.">
                    </div>

                    <!--<div>
                        <label for="sectorDesarrollo" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-industry text-[#7A1737] mr-2"></i>Sector al que impacta el proyecto
                        </label>
                        <select id="sectorDesarrollo" name="sectorDesarrollo" required class="floating-input">
                            <option value="">Seleccione una opción</option>
                            <option value="acuicultura">Acuicultura</option>
                            <option value="agricola">Agrícola – agroindustrial</option>
                            <option value="alimentos">Alimentos</option>
                            <option value="ambiente">Ambiente</option>
                            <option value="educacion">Educación</option>
                            <option value="electronica">Electrónica</option>
                            <option value="energia">Energía</option>
                            <option value="ingenieria">Ingeniería</option>
                            <option value="medicina">Medicina y farmacéutica</option>
                            <option value="quimica">Química</option>
                        </select>
                    </div>-->

                    <!-- Nivel de Maduración -->
                    <div class="mt-6">
                        <label class="block text-sm font-medium text-gray-700 mb-4">Nivel de Maduración (tecnológico y/o social)</label>
                        <p class="text-sm text-gray-600 mb-4">Marque el nivel de maduración tecnológico y social en el que se encuentra su proyecto.</p>
                        
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <!-- TRL - Niveles de Maduración Tecnológica -->
                            <div class="bg-blue-50 p-6 rounded-lg border border-blue-100">
                                <h4 class="text-lg font-semibold text-blue-800 mb-4">Niveles de Maduración Tecnológica</h4>
                                <div class="space-y-3">
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl1" name="nivelMaduracion" value="TRL1" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl1" class="text-sm">
                                            <span class="font-semibold">TRL 1:</span> Principios básicos observados y reportados. Investigación básica.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl2" name="nivelMaduracion" value="TRL2" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl2" class="text-sm">
                                            <span class="font-semibold">TRL 2:</span> Concepto y aplicación formulada.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl3" name="nivelMaduracion" value="TRL3" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl3" class="text-sm">
                                            <span class="font-semibold">TRL 3:</span> Prueba de concepto.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl4" name="nivelMaduracion" value="TRL4" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl4" class="text-sm">
                                            <span class="font-semibold">TRL 4:</span> Validación de componentes a nivel laboratorio/campo.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl5" name="nivelMaduracion" value="TRL5" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl5" class="text-sm">
                                            <span class="font-semibold">TRL 5:</span> Validación de componentes en un entorno relevante.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl6" name="nivelMaduracion" value="TRL6" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl6" class="text-sm">
                                            <span class="font-semibold">TRL 6:</span> Demostración tecnológica en un ambiente relevante.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl7" name="nivelMaduracion" value="TRL7" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl7" class="text-sm">
                                            <span class="font-semibold">TRL 7:</span> Demostración de prototipo a nivel sistema en un ambiente operativo real.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl8" name="nivelMaduracion" value="TRL8" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl8" class="text-sm">
                                            <span class="font-semibold">TRL 8:</span> Desarrollo de producto completo y evaluado.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="trl9" name="nivelMaduracion" value="TRL9" class="mt-1 text-blue-600 focus:ring-blue-500">
                                        <label for="trl9" class="text-sm">
                                            <span class="font-semibold">TRL 9:</span> Producto terminado con éxito en el entorno real.
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- SRL - Niveles de Maduración Social -->
                            <div class="bg-green-50 p-6 rounded-lg border border-green-100">
                                <h4 class="text-lg font-semibold text-green-800 mb-4">SRL: Niveles de Maduración Social</h4>
                                <div class="space-y-3">
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl1" name="nivelMaduracion" value="SRL1" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl1" class="text-sm">
                                            <span class="font-semibold">SRL 1:</span> Identificación del problema y su impacto social.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl2" name="nivelMaduracion" value="SRL2" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl2" class="text-sm">
                                            <span class="font-semibold">SRL 2:</span> Formulación del problema, propuesta de soluciones e impacto potencial.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl3" name="nivelMaduracion" value="SRL3" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl3" class="text-sm">
                                            <span class="font-semibold">SRL 3:</span> Inicio de pruebas en campo con el grupo de interés.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl4" name="nivelMaduracion" value="SRL4" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl4" class="text-sm">
                                            <span class="font-semibold">SRL 4:</span> Problema validado mediante prueba piloto en entorno relevante.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl5" name="nivelMaduracion" value="SRL5" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl5" class="text-sm">
                                            <span class="font-semibold">SRL 5:</span> Solución validada por el grupo de interés relevante en el área.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl6" name="nivelMaduracion" value="SRL6" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl6" class="text-sm">
                                            <span class="font-semibold">SRL 6:</span> Adopción de la solución.
                                        </label>
                                    </div>
                                    <div class="flex items-start space-x-3">
                                        <input type="radio" id="srl7" name="nivelMaduracion" value="SRL7" class="mt-1 text-green-600 focus:ring-green-500">
                                        <label for="srl7" class="text-sm">
                                            <span class="font-semibold">SRL 7:</span> Impacto social.
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Documento probatorio -->
                        <div class="mt-6">
                            <label for="documentoProbatorio" class="block text-sm font-medium text-gray-700 mb-2">Documento probatorio (PDF)</label>
                            <input type="file" id="documentoProbatorio" name="documentoProbatorio" accept=".pdf" 
                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                            <p class="text-xs text-gray-500 mt-1">Adjunte documento que acredite el nivel de maduración seleccionado</p>
                        </div>
                    </div>

                    <!-- Botones de acción -->
                    <div class="flex justify-end mt-8 pt-6 border-t border-gray-200">
                        <div class="flex space-x-4">
                            <button type="button" onclick="guardarBorrador('formPagina1', 'pagina1', this)" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg">
                                Guardar Borrador
                            </button>
                            <button type="button" id="btnSiguiente" class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg">
                                Siguiente
                            </button>
                        </div>
                    </div>

                    
                </form>
            </div>
        </div>
    </main>

    <%@ include file="/footer.jsp" %>
    <script>
        // Función para guardar datos del formulario en localStorage
        // ahora acepta un tercer parámetro `targetBtn` (el botón que activó el guardado)
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(input.value);
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = input.value;
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            // mostrar el mensaje encima del botón que disparó el guardado
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const elements = form.querySelectorAll('[name="' + key + '"]');
                    
                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                        } else if (element.type === 'radio') {
                            element.checked = element.value === data[key];
                        } else if (element.type !== 'file') {
                            element.value = data[key] || '';
                        }
                    });
                });
            }
        }

        // Muestra un mensaje; si se proporciona `targetEl` posiciona el mensaje encima de ese elemento,
        // en caso contrario usa la esquina superior derecha.
        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                // posicion absoluta sobre el elemento objetivo
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                // calcular posición después de render para conocer dimensiones
                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8; // 8px de separación

                // si no cabe encima, poner debajo del botón
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                // asegurar que no salga por la izquierda/derecha
                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                // fallback: esquina superior derecha (fixed)
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Versión avanzada: bloquear "Siguiente" hasta que se pulse "Guardar Borrador".
        window.addEventListener('load', function() {
            // Cargar datos guardados (si existen)
            cargarBorrador('formPagina1', 'pagina1');

            const KEY = 'proyecto_borrador_pagina1_saved';
            const form = document.getElementById('formPagina1');

            // Buscar botones por atributos/texto (resiliente cuando no hay id)
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const siguienteBtn = document.getElementById('btnSiguiente') || buttons.find(b => /siguiente/i.test(b.textContent));

            function setDisabled(btn, disabled){
                if(!btn) return;
                // No usar disabled real para que los eventos sigan funcionando
                btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
                btn.setAttribute('data-disabled', disabled ? 'true' : 'false');
                if(disabled) {
                    btn.classList.add('opacity-60', 'cursor-not-allowed');
                    btn.classList.remove('hover:bg-[#5c0f2a]');
                } else {
                    btn.classList.remove('opacity-60', 'cursor-not-allowed');
                    btn.classList.add('hover:bg-[#5c0f2a]');
                }
            }

            if(!guardarBtn || !siguienteBtn){
                console.warn('No se encontraron los botones "Guardar Borrador" o "Siguiente". Control de bloqueo no inicializado.');
                return;
            }

            // Estado inicial desde localStorage
            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(siguienteBtn, !saved);

            // Cuando se pulsa guardar, marcar y habilitar siguiente
            guardarBtn.addEventListener('click', function(){
                // Marcar borrador como guardado
                localStorage.setItem(KEY, '1');
                saved = true;
                setDisabled(siguienteBtn, false);
                console.log('Borrador marcado como guardado -> Siguiente habilitado');
            });

            // Agregar evento al botón siguiente para manejar navegación y advertencias
            siguienteBtn.addEventListener('click', function(e){
                e.preventDefault();
                e.stopPropagation();
                
                // Verificar si está "deshabilitado" (visualmente)
                if(siguienteBtn.getAttribute('data-disabled') === 'true'){
                    mostrarMensaje('Debe guardar el borrador antes de continuar', 'error', siguienteBtn);
                    return false;
                }
                
                // Si está habilitado, navegar a la siguiente página
                window.location.href = '/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto2.jsp';
            });

            // Si el formulario cambia después de guardar, volver a marcar como no guardado y bloquear
            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){
                    if(saved){
                        saved = false;
                        localStorage.setItem(KEY, '0');
                        setDisabled(siguienteBtn, true);
                        console.log('Formulario modificado después de guardar: Siguiente bloqueado.');
                    }
                };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));
                // Advertir al usuario si intenta abandonar la página con cambios no guardados
                window.addEventListener('beforeunload', function(e) {
                    try {
                        if (!saved) {
                            // Mensaje personalizado no siempre se muestra por motivos de seguridad en navegadores modernos,
                            // pero setting returnValue provoca el diálogo de confirmación.
                            var confirmationMessage = 'Tiene cambios sin guardar. ¿Desea salir sin guardar?';
                            e.preventDefault();
                            e.returnValue = confirmationMessage;
                            return confirmationMessage;
                        }
                    } catch (err) {
                        // en caso de cualquier error, no bloquear la navegación
                        return undefined;
                    }
                });
            }
        });
    </script>
</body>
</html>
