<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Planeación y evaluación - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .semestre-section {
            transition: all 0.2s ease;
            border-radius: 0.5rem;
            overflow: visible;
        }
        
        .semestre-section:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        
        .input-focus:focus {
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.1);
        }
        
        .semestre-header {
            background: linear-gradient(135deg, #7A1737, #9D5B64);
            color: white;
            border-radius: 0.5rem 0.5rem 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
        }
        
        .badge-semestre {
            background-color: #B28854;
            color: white;
            border-radius: 1rem;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
            min-width: 84px;
            text-align: center;
        }
        
        .table-actividades {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table-actividades th {
            background-color: #7A1737;
            color: white;
            padding: 0.75rem;
            text-align: left;
            font-weight: 600;
        }
        
        .table-actividades td {
            padding: 0.75rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-actividades tr:hover {
            background-color: #f9fafb;
        }
        
        .btn-remove {
            background-color: #dc2626;
            color: white;
            border: none;
            border-radius: 0.375rem;
            padding: 0.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-remove:hover {
            background-color: #b91c1c;
        }
        
        /* ESTILOS PARA ENTREGABLES */
        .entregables-container {
            position: relative;
            width: 100%;
        }
        
        .entregables-trigger {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            background-color: white;
            cursor: pointer;
            font-size: 0.875rem;
            color: #6b7280;
            text-align: left;
            margin-bottom: 0.5rem;
        }
        
        .entregables-trigger.has-selection {
            color: #374151;
            font-weight: 500;
            border-color: #7A1737;
            background-color: #fef2f2;
        }
        
        .entregables-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 50;
            max-height: 300px;
            overflow-y: auto;
            padding: 1rem;
        }
        
        .entregables-dropdown.show {
            display: block;
        }
        
        .entregable-group {
            margin-bottom: 1rem;
        }
        
        .entregable-group-title {
            font-weight: 600;
            color: #7A1737;
            font-size: 0.875rem;
            padding: 0.5rem 0.25rem;
            margin-bottom: 0.5rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .entregable-item {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 0.25rem;
            transition: background-color 0.2s;
        }
        
        .entregable-item:hover {
            background-color: #f3f4f6;
        }
        
        .entregable-checkbox {
            margin-right: 0.75rem;
            width: 16px;
            height: 16px;
        }
        
        .entregable-label {
            font-size: 0.875rem;
            color: #374151;
            cursor: pointer;
            flex: 1;
        }
        
        /* CONTENEDOR PARA ETIQUETAS VISIBLES */
        .selected-tags-container {
            min-height: 60px;
            padding: 0.75rem;
            background-color: #f8fafc;
            border-radius: 0.375rem;
            border: 1px solid #e5e7eb;
        }
        
        .selected-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .selected-tag {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #7A1737, #9D5B64);
            color: white;
            padding: 0.5rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.8rem;
            font-weight: 500;
            gap: 0.5rem;
        }
        
        .remove-tag {
            margin-left: 0.5rem;
            cursor: pointer;
            width: 16px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.3);
            transition: background-color 0.2s;
            font-size: 0.7rem;
        }
        
        .remove-tag:hover {
            background-color: rgba(255, 255, 255, 0.5);
        }
        
        .entregables-counter {
            font-size: 0.75rem;
            color: #6b7280;
            margin-top: 0.5rem;
            text-align: center;
        }
        
        .entregables-counter.has-selection {
            color: #7A1737;
            font-weight: 500;
        }
        
        .empty-selection {
            color: #9ca3af;
            font-style: italic;
            text-align: center;
            padding: 0.5rem;
        }
        
        /* Estilos para el selector de semestres */
        .selector-semestres {
            background-color: #f8fafc;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #e2e8f0;
        }
        
        .selector-semestres label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 0.75rem;
            font-size: 1.1rem;
        }
        
        .selector-semestres select {
            width: 100%;
            max-width: 300px;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            background-color: white;
            font-size: 1rem;
            color: #374151;
            cursor: pointer;
        }
        
        .btn-generar {
            background-color: #7A1737;
            color: white;
            border: none;
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 1rem;
        }
        
        .btn-generar:hover {
            background-color: #5c0f2a;
        }
        
        /* CORRECCIÓN: Estilos mejorados para el selector de semestre en actividades */
        .semestre-selector {
            width: 150px !important;
            min-width: 150px !important;
            padding: 0.5rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            background-color: white;
            font-size: 0.875rem;
            color: #374151;
            cursor: pointer;
            white-space: nowrap;
            overflow: visible;
        }
        
        .semestre-selector option {
            padding: 0.5rem;
            white-space: nowrap;
            overflow: visible;
            width: 100%;
        }

        /* CORRECCIÓN: Ancho de columnas de la tabla ajustado */
        .table-actividades th:nth-child(1) { width: 40%; } /* Actividad */
        .table-actividades th:nth-child(2) { width: 20%; } /* Semestre - Aumentado */
        .table-actividades th:nth-child(3) { width: 35%; } /* Entregables */
        .table-actividades th:nth-child(4) { width: 5%; }  /* Acciones */
        
        .table-actividades td:nth-child(2) {
            min-width: 150px;
            width: 20%;
        }
        
        /* Estilos para el botón de eliminar semestre */
        .btn-eliminar-semestre {
            background-color: #dc2626;
            color: white;
            border: none;
            border-radius: 0.5rem;
            padding: 0.5rem 1rem;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }
        
        .btn-eliminar-semestre:hover {
            background-color: #b91c1c;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
        <%@ include file="../header.jsp" %>
    </header>
    
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-calendar-alt mr-3"></i>Cronograma de Actividades 4/5
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Complete cada sección (todos los campos son necesarios)
                    </p>
                </div>

                <form class="p-8 space-y-8" action="#" method="post">
                    <!-- Selector oculto pero funcional para uso futuro -->
                    <div class="selector-semestres" style="display:none;">
                        <label for="numeroSemestres">Número de Semestres (1-4):</label>
                        <select id="numeroSemestres" name="numeroSemestres">
                            <option value="1">1 Semestre</option>
                            <option value="2" selected>2 Semestres</option>
                            <option value="3">3 Semestres</option>
                            <option value="4">4 Semestres</option>
                        </select>
                        <button type="button" id="btnGenerarSemestres" class="btn-generar flex items-center">
                            <i class="fas fa-sync-alt mr-2"></i>Generar Semestres
                        </button>
                    </div>

                    <div id="semestresContainer" class="space-y-6">
                        <!-- Los semestres se generarán automáticamente al cargar la página -->
                    </div>

                <!-- Botones de acción -->
                    <div class="flex flex-col gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-between">
                        <button type="button"
                                class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto3.jsp'">
                            <i class="fas fa-arrow-left mr-2"></i>Anterior
                        </button>
                        
                        <div class="flex flex-col-reverse gap-4 sm:flex-row">
                            <button type="button" onclick="guardarBorrador('formPagina3', 'pagina3', this)"
                                    class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                                <i class="fas fa-save mr-2"></i>Guardar Borrador
                            </button>
                            <button type="button"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto5.jsp'">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
<%@ include file="/footer.jsp" %>

    <script>
        const entregables = [
            { value: 'libros-derivados', text: 'Libros derivados de la propuesta', category: 'academicos' },
            { value: 'propiedad-intelectual', text: 'Propiedad intelectual e industrial', category: 'academicos' },
            { value: 'informes-tecnicos', text: 'Informes técnicos especializados', category: 'academicos' },
            { value: 'desarrollo-tecnologico', text: 'Desarrollo tecnológico e innovación', category: 'academicos' },
            { value: 'difusion-divulgacion', text: 'Actividades de difusión y divulgación', category: 'acceso-universal' },
            { value: 'infografias', text: 'Infografías explicativas', category: 'acceso-universal' },
            { value: 'folletos', text: 'Folletos informativos', category: 'acceso-universal' },
            { value: 'libros-divulgacion', text: 'Libros de divulgación científica', category: 'acceso-universal' },
            { value: 'material-audiovisual', text: 'Material audiovisual educativo', category: 'acceso-universal' },
            { value: 'podcast', text: 'Podcast y programas de audio', category: 'acceso-universal' },
            { value: 'otros-divulgacion', text: 'Otros productos de divulgación', category: 'acceso-universal' },
            { value: 'tesis-grado', text: 'Tesis de grado o posgrado', category: 'formacion' },
            { value: 'tesina', text: 'Tesinas de investigación', category: 'formacion' },
            { value: 'memoria-residencias', text: 'Memorias de residencias profesionales', category: 'formacion' },
            { value: 'equipamiento-maquinaria', text: 'Equipamiento de maquinaria', category: 'infraestructura' },
            { value: 'equipo-laboratorio', text: 'Equipo de laboratorio', category: 'infraestructura' },
            { value: 'software-especializado', text: 'Software especializado', category: 'infraestructura' },
            { value: 'infraestructura-redes', text: 'Infraestructura de redes', category: 'infraestructura' },
            { value: 'articulo-cientifico', text: 'Artículo científico', category: 'otros' },
            { value: 'ponencia-congreso', text: 'Ponencia en congreso', category: 'otros' },
            { value: 'poster-cientifico', text: 'Póster científico', category: 'otros' },
            { value: 'manual-tecnico', text: 'Manual técnico', category: 'otros' },
            { value: 'prototipo', text: 'Prototipo funcional', category: 'otros' },
            { value: 'base-datos', text: 'Base de datos especializada', category: 'otros' },
            { value: 'informe-final', text: 'Informe final de investigación', category: 'otros' }
        ];

        let dropdownAbierto = null;

        function generarSemestres() {
            const container = document.getElementById('semestresContainer');
            const numSemestres = parseInt(document.getElementById('numeroSemestres').value);
            
            container.innerHTML = '';
            
            for (let i = 1; i <= numSemestres; i++) {
                const semestreSection = document.createElement('div');
                semestreSection.className = 'semestre-section bg-white border border-gray-200 rounded-lg';
                semestreSection.id = `semestre-${i}`;
                semestreSection.innerHTML = `
                    <div class="semestre-header">
                        <!-- Botón de eliminar oculto - se puede habilitar en el futuro si se permiten más de 2 semestres -->
                        <button type="button" class="btn-eliminar-semestre" data-semestre="${i}" style="display:none;">
                            <i class="fas fa-trash mr-1"></i> Eliminar Semestre
                        </button>
                        <span class="badge-semestre">Semestre ${i}</span>
                    </div>
                    
                    <div class="p-6 space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="descripcionSemestre${i}" class="block text-sm font-medium text-gray-700 mb-1">Descripción del Semestre ${i}:</label>
                                <textarea id="descripcionSemestre${i}" name="descripcionSemestre${i}" rows="2" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus"
                                          placeholder="Descripción general del semestre..."></textarea>
                            </div>
                            
                            <div>
                                <label for="metaSemestre${i}" class="block text-sm font-medium text-gray-700 mb-1">Meta del Semestre ${i}:</label>
                                <textarea id="metaSemestre${i}" name="metaSemestre${i}" rows="2" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus"
                                          placeholder="Describa las metas específicas a alcanzar..."></textarea>
                            </div>
                        </div>

                        <div class="border-t border-gray-200 pt-4">
                            <div class="flex justify-between items-center mb-4">
                                <h4 class="text-lg font-semibold text-gray-800">Actividades del Semestre ${i}</h4>
                                <button type="button" class="agregar-actividad bg-[#7A1737] hover:bg-[#5A2329] text-white font-medium py-2 px-4 rounded-md transition duration-200 flex items-center" data-semestre="${i}">
                                    <i class="fas fa-plus mr-2"></i>Agregar Actividad
                                </button>
                            </div>
                            
                            <div class="overflow-x-auto">
                                <table class="table-actividades">
                                    <thead>
                                        <tr>
                                            <th>Actividad</th>
                                            <th>Semestre</th>
                                            <th>Entregables</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="actividadesTable${i}">
                                        <tr id="emptyRow${i}">
                                            <td colspan="4" class="text-center text-gray-500 py-4">
                                                No hay actividades agregadas en Semestre ${i}. Haga clic en "Agregar Actividad" para comenzar.
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                `;
                
                container.appendChild(semestreSection);
            }
        }

        function crearSemestreSelector(semestreNum, actividadId) {
            const numSemestres = parseInt(document.getElementById('numeroSemestres').value);
            
            const select = document.createElement('select');
            select.className = 'semestre-selector';
            select.name = `actividadSemestre${semestreNum}_${actividadId}`;
            
            for (let i = 1; i <= numSemestres; i++) {
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Semestre ${i}`;
                if (i == semestreNum) {
                    option.selected = true;
                }
                select.appendChild(option);
            }
            
            return select;
        }

        function crearEntregablesSelector(semestreNum, actividadId) {
            const container = document.createElement('div');
            container.className = 'entregables-container';
            
            const trigger = document.createElement('button');
            trigger.type = 'button';
            trigger.className = 'entregables-trigger';
            trigger.innerHTML = '<i class="fas fa-plus-circle mr-2"></i>Haz clic para seleccionar entregables';
            
            const counter = document.createElement('div');
            counter.className = 'entregables-counter';
            counter.textContent = 'No hay entregables seleccionados';
            
            const tagsContainer = document.createElement('div');
            tagsContainer.className = 'selected-tags-container';
            
            const dropdown = document.createElement('div');
            dropdown.className = 'entregables-dropdown';
            
            const categorias = {
                'academicos': '📚 Productos Académicos',
                'acceso-universal': '🌐 Acceso Universal del Conocimiento',
                'formacion': '🎓 Formación de Capacidades',
                'infraestructura': '🏗️ Fortalecimiento de Infraestructura',
                'otros': '📦 Otros Entregables'
            };
            
            Object.keys(categorias).forEach(categoria => {
                const group = document.createElement('div');
                group.className = 'entregable-group';
                
                const groupTitle = document.createElement('div');
                groupTitle.className = 'entregable-group-title';
                groupTitle.textContent = categorias[categoria];
                group.appendChild(groupTitle);
                
                entregables
                    .filter(entregable => entregable.category === categoria)
                    .forEach(entregable => {
                        const item = document.createElement('div');
                        item.className = 'entregable-item';
                        
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.className = 'entregable-checkbox';
                        checkbox.name = `actividadEntregable${semestreNum}_${actividadId}[]`;
                        checkbox.value = entregable.value;
                        checkbox.id = `entregable_${semestreNum}_${actividadId}_${entregable.value}`;
                        
                        const label = document.createElement('label');
                        label.className = 'entregable-label';
                        label.htmlFor = checkbox.id;
                        label.textContent = entregable.text;
                        
                        checkbox.addEventListener('change', function() {
                            updateSelectionState();
                        });
                        
                        item.appendChild(checkbox);
                        item.appendChild(label);
                        group.appendChild(item);
                    });
                
                dropdown.appendChild(group);
            });
            
            function updateSelectionState() {
                const checkboxes = dropdown.querySelectorAll('input[type="checkbox"]');
                const selected = Array.from(checkboxes).filter(cb => cb.checked);
                
                if (selected.length > 0) {
                    counter.textContent = `${selected.length} entregable(s) seleccionado(s)`;
                    counter.classList.add('has-selection');
                    trigger.classList.add('has-selection');
                    trigger.innerHTML = `<i class="fas fa-check-circle mr-2"></i>${selected.length} entregable(s) seleccionado(s) - Haz clic para modificar`;
                } else {
                    counter.textContent = 'No hay entregables seleccionados';
                    counter.classList.remove('has-selection');
                    trigger.classList.remove('has-selection');
                    trigger.innerHTML = '<i class="fas fa-plus-circle mr-2"></i>Haz clic para seleccionar entregables';
                }
                
                updateTags(selected);
            }
            
            function updateTags(selectedCheckboxes) {
                tagsContainer.innerHTML = '';
                const tagsDiv = document.createElement('div');
                tagsDiv.className = 'selected-tags';
                
                if (selectedCheckboxes.length === 0) {
                    const emptyMsg = document.createElement('div');
                    emptyMsg.className = 'empty-selection';
                    emptyMsg.textContent = 'No hay entregables seleccionados';
                    tagsContainer.appendChild(emptyMsg);
                } else {
                    selectedCheckboxes.forEach(checkbox => {
                        const entregableValue = checkbox.value;
                        const entregable = entregables.find(e => e.value === entregableValue);
                        
                        if (entregable) {
                            const tag = document.createElement('div');
                            tag.className = 'selected-tag';

                            const textSpan = document.createElement('span');
                            textSpan.textContent = entregable.text;

                            const removeBtn = document.createElement('span');
                            removeBtn.className = 'remove-tag';
                            removeBtn.setAttribute('data-value', entregableValue);
                            removeBtn.innerHTML = '<i class="fas fa-times"></i>';
                            removeBtn.addEventListener('click', function(e) {
                                e.stopPropagation();
                                const value = this.getAttribute('data-value');
                                const checkboxToUncheck = dropdown.querySelector(`input[value="${value}"]`);
                                if (checkboxToUncheck) {
                                    checkboxToUncheck.checked = false;
                                    checkboxToUncheck.dispatchEvent(new Event('change'));
                                }
                            });

                            tag.appendChild(textSpan);
                            tag.appendChild(removeBtn);
                            tagsDiv.appendChild(tag);
                        }
                    });
                    tagsContainer.appendChild(tagsDiv);
                }
            }
            
            trigger.addEventListener('click', function(e) {
                e.stopPropagation();
                
                if (dropdownAbierto && dropdownAbierto !== dropdown) {
                    dropdownAbierto.classList.remove('show');
                }
                
                dropdown.classList.toggle('show');
                dropdownAbierto = dropdown.classList.contains('show') ? dropdown : null;
            });
            
            dropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
            
            container.appendChild(trigger);
            container.appendChild(counter);
            container.appendChild(tagsContainer);
            container.appendChild(dropdown);
            
            updateTags([]);
            
            return container;
        }

        function agregarActividadTabla(semestreSource) {
            let semestreNum;
            let container;

            if (typeof semestreSource === 'string' || typeof semestreSource === 'number') {
                semestreNum = semestreSource;
                container = document.getElementById(`actividadesTable${semestreNum}`);
            } else if (semestreSource instanceof Element) {
                const boton = semestreSource;
                const semestreSection = boton.closest('.semestre-section');
                if (semestreSection) {
                    const badge = semestreSection.querySelector('.badge-semestre');
                    if (badge) {
                        const match = badge.textContent.match(/\d+/);
                        semestreNum = match ? match[0] : boton.dataset.semestre;
                    } else {
                        semestreNum = boton.dataset.semestre;
                    }
                    container = semestreSection.querySelector(`#actividadesTable${semestreNum}`);
                } else {
                    semestreNum = boton.dataset.semestre;
                    container = document.getElementById(`actividadesTable${semestreNum}`);
                }
            }

            const emptyRow = document.getElementById(`emptyRow${semestreNum}`);
            if (emptyRow) {
                emptyRow.style.display = 'none';
            }
            
            const actividadId = Date.now();
            
            const actividadRow = document.createElement('tr');
            actividadRow.id = `actividad-${actividadId}`;
            actividadRow.innerHTML = `
                <td>
                    <input type="text" 
                           name="actividadNombre${semestreNum}[]" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md input-focus text-sm"
                           placeholder="Nombre de la actividad"
                           required>
                </td>
                <td>
                    <!-- Selector de semestre se agregará aquí -->
                </td>
                <td>
                    <!-- Selector de entregables se agregará aquí -->
                </td>
                <td>
                    <button type="button" 
                            class="eliminar-actividad btn-remove"
                            data-actividad="${actividadId}"
                            data-semestre="${semestreNum}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            
            const tdSemestre = actividadRow.querySelector('td:nth-child(2)');
            const semestreSelector = crearSemestreSelector(semestreNum, actividadId);
            tdSemestre.appendChild(semestreSelector);
            
            const tdEntregable = actividadRow.querySelector('td:nth-child(3)');
            const entregablesSelector = crearEntregablesSelector(semestreNum, actividadId);
            tdEntregable.appendChild(entregablesSelector);
            
            if (container) {
                container.appendChild(actividadRow);
            }
        }

        function eliminarActividad(actividadId, semestreNum) {
            const actividadRow = document.getElementById(`actividad-${actividadId}`);
            if (actividadRow) {
                actividadRow.remove();

                const container = document.getElementById(`actividadesTable${semestreNum}`);
                const actividades = container.querySelectorAll('tr[id^="actividad-"]');
                if (actividades.length === 0) {
                    const emptyRow = document.getElementById(`emptyRow${semestreNum}`);
                    if (emptyRow) {
                        emptyRow.style.display = '';
                    }
                }
            }
        }

        function eliminarSemestre(semestreNum) {
            if (confirm(`¿Está seguro de que desea eliminar el Semestre ${semestreNum}?`)) {
                const semestreSection = document.getElementById(`semestre-${semestreNum}`);
                if (semestreSection) {
                    semestreSection.remove();
                    
                    const selector = document.getElementById('numeroSemestres');
                    const numSemestresActuales = document.querySelectorAll('.semestre-section').length;
                    selector.value = numSemestresActuales;
                    
                    if (numSemestresActuales === 0) {
                        const container = document.getElementById('semestresContainer');
                        container.innerHTML = `
                            <div class="text-center py-12 text-gray-500">
                                <i class="fas fa-calendar-day text-4xl mb-3 opacity-50"></i>
                                <p>No hay semestres configurados</p>
                            </div>
                        `;
                    }
                }
            }
        }

        document.addEventListener('click', function(event) {
            if (dropdownAbierto && !dropdownAbierto.parentElement.contains(event.target)) {
                dropdownAbierto.classList.remove('show');
                dropdownAbierto = null;
            }

            const addBtn = event.target.closest('.agregar-actividad');
            if (addBtn) {
                agregarActividadTabla(addBtn);
            }

            const delBtn = event.target.closest('.eliminar-actividad');
            if (delBtn) {
                const actividadId = delBtn.dataset.actividad;
                const semestreNum = delBtn.dataset.semestre;
                eliminarActividad(actividadId, semestreNum);
            }

            const delSemestreBtn = event.target.closest('.btn-eliminar-semestre');
            if (delSemestreBtn) {
                const semestreNum = delSemestreBtn.dataset.semestre;
                eliminarSemestre(semestreNum);
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            // Fijar en 2 semestres y generar automáticamente
            document.getElementById('numeroSemestres').value = '2';
            generarSemestres();
            
            // Mantener el event listener por si se habilita en el futuro
            document.getElementById('btnGenerarSemestres').addEventListener('click', function() {
                generarSemestres();
            });
        });
    </script>
</body>
</html>