<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!-- se usa Tailwind CSS para el diseño y estilo de la interfaz -->
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <%@ include file="../header.jsp" %>
  <title>Entregables - COVEICYDET</title>
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }
  </style>
</head>
<body>
  <body class="bg-gray-50 min-h-screen antialiased">
    <div class="max-w-5xl mx-auto px-4 py-10">
        <!-- Encabezado con el estilo COVEICYDET -->
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-[#B28854] p-6">
                <h1 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-box-open mr-3"></i>Entregables 4/5
                </h1>
                <p class="text-white/90 mt-2">Seleccione los productos entregables comprometidos y defina el presupuesto de su proyecto</p>
            </div>
            
        <form id="formPagina4" class="p-8 space-y-8" action="#" method="post">

            <!-- productos entregables comprometidos -->
            <!-- productos academicos, checklist de libros derivados de la propuesta, propiedad intelectua e industrial, informes tecnicos, desarrollo tecnologico -->
            <div class="space-y-6">
                <div class="flex items-center mb-6">
                    <i class="fas fa-gift text-[#7A1737] text-xl mr-3"></i>
                    <h2 class="text-xl font-semibold text-gray-800">Productos Entregables Comprometidos</h2>
                </div>
                
                <!-- Productos Académicos -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-graduation-cap text-[#7A1737] mr-2"></i>
                        <h3 class="text-lg font-semibold text-gray-700">Productos Académicos</h3>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="libros" name="productos-entregables[]" value="libros" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Libros derivados</span> de la propuesta
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="propiedad-intelectual" name="productos-entregables[]" value="propiedad-intelectual" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Propiedad intelectual</span> e industrial
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="Folletos" name="productos-entregables[]" value="Folletos" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Informes técnicos</span> especializados
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="Libros-de-divulgacion" name="productos-entregables[]" value="Libros-de-divulgacion" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Desarrollo tecnológico</span> e innovación
                            </span>
                        </label>
                    </div>
                </div>

                <!-- Productos de acceso universal del conocimiento -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-globe text-[#7A1737] mr-2"></i>
                        <h3 class="text-lg font-semibold text-gray-700">Productos de acceso universal del conocimiento</h3>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="tesis" name="productos-entregables[]" value="tesis" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                Desarrollo de actividades de <span class="font-medium">difusión y divulgación</span> de los resultados
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="infografias" name="productos-entregables[]" value="infografias" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Infografías</span> explicativas
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="Folletos" name="productos-entregables[]" value="Folletos" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Folletos</span> informativos
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="Libros-de-divulgacion" name="productos-entregables[]" value="Libros-de-divulgacion" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Libros de divulgación</span> científica
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="material-audiovisual" name="productos-entregables[]" value="material-audiovisual" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Material audiovisual</span> educativo
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="podcast" name="productos-entregables[]" value="podcast" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Podcast</span> y programas de audio
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="entre-otros" name="productos-entregables[]" value="entre-otros"
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Otros productos</span> de divulgación
                            </span>
                        </label>
                    </div>
                </div>

                <!-- Formación de capacidades en HCTI y vocaciones científicas -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-user-graduate text-[#7A1737] mr-2"></i>
                        <h3 class="text-lg font-semibold text-gray-700">Formación de capacidades en HCTI y vocaciones científicas</h3>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="tesis" name="productos-entregables[]" value="tesis" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Tesis</span> de grado o posgrado
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="tesina" name="productos-entregables[]" value="tesina" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Tesinas</span> de investigación
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="memoria-residencias" name="productos-entregables[]" value="memoria-residencias" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Memorias</span> de residencias profesionales
                            </span>
                        </label>
                    </div>
                </div>

                <!-- Insumos para la implementación de políticas públicas -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-landmark text-[#7A1737] mr-2"></i>
                        <h3 class="text-lg font-semibold text-gray-700">Insumos para la implementación de políticas públicas</h3>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="estudios-politicas" name="productos-entregables[]" value="estudios-politicas" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Estudios</span> para políticas públicas
                            </span>
                        </label>
                    </div>
                </div>

                <!-- Fortalecimiento de infraestructura -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-tools text-[#7A1737] mr-2"></i>
                        <h3 class="text-lg font-semibold text-gray-700">Fortalecimiento de infraestructura</h3>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="Equipamiento-de-maquinaria" name="productos-entregables[]" value="Equipamiento-de-maquinaria" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Equipamiento</span> de maquinaria
                            </span>
                        </label>

                        <label class="flex items-start p-4 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors cursor-pointer">
                            <input type="checkbox" id="equipo-de-laboratorio" name="productos-entregables[]" value="equipo-de-laboratorio" 
                                   class="h-5 w-5 text-[#7A1737] border-gray-300 rounded focus:ring-[#7A1737] mt-0.5 flex-shrink-0">
                            <span class="ml-3 text-sm text-gray-700">
                                <span class="font-medium">Equipo</span> de laboratorio
                            </span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- presupuesto, primero solicita la cantidad y despues la justificacion del porque esa cantidad-->
            <div class="bg-gray-50 rounded-lg p-6">
                <div class="flex items-center mb-6">
                    <i class="fas fa-dollar-sign text-[#7A1737] text-xl mr-3"></i>
                    <h2 class="text-xl font-semibold text-gray-800">Presupuesto del Proyecto</h2>
                </div>
                
                <div class="space-y-6">
                    <div>
                        <label for="presupuesto" class="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-money-bill-wave text-[#7A1737] mr-2"></i>
                            Cantidad solicitada
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="text-gray-500 sm:text-sm">$</span>
                            </div>
                            <input type="number" id="presupuesto" name="presupuesto" placeholder="0.00" 
                                   class="pl-7 block w-full rounded-lg border-gray-300 shadow-sm focus:border-[#7A1737] focus:ring-[#7A1737] sm:text-sm">
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                <span class="text-gray-500 sm:text-sm">MXN</span>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label for="justificacion-presupuesto" class="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-file-alt text-[#7A1737] mr-2"></i>
                            Justificación del presupuesto
                        </label>
                        <textarea id="justificacion-presupuesto" name="justificacion-presupuesto" rows="4" 
                                  placeholder="Detalle la justificación del presupuesto solicitado, incluyendo los principales rubros de gasto y su importancia para el desarrollo del proyecto" 
                                  class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-[#7A1737] focus:ring-[#7A1737] sm:text-sm"></textarea>
                    </div>
                </div>
            </div>
            
            <!-- botones -->
            <div class="flex justify-between pt-6 border-t border-gray-200">
                <button type="button" class="flex items-center px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-lg transition-colors duration-200" onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto3.jsp'">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Anterior
                </button>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="guardarBorrador('formPagina4', 'pagina4', this)" class="flex items-center px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white font-medium rounded-lg transition-colors duration-200">
                        <i class="fas fa-save mr-2"></i>
                        Guardar borrador
                    </button>
                    <button type="button" onclick="enviarProyecto()" class="flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors duration-200">
                        <i class="fas fa-paper-plane mr-2"></i>
                        Enviar proyecto
                    </button>
                </div>
            </div>
        </form>
        </div>
    </div>
    
    <script>
        // Funciones para guardar y cargar borradores
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(input.value);
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = input.value;
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                const data = JSON.parse(savedData);
                const form = document.getElementById(formId);
                
                Object.keys(data).forEach(key => {
                    const elements = form.querySelectorAll('[name="' + key + '"]');
                    
                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            element.checked = Array.isArray(data[key]) && data[key].includes(element.value);
                        } else if (element.type === 'radio') {
                            element.checked = element.value === data[key];
                        } else if (element.type !== 'file') {
                            element.value = data[key] || '';
                        }
                    });
                });
            }
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir protección beforeunload
        window.addEventListener('load', function() {
            cargarBorrador('formPagina4', 'pagina4');

            const KEY = 'proyecto_borrador_pagina4_saved';
            const form = document.getElementById('formPagina4');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));

            let saved = localStorage.getItem(KEY) === '1';

            if(guardarBtn){
                guardarBtn.addEventListener('click', function(){
                    localStorage.setItem(KEY,'1'); saved = true; console.log('Borrador pagina4 guardado');
                });
            }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){ if(saved){ saved = false; localStorage.setItem(KEY,'0'); console.log('Formulario pagina4 modificado despues de guardar'); } };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                window.addEventListener('beforeunload', function(e){ try{ if(!saved){ var msg='Tiene cambios sin guardar. ¿Desea salir sin guardar?'; e.preventDefault(); e.returnValue = msg; return msg; } }catch(err){ return undefined; } });
            }
        });

        // Función para enviar el proyecto completo a la base de datos
        function enviarProyecto() {
            // Primero guardar la página actual
            guardarBorrador('formPagina4', 'pagina4');
            
            // Recopilar datos de todas las páginas
            const datosCompletos = {
                pagina1: JSON.parse(localStorage.getItem('proyecto_borrador_pagina1') || '{}'),
                pagina2: JSON.parse(localStorage.getItem('proyecto_borrador_pagina2') || '{}'),
                pagina3: JSON.parse(localStorage.getItem('proyecto_borrador_pagina3') || '{}'),
                pagina4: JSON.parse(localStorage.getItem('proyecto_borrador_pagina4') || '{}')
            };
            
            // Debug: Mostrar datos del cronograma antes del envío
            console.log('Datos completos antes del envío:', datosCompletos);
            console.log('Datos de página 3:', datosCompletos.pagina3);
            console.log('Cronograma específico:', datosCompletos.pagina3.cronograma);
            
            // Verificar si hay cronograma
            if (datosCompletos.pagina3.cronograma && Array.isArray(datosCompletos.pagina3.cronograma)) {
                console.log('Cronograma encontrado con ' + datosCompletos.pagina3.cronograma.length + ' actividades');
                datosCompletos.pagina3.cronograma.forEach((actividad, index) => {
                    console.log('Actividad ' + index + ':', actividad);
                });
            } else {
                console.log('No se encontró cronograma o no es un array');
            }

            // Validar que tenemos datos básicos
            if (!datosCompletos.pagina1.institucion || !datosCompletos.pagina2['resumen-ejecutivo']) {
                mostrarMensaje('Por favor complete al menos la información básica en las primeras páginas', 'error');
                return;
            }

            // Mostrar indicador de carga
            const enviarBtn = event.target;
            enviarBtn.disabled = true;
            enviarBtn.textContent = 'Enviando...';

            // Crear formulario para envío
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'procesar_proyecto.jsp';

            // Agregar datos como campos ocultos
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'datosProyecto';
            input.value = JSON.stringify(datosCompletos);
            form.appendChild(input);

            // Debug: Mostrar el JSON final que se envía
            console.log('JSON final enviado:', input.value);

            // Enviar
            document.body.appendChild(form);
            form.submit();
        }
    </script>
    
    <%@ include file="/footer.jsp" %>
  </body>