<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% if (!"responsable".equals(String.valueOf(session.getAttribute("rol")))) { String n=request.getRequestURI()+(request.getQueryString()!=null?("?"+request.getQueryString()):""); response.sendRedirect(request.getContextPath()+"/pages/login/login.jsp?next="+java.net.URLEncoder.encode(n,"UTF-8")); return; } %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Planeación y evaluación - COVEICYDET</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .form-container {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .floating-input {
            border: 1px solid #cbd5e0;
            border-radius: 0.5rem;
            padding: 0.75rem;
            width: 100%;
            transition: all 0.2s;
            resize: vertical;
        }
        
        .floating-input:focus {
            outline: none;
            border-color: #7A1737;
            box-shadow: 0 0 0 3px rgba(122, 23, 55, 0.2);
        }
        
        .modal {
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <%@ include file="../header.jsp" %>
    
    <!-- Contenido principal -->
    <main class="flex-grow py-8">
        <div class="container mx-auto px-4">
            <div class="form-container bg-white rounded-xl overflow-hidden border border-slate-200">
                <!-- Encabezado del formulario -->
                <div class="bg-[#B28854] p-6">
                    <h1 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-calendar-alt mr-3"></i>Planeación y evaluación 3/5
                    </h1>
                    <p class="text-white/90 mt-2 flex items-center">
                        <i class="fas fa-info-circle mr-2"></i>Complete cada sección (todos los campos son necesarios)
                    </p>
                </div>

                <!-- Formulario -->
                <form id="formPagina3" class="p-8 space-y-8" action="#" method="post">

                    <!-- Cronograma de actividades -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-project-diagram text-[#7A1737] mr-2"></i>Cronograma de Actividades
                        </label>
                        <div class="flex items-center space-x-4">
                            <button type="button" onclick="openCronogramaModal()" 
                                    class="inline-flex items-center px-4 py-2 bg-[#7A1737] hover:bg-[#5c0f2a] text-white text-sm font-medium rounded-md transition duration-200">
                                <i class="fas fa-plus-circle mr-2"></i>Realizar cronograma
                            </button>
                        </div>
                    </div>

                    <!-- Factores de riesgo y mitigación -->
                    <div>
                        <label for="factores-riesgo" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-exclamation-triangle text-[#7A1737] mr-2"></i>Factores de Riesgo y Mitigación
                        </label>
                        <textarea id="factores-riesgo" name="factores-riesgo" rows="4" required
                                placeholder="Describa los principales factores de riesgo y sus estrategias de mitigación."
                                class="floating-input"></textarea>
                    </div>

                    <!-- Referencias bibliográficas -->
                    <div>
                        <label for="referencias" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-book text-[#7A1737] mr-2"></i>Referencias Bibliográficas
                        </label>
                        <textarea id="referencias" name="referencias" rows="4" required
                                placeholder="Incluya las referencias bibliográficas utilizadas."
                                class="floating-input"></textarea>
                    </div>

                    <!-- Vinculación institucional -->
                    <div>
                        <label for="vinculacion-institucional" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-handshake text-[#7A1737] mr-2"></i>Vinculación Institucional
                        </label>
                        <textarea id="vinculacion-institucional" name="vinculacion-institucional" rows="4" required
                                placeholder="Describa la vinculación institucional del proyecto."
                                class="floating-input"></textarea>
                    </div>

                    <!-- Resultados esperados -->
                    <div>
                        <label for="resultados" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-chart-line text-[#7A1737] mr-2"></i>Resultados Esperados
                        </label>
                        <textarea id="resultados" name="resultados" rows="4" required
                                placeholder="Describa los resultados esperados del proyecto."
                                class="floating-input"></textarea>
                    </div>

                    <!-- Áreas de impacto -->
                    <div>
                        <label for="areas-impacto" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                            <i class="fas fa-bullseye text-[#7A1737] mr-2"></i>Áreas de Impacto
                        </label>
                        <textarea id="areas-impacto" name="areas-impacto" rows="4" required
                                placeholder="Describa las áreas de impacto del proyecto."
                                class="floating-input"></textarea>
                    </div>

                    <!-- Botones de acción -->
                    <div class="flex flex-col-reverse gap-4 pt-8 border-t border-gray-200 sm:flex-row sm:justify-end">
                        <button type="button" onclick="guardarBorrador('formPagina3', 'pagina3', this)"
                                class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center">
                            <i class="fas fa-save mr-2"></i>Guardar Borrador
                        </button>
                        <div class="flex gap-4">
                            <button type="button"
                                    class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto2.jsp'">
                                <i class="fas fa-arrow-left mr-2"></i>Anterior
                            </button>
                            <button type="button"
                                    class="bg-[#7A1737] hover:bg-[#5c0f2a] text-white font-medium py-2 px-6 rounded-lg transition duration-200 flex items-center justify-center"
                                    onclick="location.href='/proyectos/pages/responsableDeproyecto/registroProyecto/registroProyecto4.jsp'">
                                Siguiente <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- Modal para cronograma -->
    <div id="cronogramaModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <!-- Header del modal -->
            <div class="flex items-center justify-between p-6 border-b border-gray-200 bg-[#B28854] text-white rounded-t-xl">
                <h3 class="text-lg font-semibold flex items-center">
                    <i class="fas fa-calendar-plus mr-2"></i>Cronograma de Actividades
                </h3>
                <button type="button" onclick="closeCronogramaModal()" class="text-white hover:text-gray-200">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <!-- Contenido del modal -->
            <div class="p-6">
                <form id="cronogramaForm">
                    <!-- Tabla para crear cronograma -->
                    <div class="overflow-x-auto rounded-lg border border-gray-200">
                        <table class="min-w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Actividad</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Trimestre</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Meta</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Entregable</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Fecha Entrega</th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="cronogramaTableBody" class="bg-white divide-y divide-gray-200">
                                <tr>
                                    <td class="px-4 py-2 border border-gray-300">
                                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300">
                                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300">
                                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300">
                                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300">
                                        <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300 text-center">
                                        <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Botón para agregar fila -->
                    <div class="mt-4">
                        <button type="button" onclick="addRow()" 
                                class="inline-flex items-center px-4 py-2 bg-[#7A1737] hover:bg-[#5c0f2a] text-white text-sm font-medium rounded-md transition duration-200">
                            <i class="fas fa-plus-circle mr-2"></i>Agregar Actividad
                        </button>
                    </div>
                </form>
            </div>

            <!-- Footer del modal -->
            <div class="flex justify-end space-x-3 p-6 border-t border-gray-200">
                <button type="button" onclick="closeCronogramaModal()" 
                        class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 transition duration-200">
                    Cancelar
                </button>
                <button type="button" onclick="saveCronograma()" 
                        class="px-4 py-2 bg-[#7A1737] hover:bg-[#5c0f2a] text-white text-sm font-medium rounded-md transition duration-200">
                    Guardar Cronograma
                </button>
            </div>
        </div>
    </div>

    <script>
        // Utilidades para normalizar valores que llegan como 'false'/false/null
        function isFalseyString(v) {
            return v === false || v === 'false' || v === 'null' || v === 'undefined' || v === 'NaN';
        }
        function safe(v) {
            return (v == null || isFalseyString(v)) ? '' : String(v);
        }

        function openCronogramaModal() {
            document.getElementById('cronogramaModal').classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Evita scroll del body
        }

        function closeCronogramaModal() {
            document.getElementById('cronogramaModal').classList.add('hidden');
            document.body.style.overflow = 'auto'; // Restaura scroll del body
        }

        function addRow() {
            const tableBody = document.getElementById('cronogramaTableBody');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                </td>
                <td class="px-4 py-2 border border-gray-300">
                    <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                </td>
                <td class="px-4 py-2 border border-gray-300 text-center">
                    <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            tableBody.appendChild(newRow);
        }

        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
        }

        function saveCronograma() {
            // Guardar el cronograma y también actualizar el borrador
            guardarBorrador('formPagina3', 'pagina3');
            mostrarMensaje('Cronograma guardado exitosamente', 'success');
            closeCronogramaModal();
        }

        // Cerrar modal al hacer click fuera de él
        document.getElementById('cronogramaModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeCronogramaModal();
            }
        });

        // Funciones para guardar y cargar borradores
        function guardarBorrador(formId, pageKey, targetBtn) {
            const form = document.getElementById(formId);
            const data = {};
            
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (input.type === 'checkbox') {
                    if (!data[input.name]) data[input.name] = [];
                    if (input.checked) {
                        data[input.name].push(safe(input.value));
                    }
                } else if (input.type === 'radio') {
                    if (input.checked) {
                        data[input.name] = safe(input.value);
                    }
                } else if (input.type === 'file') {
                    data[input.name] = input.files[0] ? input.files[0].name : '';
                } else {
                    data[input.name] = safe(input.value);
                }
            });
            
            // Guardar datos del cronograma
            const cronogramaData = [];
            const tableBody = document.getElementById('cronogramaTableBody');
            const rows = tableBody.querySelectorAll('tr');
            
            rows.forEach(row => {
                const inputs = row.querySelectorAll('input');
                if (inputs.length >= 5) {
                    const rowData = {
                        actividad: safe(inputs[0].value),
                        mes: safe(inputs[1].value),
                        meta: safe(inputs[2].value),
                        entregable: safe(inputs[3].value),
                        fecha_entrega: safe(inputs[4].value)
                    };
                    // Solo guardar si al menos uno de los campos tiene datos
                    if (rowData.actividad || rowData.mes || rowData.meta || rowData.entregable || rowData.fecha_entrega) {
                        cronogramaData.push(rowData);
                    }
                }
            });
            
            data.cronograma = cronogramaData;
            
            localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
            mostrarMensaje('Borrador guardado exitosamente', 'success', targetBtn);
        }

        function cargarBorrador(formId, pageKey) {
            const savedData = localStorage.getItem('proyecto_borrador_' + pageKey);
            
            if (savedData) {
                try {
                    const raw = JSON.parse(savedData);
                    // Limpieza defensiva contra valores 'false' persistidos previamente
                    const data = {};
                    Object.keys(raw).forEach(k => {
                        if (k === 'cronograma') {
                            const arr = Array.isArray(raw[k]) ? raw[k] : [];
                            data[k] = arr.map(r => ({
                                actividad: safe(r && r.actividad),
                                mes: safe(r && r.mes),
                                meta: safe(r && r.meta),
                                entregable: safe(r && r.entregable),
                                fecha_entrega: safe(r && r.fecha_entrega)
                            }));
                        } else {
                            data[k] = safe(raw[k]);
                        }
                    });
                    // Reescribir el borrador ya limpiado para evitar que regrese 'false'
                    localStorage.setItem('proyecto_borrador_' + pageKey, JSON.stringify(data));
                    const form = document.getElementById(formId);
                    
                    Object.keys(data).forEach(key => {
                        if (key === 'cronograma') {
                            // Cargar datos del cronograma
                            cargarCronograma(data[key]);
                        } else {
                            const elements = form.querySelectorAll('[name="' + key + '"]');
                            
                            elements.forEach(element => {
                                if (element.type === 'checkbox') {
                                    element.checked = Array.isArray(data[key]) && data[key].includes(safe(element.value));
                                } else if (element.type === 'radio') {
                                    element.checked = safe(element.value) === data[key];
                                } else if (element.type !== 'file') {
                                    element.value = data[key] || '';
                                }
                            });
                        }
                    });
                } catch (error) {
                    console.error('Error al cargar el borrador:', error);
                    // Si hay error, crear una fila vacía en el cronograma
                    const tableBody = document.getElementById('cronogramaTableBody');
                    if (tableBody.children.length === 0) {
                        addRow();
                    }
                }
            } else {
                // Si no hay datos guardados, asegurarse de que haya al menos una fila en el cronograma
                const tableBody = document.getElementById('cronogramaTableBody');
                if (tableBody.children.length === 0) {
                    addRow();
                }
            }
        }

        function cargarCronograma(cronogramaData) {
            const tableBody = document.getElementById('cronogramaTableBody');
            tableBody.innerHTML = '';

            if (!Array.isArray(cronogramaData) || cronogramaData.length === 0) {
                addRow();
                return;
            }

            cronogramaData.forEach(rowData => {
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Nombre de la actividad">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Trimestre">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Meta">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="text" class="w-full border-0 focus:ring-0 text-sm" placeholder="Entregable">
                    </td>
                    <td class="px-4 py-2 border border-gray-300">
                        <input type="date" class="w-full border-0 focus:ring-0 text-sm">
                    </td>
                    <td class="px-4 py-2 border border-gray-300 text-center">
                        <button type="button" onclick="removeRow(this)" class="text-red-600 hover:text-red-800">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </td>
                `;
                const inputs = newRow.querySelectorAll('input');
                inputs[0].value = safe(rowData.actividad);
                inputs[1].value = safe(rowData.mes);
                inputs[2].value = safe(rowData.meta);
                inputs[3].value = safe(rowData.entregable);
                inputs[4].value = safe(rowData.fecha_entrega);

                tableBody.appendChild(newRow);
            });
        }

        function mostrarMensaje(mensaje, tipo = 'info', targetEl = null) {
            const messageDiv = document.createElement('div');
            let baseClasses = 'p-4 rounded-md shadow-lg z-50 border ';

            if (tipo === 'success') {
                baseClasses += 'bg-green-100 text-green-800 border-green-200';
            } else if (tipo === 'error') {
                baseClasses += 'bg-red-100 text-red-800 border-red-200';
            } else {
                baseClasses += 'bg-blue-100 text-blue-800 border-blue-200';
            }

            messageDiv.className = baseClasses;
            messageDiv.textContent = mensaje;

            if (targetEl && targetEl.getBoundingClientRect) {
                messageDiv.style.position = 'absolute';
                messageDiv.style.visibility = 'hidden';
                document.body.appendChild(messageDiv);

                const rect = targetEl.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

                const mw = messageDiv.offsetWidth;
                const mh = messageDiv.offsetHeight;

                let left = rect.left + scrollLeft + (rect.width - mw) / 2;
                let top = rect.top + scrollTop - mh - 8;
                if (top < (window.pageYOffset || document.documentElement.scrollTop)) {
                    top = rect.top + scrollTop + rect.height + 8;
                }

                const maxLeft = (window.pageXOffset || document.documentElement.scrollLeft) + document.documentElement.clientWidth - mw - 8;
                if (left < 8) left = 8;
                if (left > maxLeft) left = maxLeft;

                messageDiv.style.left = left + 'px';
                messageDiv.style.top = top + 'px';
                messageDiv.style.visibility = 'visible';
            } else {
                messageDiv.style.position = 'fixed';
                messageDiv.style.top = '1rem';
                messageDiv.style.right = '1rem';
                document.body.appendChild(messageDiv);
            }

            setTimeout(() => {
                if (messageDiv && messageDiv.parentNode) messageDiv.parentNode.removeChild(messageDiv);
            }, 3000);
        }

        // Cargar borrador y añadir control beforeunload y bloqueo/Siguiente
        window.addEventListener('load', function() {
            cargarBorrador('formPagina3', 'pagina3');

            const KEY = 'proyecto_borrador_pagina3_saved';
            const form = document.getElementById('formPagina3');
            const buttons = Array.from(document.querySelectorAll('button'));
            const guardarBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('guardarBorrador') || /guardar borrador/i.test(b.textContent));
            const siguienteBtn = buttons.find(b => (b.getAttribute('onclick')||'').includes('registroProyecto4.jsp') || /siguiente/i.test(b.textContent));

            function setDisabled(btn, disabled){ if(!btn) return; btn.disabled = disabled; btn.setAttribute('aria-disabled', disabled ? 'true' : 'false'); if(disabled) { btn.classList.add('opacity-60','cursor-not-allowed'); } else { btn.classList.remove('opacity-60','cursor-not-allowed'); } }

            let saved = localStorage.getItem(KEY) === '1';
            setDisabled(siguienteBtn, !saved);

            if(guardarBtn){ guardarBtn.addEventListener('click', function(){ localStorage.setItem(KEY,'1'); saved = true; setDisabled(siguienteBtn, false); console.log('Borrador pagina3 guardado -> Siguiente habilitado'); }); }

            if(form){
                const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
                const onChange = function(){ if(saved){ saved = false; localStorage.setItem(KEY,'0'); setDisabled(siguienteBtn, true); console.log('Formulario pagina3 modificado despues de guardar: Siguiente bloqueado'); } };
                inputs.forEach(el => el.addEventListener('input', onChange));
                inputs.forEach(el => el.addEventListener('change', onChange));

                window.addEventListener('beforeunload', function(e){ try{ if(!saved){ var msg='Tiene cambios sin guardar. ¿Desea salir sin guardar?'; e.preventDefault(); e.returnValue = msg; return msg; } }catch(err){ return undefined; } });
            }
        });
    </script>

    <%@ include file="/footer.jsp" %>
</body>
</html>